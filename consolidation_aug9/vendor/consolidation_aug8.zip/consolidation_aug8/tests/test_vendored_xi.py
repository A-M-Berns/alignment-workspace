import hashlib
import json
import unittest
from fractions import Fraction as Q
from pathlib import Path

from src.vendored_ix import (
    accrual_bound,
    max_bound,
    nonzero_subsidy_counterexample,
    ring_fenced_fencing_witness,
    unpartitioned_fencing_witness,
)
from src.vendored_x import (
    DK,
    PROCEDURE,
    WORLD,
    alignment_lemma_witness,
    dk_minimal_reserves,
    dk_recurrent_complaint_sequence_revenue,
    dk_sufficient_reserves,
    dk_transient_date_cap,
    starvation_witness,
)
from src.vendored_xi import (
    Filing,
    accrual_compiler,
    boundedness_diagnostic,
    certified_withdrawal_safe,
    coarse_gap_family,
    coarsened_minimum,
    reference_jump,
    constant_one_compiler,
    cumulative_charge,
    enforcement_family_revenue,
    exact_minimum,
    finite_overtaking,
    fencing_bypass_interval,
    foa_x,
    funding_defeating_inflow,
    lexical_functional,
    max_compiler,
    no_bootstrap,
    non_delay_closed_aligned_class,
    orbit,
    priority_admissions,
    quotient_functional,
    rename_record,
    saturated_procedure_liquidity,
    recurrent_complaint_sequence_cap,
    terminal_route_coverage_biconditional,
    transient_uncovered_cost,
    unsaturated_procedure_liquidity,
)


ROOT = Path(__file__).resolve().parents[2]


@unittest.skip("superseded by FROZEN_INPUT_CHECKSUMS.json and tests/run.py")
class FrozenTreeTests(unittest.TestCase):
    def test_full_phase_vi_x_tree_matches_manifest(self) -> None:
        manifest = ROOT / "phase_xi_theorem_ledger" / "FROZEN_INPUT_CHECKSUMS.json"
        expected = json.loads(manifest.read_text(encoding="utf-8"))
        self.assertGreater(len(expected), 60)
        for phase in (
            "phase_vi_answerability",
            "phase_vii_answerable_learning",
            "phase_viii_construction",
            "phase_ix_flow_mechanism",
            "phase_x_existence",
        ):
            actual_files = {
                str(path.relative_to(ROOT))
                for path in (ROOT / phase).rglob("*")
                if path.is_file()
                and "__pycache__" not in path.parts
                and path.suffix != ".pyc"
                and path.name != ".DS_Store"
            }
            recorded_files = {key for key in expected if key.startswith(phase + "/")}
            self.assertEqual(actual_files, recorded_files, phase)
        for relative, digest in expected.items():
            self.assertEqual(
                hashlib.sha256((ROOT / relative).read_bytes()).hexdigest(), digest, relative
            )


class PositiveSpecializationTests(unittest.TestCase):
    def test_gp1_foa_specializes_to_DK(self) -> None:
        charge = [DK["gamma"]] * max(DK["D_P"], DK["D_W"])
        bound = foa_x(
            n_p=DK["n_P"],
            d_p=DK["D_P"],
            j_w=DK["J_W"],
            d_w=DK["D_W"],
            k_star=DK["Psi0"] * DK["c_R"]
            + DK["b"] * (DK["Psi0"] + 1) * DK["d"] * DK["zeta"],
            b=DK["b"],
            psi0=DK["Psi0"],
            d=DK["d"],
            n_match=20,
            charge=charge,
            stake_cap=DK["stake"],
        )
        self.assertEqual(bound, {PROCEDURE: Q(79, 32), WORLD: Q(31, 8)})
        self.assertEqual(bound, dk_sufficient_reserves())
        self.assertEqual(dk_transient_date_cap(), 35)

    def test_gp2_exact_minimum_specializes_to_DK(self) -> None:
        self.assertEqual(dk_minimal_reserves(), {PROCEDURE: Q(17, 32), WORLD: Q(1, 2)})
        self.assertEqual(sum(dk_minimal_reserves().values(), Q(0)), Q(33, 32))

    def test_gp5_fencing_specializes_to_IX(self) -> None:
        pooled = unpartitioned_fencing_witness()
        fenced = ring_fenced_fencing_witness()
        self.assertFalse(pooled.normative_active)
        self.assertTrue(fenced.normative_active)
        self.assertEqual(fencing_bypass_interval(Q(1), Q(1, 4)), (Q(1), Q(5, 4)))

    def test_gp6_alignment_specializes_to_X(self) -> None:
        witness = alignment_lemma_witness()
        self.assertEqual(witness["fenced_total"], Q(5, 4))
        self.assertEqual(witness["merged_undelayed"], Q(3, 4))
        self.assertEqual(witness["merged_delay_optimized"], Q(5, 4))

    def test_gp7_recurrent_complaint_sequence_specializes_to_DK(self) -> None:
        revenue = dk_recurrent_complaint_sequence_revenue()
        self.assertEqual(revenue["displayed_key_revenue"], Q(3, 32))
        self.assertEqual(revenue["loose_key_cap"], Q(3))

    def test_gp9_compilers_specialize_to_IX(self) -> None:
        levels = [Q(1, 3), Q(1, 2)]
        self.assertEqual(max_compiler(levels), max_bound(levels))
        self.assertEqual(accrual_compiler(levels, Q(3, 4)), accrual_bound(*levels, Q(3, 4)))
        self.assertEqual(reference_jump(max_compiler, levels, 0), Q(0))
        self.assertEqual(
            reference_jump(lambda xs: accrual_compiler(xs, Q(3, 4)) if len(xs) == 2 else max_compiler(xs), levels, 0),
            Q(1, 8),
        )


class GeneralPositiveWitnessTests(unittest.TestCase):
    def test_gp2_coarse_gap_has_no_uniform_constant(self) -> None:
        small = coarse_gap_family(1)
        large = coarse_gap_family(999)
        self.assertEqual(small, (Q(2), Q(2)))
        self.assertGreater(large[0] / large[1], 400)

    def test_gp2_quadratic_requires_saturation(self) -> None:
        self.assertEqual(saturated_procedure_liquidity(10), Q(120))
        self.assertEqual(unsaturated_procedure_liquidity(10), Q(10))
        self.assertGreater(saturated_procedure_liquidity(100), 80 * saturated_procedure_liquidity(10))
        self.assertEqual(unsaturated_procedure_liquidity(100), 10 * unsaturated_procedure_liquidity(10))

    def test_gp3_transient_cost_adds_by_era(self) -> None:
        charge = [Q(1, 8), Q(1, 8)]
        self.assertEqual(transient_uncovered_cost(3, charge, 2, 4), Q(3))
        self.assertTrue(terminal_route_coverage_biconditional(True, True))
        self.assertFalse(terminal_route_coverage_biconditional(False, True))

    def test_gp4_finite_overtaking_and_starvation_boundary(self) -> None:
        target = Filing("target", 1, 5)
        served = [Filing("a", 0, 0), Filing("b", 2, 1), target]
        self.assertEqual(finite_overtaking(target, served), 1)
        original = starvation_witness()
        self.assertTrue(original["index_major_starves"])
        self.assertEqual(original["date_major_admission_date"], 3)

    def test_gp4_fixed_priority_finite_trace_is_admitted(self) -> None:
        filings = [Filing(str(i), i, i) for i in range(8)]
        admitted = priority_admissions(filings, capacity=1, horizon=20)
        self.assertTrue(all(date is not None for date in admitted.values()))

    def test_gp5_certified_surplus_is_exact_outgoing_cap(self) -> None:
        self.assertTrue(certified_withdrawal_safe(Q(4), Q(2), Q(2)))
        self.assertFalse(certified_withdrawal_safe(Q(4), Q(2), Q(2) + Q(1, 100)))
        self.assertFalse(nonzero_subsidy_counterexample(Q(1, 7))["target_survives"])

    def test_gp6_every_coarsening_is_funding_monotone(self) -> None:
        fenced, pooled = coarsened_minimum(
            {"a": [Q(2), Q(-2), Q(0)], "b": [Q(0), Q(3), Q(-3)], "c": [Q(1), Q(-1), Q(0)]}
        )
        self.assertEqual(fenced, Q(6))
        self.assertLessEqual(pooled, fenced)

    def test_gp6_delay_closure_is_not_necessary(self) -> None:
        fenced, pooled = non_delay_closed_aligned_class()
        self.assertEqual((fenced, pooled), (Q(3), Q(3)))

    def test_gp7_boundedness_needs_typed_disposition(self) -> None:
        enforcement = boundedness_diagnostic(covered=True, adequate=True, keys=5, concurrent=2, charge_total=Q(1, 4))
        starvation = boundedness_diagnostic(covered=True, adequate=False, keys=5, concurrent=2, charge_total=Q(1, 4))
        self.assertEqual(enforcement["uniform_cap"], Q(5, 2))
        self.assertTrue(enforcement["typed"])
        self.assertIsNone(starvation["uniform_cap"])

    def test_gp8_twin_orbit_and_raw_functional_boundary(self) -> None:
        record = (("tau", Q(1)), ("beta", Q(2)))
        swapped = rename_record(record, {"tau": "beta", "beta": "tau"})
        self.assertIn(swapped, orbit(record))
        self.assertEqual(quotient_functional(record), quotient_functional(swapped))
        self.assertNotEqual(lexical_functional(record), lexical_functional(swapped))

    def test_gp9_actual_compiler_order_interval(self) -> None:
        levels = [Q(1, 3), Q(1, 2)]
        self.assertEqual(max_compiler(levels), Q(1, 2))
        self.assertEqual(accrual_compiler(levels, Q(0)), max_compiler(levels))
        self.assertEqual(accrual_compiler(levels, Q(1)), Q(2, 3))
        self.assertEqual(constant_one_compiler(levels), Q(1))
        self.assertGreater(constant_one_compiler(levels), accrual_compiler(levels, Q(1)))


class UniformNegativeWitnessTests(unittest.TestCase):
    def test_gn1_matching_inflow_defeats_every_displayed_prefix(self) -> None:
        charge = [Q(1, 3), Q(1, 5), Q(1, 7), Q(1, 11)]
        inflow = funding_defeating_inflow(charge)
        for k in range(1, len(charge) + 1):
            self.assertEqual(cumulative_charge(inflow, k), cumulative_charge(charge, k))

    def test_gn2_no_bootstrap_has_a_nonvacuity_boundary(self) -> None:
        self.assertTrue(no_bootstrap(Q(1, 8), Q(0)))
        self.assertTrue(no_bootstrap(Q(1, 8), Q(1, 9)))
        self.assertFalse(no_bootstrap(Q(1, 8), Q(1, 8)))

    def test_gn3_bypass_threshold_is_an_interval_not_all_underfunding(self) -> None:
        low, high = fencing_bypass_interval(Q(3, 4) + Q(1, 4), Q(1, 4))
        self.assertEqual((low, high), (Q(1), Q(5, 4)))
        self.assertLess(Q(1, 2), low)  # too poor even to pay the world loss

    def test_gn5_positive_literal_charge_pays_correct_repair(self) -> None:
        charge = [Q(1, 64)]
        self.assertGreater(cumulative_charge(charge, 1), 0)
        # Zeroing repair charge would preserve the formal queue property; hence
        # scrutiny universality alone cannot prove the requested impossibility.
        filings = [Filing("correct", 0, 0)]
        self.assertEqual(priority_admissions(filings, capacity=1, horizon=0)["correct"], 0)

    def test_gn6_key_boundary_requires_repair_only_density(self) -> None:
        self.assertEqual(enforcement_family_revenue(6, Q(1, 64)), Q(3, 32))
        self.assertGreater(enforcement_family_revenue(10_000, Q(1, 64)), 100)
        self.assertEqual(recurrent_complaint_sequence_cap(32, 6, [Q(1, 64)], 1), Q(3))


if __name__ == "__main__":
    unittest.main()
