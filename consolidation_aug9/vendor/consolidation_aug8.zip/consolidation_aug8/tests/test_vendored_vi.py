import ast
from fractions import Fraction
from pathlib import Path
import re
import unittest

from src.vendored_vi import (
    constant_charge_timeout,
    d2_witness,
    d3_false_bound_trace,
    nc_primitive_response_exists,
    overload_backlog,
    relabel_lock_trace,
    token_envelope_holds,
)


class ExactWitnessTests(unittest.TestCase):
    def test_d1_timeout_bound_and_equality_case(self) -> None:
        capacity = Fraction(1)
        charge = Fraction(1, 4)
        stake = Fraction(1, 100)
        timeout = constant_charge_timeout(capacity, charge)
        self.assertEqual(timeout, 4)
        self.assertLess(stake + (timeout - 1) * charge, capacity)
        self.assertGreater(stake + timeout * charge, capacity)

    def test_d2_contentful_survival_witness(self) -> None:
        witness = d2_witness()
        self.assertTrue(witness.certifies())
        self.assertEqual(witness.maximum_same_date_lock(), Fraction(1, 2))
        arrivals = [Fraction(2), Fraction(0), Fraction(2), Fraction(0)]
        self.assertTrue(
            token_envelope_holds(
                arrivals, witness.arrival_rate, witness.arrival_burst
            )
        )

    def test_a1_unrestricted_overload_has_linear_backlog(self) -> None:
        self.assertEqual(
            overload_backlog(12, Fraction(3), Fraction(2)), Fraction(12)
        )
        self.assertGreater(
            overload_backlog(120, Fraction(3), Fraction(2)),
            overload_backlog(12, Fraction(3), Fraction(2)),
        )

    def test_d3_false_bound_is_as_solvent_but_pays_without_bound(self) -> None:
        first = d3_false_bound_trace(8)
        later = d3_false_bound_trace(80)
        self.assertTrue(first.bound_is_false)
        self.assertTrue(first.as_solvent)
        self.assertEqual(first.maximum_lock, Fraction(1, 2))
        self.assertEqual(first.challenger_gain, Fraction(2))
        self.assertEqual(later.challenger_gain, Fraction(20))
        self.assertGreater(later.challenger_gain, first.challenger_gain)

    def test_d4_external_relabeling_preserves_lock_trace(self) -> None:
        trace = (Fraction(1, 4), Fraction(1, 2), Fraction(0))
        self.assertEqual(relabel_lock_trace(trace, "true"), trace)
        self.assertEqual(relabel_lock_trace(trace, "false"), trace)

    def test_nc_primitive_dismissal_witness_has_no_response(self) -> None:
        premises = frozenset({"seed:A0"})
        forbidden = frozenset({"seed:A0", "target:u", "successor:u1"})
        self.assertFalse(nc_primitive_response_exists(premises, forbidden))

    def test_no_float_literals_in_witness_source(self) -> None:
        source_path = Path(__file__).parents[1] / "src" / "vendored_vi.py"
        tree = ast.parse(source_path.read_text(encoding="utf-8"))
        float_nodes = [
            node for node in ast.walk(tree)
            if isinstance(node, ast.Constant) and isinstance(node.value, float)
        ]
        self.assertEqual(float_nodes, [])

    @unittest.skip("superseded by the consolidation claim/status audit")
    def test_decision_ledger_has_the_five_fixed_verdicts(self) -> None:
        ledger_path = Path(__file__).parents[1] / "DECISION_LEDGER.md"
        ledger = ledger_path.read_text(encoding="utf-8")
        rows = re.findall(
            r"^\| D([1-5]) [^|]*\| \*\*(PROVED|REFUTED|BLOCKED)\*\* \|",
            ledger,
            flags=re.MULTILINE,
        )
        self.assertEqual(
            dict(rows),
            {
                "1": "PROVED",
                "2": "PROVED",
                "3": "REFUTED",
                "4": "PROVED",
                "5": "REFUTED",
            },
        )


if __name__ == "__main__":
    unittest.main()
