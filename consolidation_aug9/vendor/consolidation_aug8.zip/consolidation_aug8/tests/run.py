#!/usr/bin/env python3
"""One-command runner for exact tests, document audits, rename integrity, and Lean."""
from __future__ import annotations

import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

RETIRED = (
    "floor", "rent", "defect", "kernel", "AnsLearn", "ARC", "shock",
    "round", "period", "alpha", "extortion", "martyrdom", "firewall",
)
RETIRED_NOTATION = ("B_R", "D_N", "E_N", "E_*", "a_t", "R_t", "S_t", "S(R)")
EXCLUDED_MARKDOWN = {
    "GLOSSARY.md", "AMBIGUITIES.md", "ID_EXPANSIONS.md", "REPORT.md",
    "CHECKSUMS_PRE_POST.md", "TEST_OUTPUT_DIFF.md",
}

def documents() -> list[pathlib.Path]:
    return sorted(ROOT.glob("THEORY_*.md"))

def live_markdown() -> list[pathlib.Path]:
    return sorted(
        path for path in ROOT.rglob("*.md")
        if "archive" not in path.parts and path.name not in EXCLUDED_MARKDOWN
    )

def audit_retired_names() -> None:
    failures: list[str] = []
    claim_id = re.compile(r"\b(?:C|NL|AM)-[A-Z0-9-]+\b")
    for path in live_markdown():
        for number, raw in enumerate(path.read_text().splitlines(), 1):
            line = claim_id.sub("", raw)
            for word in RETIRED:
                if not re.search(rf"\b{re.escape(word)}\b", line, re.I):
                    continue
                if word == "floor" and any(token in line for token in
                    ("integer-floor", "rational-floor", "\\lfloor", "⌊", "Mathlib.Data.Rat.Floor")):
                    continue
                if word == "defect" and "fault proofs" in line.lower():
                    continue
                if word == "round" and "round-trip" in line.lower():
                    continue
                failures.append(f"{path.relative_to(ROOT)}:{number}: retired {word!r}")
            for notation in RETIRED_NOTATION:
                if re.search(rf"(?<![A-Za-z]){re.escape(notation)}(?![A-Za-z])", line):
                    failures.append(f"{path.relative_to(ROOT)}:{number}: retired notation {notation!r}")
    if failures:
        raise AssertionError("retired vocabulary remains:\n" + "\n".join(failures))

def audit_documents() -> None:
    audit_retired_names()
    if "sorry" in "\n".join(path.read_text() for path in (ROOT / "lean").glob("*.lean")):
        raise AssertionError("Lean source contains sorry")
    missing_command = re.compile(
        r"(?<!\\)\b(?:quad|qquad|cdot|times|leq|geq|operatorname|mathrm|"
        r"mathbf|mathcal|mathfrak|tag)\b"
    )
    math_segment = re.compile(r"\\\((.*?)\\\)|\\\[(.*?)\\\]", re.S)
    for path in documents():
        body = path.read_text()
        for opening, closing, label in ((r"\(", r"\)", "inline"), (r"\[", r"\]", "display")):
            if body.count(opening) != body.count(closing):
                raise AssertionError(f"unbalanced {label} math delimiters in {path.name}")
        for match in math_segment.finditer(body):
            segment = match.group(1) if match.group(1) is not None else match.group(2)
            line = body.count("\n", 0, match.start()) + 1
            if missing_command.search(segment):
                raise AssertionError(f"missing LaTeX command backslash in {path.name}:{line}")
            depth = 0
            for char in re.sub(r"\\[{}]", "", segment):
                if char == "{": depth += 1
                elif char == "}": depth -= 1
                if depth < 0:
                    raise AssertionError(f"unbalanced math braces in {path.name}:{line}")
            if depth or len(re.findall(r"\\left(?![A-Za-z])", segment)) != len(re.findall(r"\\right(?![A-Za-z])", segment)):
                raise AssertionError(f"unbalanced math grouping in {path.name}:{line}")
    ledger = (ROOT / "LEDGER.md").read_text()
    allowed = (r"PROVED\+MACHINE-CHECKED|PROVED\+INDEPENDENTLY-REDERIVED|"
               r"PROVED \(single derivation\)|PROVED-CONDITIONAL \(conditions listed\)|"
               r"REFUTED \(witness displayed\)|OPEN")
    ledger_status = {match.group(1): match.group(2) for match in re.finditer(
        rf"\| (C-[A-Z0-9-]+)[^\n]*\| ({allowed}) \|", ledger)}
    theory_claims: set[str] = set()
    for path in documents():
        body = path.read_text()
        for claim in re.findall(r"\{#(C-[A-Z0-9-]+)\}", body):
            theory_claims.add(claim)
            if claim not in ledger:
                raise AssertionError(f"missing ledger row {claim}")
        for claim, status in re.findall(rf"\{{#(C-[A-Z0-9-]+)\}} \*\*Status: ({allowed})\.\*\*", body):
            if ledger_status.get(claim) != status:
                raise AssertionError(f"status mismatch {claim}: {status} / {ledger_status.get(claim)}")
    if theory_claims != set(ledger_status):
        raise AssertionError(f"ledger/theory claim mismatch: {sorted(set(ledger_status) ^ theory_claims)}")

def verify_manifest() -> None:
    path = ROOT / "FROZEN_INPUT_CHECKSUMS.json"
    data = json.loads(path.read_text())
    if data.get("algorithm") != "sha256" or not data.get("pre_rename_files") or not data.get("post_rename_files"):
        raise AssertionError("checksum manifest is empty or malformed")
    archive = ROOT / "archive" / "pre_standardization"
    for relative, digest in data["pre_rename_files"].items():
        actual = archive / relative
        if not actual.is_file() or hashlib.sha256(actual.read_bytes()).hexdigest() != digest:
            raise AssertionError(f"pre-rename checksum mismatch: {relative}")
    for relative, digest in data["post_rename_files"].items():
        actual = ROOT / relative
        if not actual.is_file() or hashlib.sha256(actual.read_bytes()).hexdigest() != digest:
            raise AssertionError(f"post-rename checksum mismatch: {relative}")

def verify_rename_roundtrip() -> None:
    subprocess.run([sys.executable, str(ROOT / "tools" / "rename_check.py")], check=True)

def run_lean() -> bool:
    configured = os.environ.get("MATHLIB_DIR")
    if not configured:
        print("LEAN SKIPPED: set MATHLIB_DIR to a Mathlib/Lake project")
        return False
    mathlib = pathlib.Path(configured).expanduser()
    lake = shutil.which("lake")
    if lake is None:
        print("LEAN SKIPPED: `lake` is unavailable; Python and document checks passed")
        return False
    if not mathlib.is_dir():
        print(f"LEAN SKIPPED: configured Mathlib directory does not exist: {mathlib}")
        return False
    for source in sorted((ROOT / "lean").glob("*.lean")):
        subprocess.run([lake, "env", "lean", str(source)], cwd=mathlib, check=True)
    print("LEAN CHECKED: both consolidation Lean files compiled sorry-free")
    return True

if __name__ == "__main__":
    audit_documents()
    verify_manifest()
    verify_rename_roundtrip()
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), pattern="test_*.py")
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        sys.exit(1)
    run_lean()
    print("ALL PYTHON TESTS GREEN: Tier A, Tier B, document and integrity audits")
