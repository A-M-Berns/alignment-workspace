# Standardization report and proposals requiring author approval

This file reports the requested non-actions. It does not change theorem status,
build a reverse-dependency index, or alter out-of-scope mathematics.

## Status-vocabulary proposal — not applied

`REFUTED (witness displayed)` currently labels both a false positive claim and a
countermodel showing that a theorem hypothesis is necessary. The latter is a
positive sharpness result. I propose adding `NECESSITY-WITNESS` for a displayed
drop-one countermodel while retaining `REFUTED` for a claim whose asserted
conclusion itself is false.

Proposed `normative-learner/LEDGER.md` reclassification:

| Row | Current | Proposed | Reason |
|---|---|---|---|
| `NL-X1`, `NL-X2`, `NL-X5`, `NL-X7`, `NL-X9`–`NL-X15`, `NL-X17`, `NL-X18` | REFUTED | NECESSITY-WITNESS | Each drops or bypasses a named joint-process contract and displays the resulting failure. |
| `AM-X1`–`AM-X9`, `AM-X11`–`AM-X17` | REFUTED | NECESSITY-WITNESS | Each malformed-certificate mutation establishes that a verifier field or invariant is load-bearing. |
| `AM-X10` | REFUTED | REFUTED | It directly refutes selection of a permanent universal comparison arena from the displayed local data; it is not merely a dropped hypothesis of `AM-J3`. |

The rows already marked `PROVED...`—including `NL-X3`, `NL-X4`, `NL-X6`,
`NL-X8`, and `NL-X16`—need no reclassification. No status was changed in this
pass because the canonical August 8 vocabulary remains in force pending author
approval.

## Reverse-dependency proposal — not built

Transpose the existing dependency column into a generated index:

```text
C-ID -> [NL/AM downstream claim IDs, proof locations, verification targets]
```

The generator should parse stable IDs rather than prose expansions, reject an
unknown dependency, and sort consumers by project and identifier. This would
make upstream-change impact visible without duplicating hypotheses. The index is
not constructed here.

## Determinate exceptions and remaining readings

- Mathematical integer floor and `Mathlib.Data.Rat.Floor` remain standard
  technical vocabulary. Book content uses *bound*.
- Matrix/table/ledger rows remain rows. Book and compiler objects are
  endorsements.
- Empirical/epistemic exposure remains exposure. `H_t` and position quantities
  are holdings.
- `P_\Gamma=conv(W_\Gamma)` is a local migration payoff carrier, not the retired
  notation for the credal simplex.
- Adjectives such as *certificate-bound*, *snapshot-bound*, and *cell-bound*
  mean “attached to”; they are neither book bounds nor proved ceilings.
- `C-FIXED-KERNEL` is a frozen stable identifier. Its expansion uses
  *fixed-transition boundary* and must not be renamed.
- The construction reply-cost use of `κ` was unrelated to the operative-force
  odds factor and is now `ζ`. No other unresolved double use was found.
- No `phase_xi_theorem_ledger/` or retained Phase IX/X proposal tree was present.
  The adopted decisions were applied to the retained files and the absence is
  recorded in both deviation files.
- The existing `THEORY_1`–`THEORY_6` numbering already had the required
  dependency order, so no filename move was necessary. Headings, folder maps,
  `FOR_HUMANS.md`, and ledger expansions now state the fixed one-theory order.

Every context-sensitive source-line occurrence reviewed in the pass, including
these exceptions, is listed in `AMBIGUITIES.md`. No further occurrence was left
with an indeterminate sense.

## Explicitly out of scope — unchanged

- tightening-count refinement to `NL-J2`/`NL-J3`;
- a `κ`-base lower bound on the jump recursion;
- the demand/nondegeneracy term;
- any new Lean target;
- the full local-span composition theorem.
