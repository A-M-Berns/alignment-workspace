"""Small exact-rational certificates.

These functions certify only the finite witnesses cited in the hand proofs.
They are not a longitudinal model or an implementation of AnsLearn.
"""

from dataclasses import dataclass
from fractions import Fraction
from typing import Dict, Iterable, Mapping, Sequence, Tuple


Q = Fraction


def procedure_lock(stake: Fraction, age: int, gamma: Fraction) -> Fraction:
    return stake + age * gamma


def world_lock(stake: Fraction, age: int) -> Fraction:
    del age
    return stake


def world_challenger_net(
    stake: Fraction, floor: Fraction, outcomes: Sequence[int]
) -> Fraction:
    if not outcomes:
        raise ValueError("a world block must be nonempty")
    if any(outcome not in (0, 1) for outcome in outcomes):
        raise ValueError("Boolean outcomes required")
    mean = Fraction(sum(outcomes), len(outcomes))
    return stake if mean < floor else -stake


def least_valid_block(
    outcomes: Sequence[int],
    frequency: Fraction,
    eta: Fraction,
    start: int = 0,
) -> int:
    if eta <= 0:
        raise ValueError("eta must be positive")
    total = 0
    for end in range(start, len(outcomes)):
        outcome = outcomes[end]
        if outcome not in (0, 1):
            raise ValueError("Boolean outcomes required")
        total += outcome
        length = end - start + 1
        mean = Fraction(total, length)
        if abs(mean - frequency) < eta:
            return length
    raise ValueError("finite prefix contains no valid block")


def residual_lock_certificate(
    *,
    Q_service: int,
    rho: int,
    beta: int,
    w_min: int,
    max_stake: Fraction,
    gamma: Fraction,
    procedure_reserve: Fraction,
    world_slots: int,
    world_reserve: Fraction,
    capacity: Fraction,
) -> Dict[str, Fraction]:
    numerator = 2 * beta + rho
    service_delay = (numerator + Q_service - 1) // Q_service
    open_work = rho * (service_delay + 1) + beta
    open_count = open_work // w_min
    procedure_lock_bound = open_count * (
        max_stake + service_delay * gamma
    )
    world_lock_bound = world_slots * max_stake
    assert procedure_lock_bound <= procedure_reserve
    assert world_lock_bound <= world_reserve
    assert procedure_reserve + world_reserve <= capacity
    return {
        "service_delay": Fraction(service_delay),
        "open_count": Fraction(open_count),
        "procedure_lock_bound": procedure_lock_bound,
        "world_lock_bound": world_lock_bound,
        "actual_total_lock_bound": procedure_lock_bound + world_lock_bound,
    }


@dataclass(frozen=True)
class ArcNode:
    name: str
    consumption: int
    unresolved: Tuple[str, ...]


@dataclass(frozen=True)
class ArcEdge:
    source: str
    target: str
    defect: str
    cost: Fraction


def certify_arc_paths(
    nodes: Mapping[str, ArcNode],
    edges: Iterable[ArcEdge],
    paths: Mapping[Tuple[str, str], Tuple[str, ...]],
) -> None:
    edge_map = {(edge.source, edge.defect): edge for edge in edges}
    for node in nodes.values():
        for defect in node.unresolved:
            key = (node.name, defect)
            if key not in paths or not paths[key]:
                raise AssertionError(f"missing route path for {key}")
            current = node
            for named_defect in paths[key]:
                edge = edge_map[(current.name, named_defect)]
                target = nodes[edge.target]
                if target.consumption >= current.consumption:
                    raise AssertionError("consumption did not decrease")
                current = target
            if defect in current.unresolved:
                raise AssertionError("path failed to resolve target defect")


def run_lexicographic_policy(
    start: str,
    nodes: Mapping[str, ArcNode],
    edges: Iterable[ArcEdge],
) -> Tuple[str, ...]:
    edge_map = {(edge.source, edge.defect): edge for edge in edges}
    trace = [start]
    current = nodes[start]
    while current.unresolved:
        defect = sorted(current.unresolved)[0]
        edge = edge_map[(current.name, defect)]
        successor = nodes[edge.target]
        if successor.consumption >= current.consumption:
            raise AssertionError("nonconsuming policy transition")
        trace.append(successor.name)
        current = successor
    return tuple(trace)


def construction_outflow_bound(
    *,
    world_slots: int,
    extraction: Fraction,
    initial_false: int,
    schemas: int,
    route_budget: int,
    route_cost: Fraction,
    defect_kinds: int,
    answer_cost: Fraction,
) -> Fraction:
    world = world_slots * extraction * (
        initial_false + schemas * route_budget
    )
    revisions = route_budget * route_cost
    answers = schemas * (route_budget + 1) * defect_kinds * answer_cost
    return world + revisions + answers


def reusable_cycle(steps: int) -> Tuple[str, ...]:
    state = "A"
    trace = [state]
    for _ in range(steps):
        state = "B" if state == "A" else "A"
        trace.append(state)
    return tuple(trace)
