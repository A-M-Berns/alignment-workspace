"""Exact-rational queue and aggregation experiments for Stage III-B.

Finite simulations below do not prove infinite liveness claims.  The general
flooding, FIFO-envelope, overload-safety, and identity-conservation theorems
are proved in ``LIVENESS_PASS.md``.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable, Sequence

Q = Fraction


def ceil_fraction(value: Q) -> int:
    x = Q(value)
    return -((-x.numerator) // x.denominator)


@dataclass(frozen=True)
class Job:
    identifier: str
    work: Q
    source_ids: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "work", Q(self.work))
        if self.work <= 0:
            raise ValueError("jobs need positive service work")


@dataclass(frozen=True)
class QueueStep:
    round_index: int
    arrived: tuple[str, ...]
    served: tuple[tuple[str, Q], ...]
    completed: tuple[str, ...]
    queued: tuple[tuple[str, Q], ...]
    workload_after_service: Q
    overload_announced: bool


def fifo_simulate(
    arrival_batches: Sequence[Sequence[Job]], capacity: Q
) -> tuple[QueueStep, ...]:
    """Work-conserving FIFO with divisible exact-rational service."""

    cap = Q(capacity)
    if cap <= 0:
        raise ValueError("capacity must be positive")
    queue: list[list[object]] = []
    known: set[str] = set()
    trace: list[QueueStep] = []
    for round_index, batch in enumerate(arrival_batches):
        for job in batch:
            if job.identifier in known:
                raise ValueError("job identifiers must be immutable and unique")
            known.add(job.identifier)
            queue.append([job, Q(job.work)])
        available = cap
        served: list[tuple[str, Q]] = []
        completed: list[str] = []
        while queue and available > 0:
            job = queue[0][0]
            remaining = Q(queue[0][1])
            assert isinstance(job, Job)
            amount = min(available, remaining)
            served.append((job.identifier, amount))
            remaining -= amount
            available -= amount
            if remaining == 0:
                completed.append(job.identifier)
                queue.pop(0)
            else:
                queue[0][1] = remaining
        workload = sum((Q(item[1]) for item in queue), Q(0))
        trace.append(
            QueueStep(
                round_index,
                tuple(job.identifier for job in batch),
                tuple(served),
                tuple(completed),
                tuple(
                    (item[0].identifier, Q(item[1]))  # type: ignore[union-attr]
                    for item in queue
                ),
                workload,
                overload_announced=workload > cap,
            )
        )
    return tuple(trace)


def identity_conserved(
    arrival_batches: Sequence[Sequence[Job]], trace: Sequence[QueueStep]
) -> bool:
    """Every arrived ID is exactly queued or completed after every prefix."""

    arrived: set[str] = set()
    completed: set[str] = set()
    for batch, step in zip(arrival_batches, trace):
        arrived.update(job.identifier for job in batch)
        completed.update(step.completed)
        queued = {identifier for identifier, _ in step.queued}
        if completed & queued or arrived != completed | queued:
            return False
    return True


def flooding_witness(
    capacity_per_round: Q, arrivals_per_round: Q, promised_wait: int
) -> tuple[int, Q, Q]:
    """First counting horizon contradicting a uniform wait promise."""

    capacity, arrivals = Q(capacity_per_round), Q(arrivals_per_round)
    if capacity <= 0 or arrivals <= capacity or promised_wait < 0:
        raise ValueError("need positive capacity, overload, and nonnegative wait")
    horizon = int(capacity * promised_wait / (arrivals - capacity)) + 1
    demand = arrivals * horizon
    possible_service = capacity * (horizon + promised_wait)
    if not demand > possible_service:
        raise AssertionError("bad flooding witness")
    return horizon, demand, possible_service


def arrival_envelope_holds(
    workloads: Sequence[Q], rho: Q, burst: Q
) -> bool:
    """Finite exact check of A[s,t] <= rho*length + burst."""

    values = tuple(Q(value) for value in workloads)
    rate, beta = Q(rho), Q(burst)
    if rate < 0 or beta < 0 or any(value < 0 for value in values):
        raise ValueError("nonnegative arrival parameters required")
    for start in range(len(values)):
        total = Q(0)
        for end in range(start, len(values)):
            total += values[end]
            if total > rate * (end - start + 1) + beta:
                return False
    return True


@dataclass(frozen=True)
class QualifiedFairnessBounds:
    backlog_after_service: Q
    workload_before_service: Q
    fifo_completion_rounds: int


def qualified_fairness_bounds(
    capacity: Q, rho: Q, burst: Q
) -> QualifiedFairnessBounds:
    """Bounds proved for FIFO under a token-bucket arrival envelope."""

    cap, rate, beta = Q(capacity), Q(rho), Q(burst)
    if not Q(0) <= rate < cap or beta < 0:
        raise ValueError("need 0 <= rho < capacity and nonnegative burst")
    before = 2 * beta + rate
    return QualifiedFairnessBounds(beta, before, ceil_fraction(before / cap))


@dataclass(frozen=True)
class ProvenanceAggregate:
    identifier: str
    source_vector: tuple[tuple[str, int], ...]

    @property
    def source_ids(self) -> frozenset[str]:
        return frozenset(identifier for identifier, count in self.source_vector if count)


def identity_vector(identifiers: Iterable[str]) -> tuple[tuple[str, int], ...]:
    counts: dict[str, int] = {}
    for identifier in identifiers:
        counts[identifier] = counts.get(identifier, 0) + 1
    return tuple(sorted(counts.items()))


def aggregate_sources(identifier: str, source_ids: Iterable[str]) -> ProvenanceAggregate:
    vector = identity_vector(source_ids)
    if not vector:
        raise ValueError("cannot create an empty aggregate")
    return ProvenanceAggregate(identifier, vector)


def vector_add(
    vectors: Iterable[tuple[tuple[str, int], ...]]
) -> tuple[tuple[str, int], ...]:
    counts: dict[str, int] = {}
    for vector in vectors:
        for identifier, count in vector:
            counts[identifier] = counts.get(identifier, 0) + count
    return tuple(sorted((identifier, count) for identifier, count in counts.items() if count))


def aggregation_conserves_identity(
    before: Iterable[tuple[tuple[str, int], ...]],
    live_after: Iterable[tuple[tuple[str, int], ...]],
    terminally_adjudicated: Iterable[tuple[tuple[str, int], ...]],
) -> bool:
    """Free-commutative-monoid conservation for merge/split/disposition."""

    return vector_add(before) == vector_add((*tuple(live_after), *tuple(terminally_adjudicated)))


def history_identity_conserved(
    live_before: Iterable[tuple[tuple[str, int], ...]],
    terminal_before: Iterable[tuple[tuple[str, int], ...]],
    live_after: Iterable[tuple[tuple[str, int], ...]],
    terminal_after: Iterable[tuple[tuple[str, int], ...]],
) -> bool:
    """Global live-plus-terminal stock conservation, including reopening."""

    return vector_add((*tuple(live_before), *tuple(terminal_before))) == vector_add(
        (*tuple(live_after), *tuple(terminal_after))
    )


def shared_response_covers_every_source(
    aggregate: ProvenanceAggregate, response_source_ids: Iterable[str]
) -> bool:
    """One effort may be shared only if congruence is recorded per source."""

    return aggregate.source_ids == frozenset(response_source_ids)


def lossy_aggregate_signature(
    extensional_claim: str, source_ids: Iterable[str]
) -> tuple[str, int]:
    """A deliberately bad summary: claim plus cardinality, no identities."""

    ids = tuple(source_ids)
    return extensional_claim, len(ids)


@dataclass(frozen=True)
class FiniteSchedulerObservation:
    horizon: int
    oldest_completed: bool
    remaining_ids: tuple[str, ...]


def newest_first_starvation_prefix(horizon: int) -> FiniteSchedulerObservation:
    """Finite shadows of an infinite starvation construction."""

    if horizon < 1:
        raise ValueError("positive horizon required")
    queue = ["old"]
    for index in range(horizon):
        queue.append(f"new-{index}")
        queue.pop()  # capacity one always serves the newest arrival
    return FiniteSchedulerObservation(horizon, "old" not in queue, tuple(queue))
