"""Small exact witnesses retained by the hardened theorem stack.

All arithmetic is rational.  These functions validate examples and do not
stand in for the general proofs in ``proofs/``.
"""

from fractions import Fraction as Q


def leverage_tight(c_p: Q, c_a: Q, c_s: Q):
    """Four atom masses realizing equality in the Leverage Lemma."""
    masses = (
        c_p * c_a * c_s,
        c_p * c_a * (1 - c_s),
        c_p * (1 - c_a),
        1 - c_p,
    )
    assert all(value >= 0 for value in masses)
    assert sum(masses) == 1
    return masses


def convergent_crossing_prefix(start: int, stop: int):
    """Gain from L_n then U_n in the convergent moving-book witness."""
    assert 4 <= start <= stop
    gains = tuple(Q(2, n) for n in range(start, stop + 1))
    return gains, sum(gains, Q(0))


def polyhedral_nonunique_repairs(q: Q):
    """Optimal repairs for p>=3/4, p<=1/4 with a=1/2."""
    assert 0 <= q <= 1
    lower = Q(3, 4) - q / 2
    upper = Q(1, 4) + q / 2
    assert lower >= 0 and upper >= 0 and lower + upper == 1
    return lower, upper


def canonical_staging_fraction(capacity: Q = Q(1, 20)):
    """Greatest lambda for K=max(0, 3 lambda/10 - 3/20)."""
    root = (capacity + Q(3, 20)) / Q(3, 10)
    return min(Q(1), root)


def dynamic_order_costs():
    """Standalone exact values extracted from the dynamic order witness."""
    first_order = Q(7, 40)
    second_order = Q(1, 10)
    assert first_order - second_order == Q(3, 40)
    return first_order, second_order


def six_case_version_space():
    """Evaluate the four canonical public predicates on active audits."""
    cases = {
        "c0": {"sector": "manufacturing", "dependency": "high"},
        "c1": {"sector": "manufacturing", "dependency": "low"},
        "c2": {"sector": "healthcare", "dependency": "high"},
        "c3": {"sector": "healthcare", "dependency": "low"},
        "c4": {"sector": "transport", "dependency": "high"},
        "c5": {"sector": "transport", "dependency": "low"},
    }
    successes = {"c0", "c2"}
    burdens = {"c1", "c3"}
    predicates = {
        "all": lambda case_id, attrs: True,
        "manufacturing": lambda case_id, attrs: attrs["sector"] == "manufacturing",
        "local-c0": lambda case_id, attrs: case_id == "c0",
        "high-dependency": lambda case_id, attrs: attrs["dependency"] == "high",
    }
    eligible = []
    for name, predicate in predicates.items():
        covered_success = {i for i in successes if predicate(i, cases[i])}
        covered_burden = {i for i in burdens if predicate(i, cases[i])}
        if len(covered_success) >= 2 and not covered_burden:
            eligible.append(name)
    selected = eligible[0] if len(eligible) == 1 else None
    return {
        "eligible": tuple(eligible),
        "selected": selected,
        "c4": predicates[selected]("c4", cases["c4"]) if selected else None,
        "c5": predicates[selected]("c5", cases["c5"]) if selected else None,
    }


def public_twin(rule, public_history):
    """Two hidden labels with one public input induce the same output."""
    honest = rule(public_history)
    manipulative = rule(public_history)
    return honest, manipulative

