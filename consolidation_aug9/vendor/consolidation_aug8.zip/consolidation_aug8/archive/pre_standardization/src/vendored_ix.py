"""Exact-rational Phase IX witnesses.

The functions certify the finite traces cited in the hand proofs.  They are
not a longitudinal simulation and do not import the Phase VI--VIII kernels.
"""

from dataclasses import dataclass
from fractions import Fraction
from typing import Dict, Iterable, Mapping, Optional, Sequence, Tuple, Union


Q = Fraction


def rent(periods: int, gamma: Fraction) -> Fraction:
    if periods < 0 or gamma <= 0:
        raise ValueError("nonnegative periods and positive rent required")
    return periods * gamma


def pure_run_failure_period(
    initial_wealth: Fraction, gamma: Fraction
) -> int:
    """First period whose rent cannot be paid, with no inflow."""
    if initial_wealth < 0 or gamma <= 0:
        raise ValueError("nonnegative wealth and positive rent required")
    return int(initial_wealth // gamma) + 1


def funding_failure_period(
    initial_wealth: Fraction,
    rents: Sequence[Fraction],
    inflows: Sequence[Fraction],
) -> Optional[int]:
    """First one-indexed period with insufficient funds, or None."""
    if len(rents) != len(inflows):
        raise ValueError("rent and inflow schedules must have equal length")
    wealth = initial_wealth
    for period, (due, inflow) in enumerate(zip(rents, inflows), start=1):
        if due < 0 or inflow < 0:
            raise ValueError("nonnegative flows required")
        wealth += inflow
        if wealth < due:
            return period
        wealth -= due
    return None


def nuisance_payoff(
    stake: Fraction, periods_open: int, gamma: Fraction
) -> Fraction:
    """Defect-free filer receives drip but forfeits its bond."""
    return rent(periods_open, gamma) - stake


def world_round_transfer(
    *,
    stake: Fraction,
    periods_open: int,
    gamma: Fraction,
    floor_false: bool,
) -> Dict[str, Fraction]:
    """Net book/challenger flow for one completed world challenge."""
    drip = rent(periods_open, gamma)
    if floor_false:
        challenger_net = stake + drip
    else:
        challenger_net = drip - stake
    return {
        "rent": drip,
        "challenger_net": challenger_net,
        "book_net_outflow": challenger_net,
    }


def serial_false_floor(
    *,
    initial_book_wealth: Fraction,
    stake: Fraction,
    periods_open: int,
    gamma: Fraction,
) -> Dict[str, Union[Fraction, int]]:
    per_round = stake + rent(periods_open, gamma)
    completed = int(initial_book_wealth // per_round)
    return {
        "per_round_extraction": per_round,
        "completed_rounds": completed,
        "first_unfunded_round": completed + 1,
        "challenger_gain": completed * per_round,
        "book_remainder": initial_book_wealth - completed * per_round,
    }


@dataclass(frozen=True)
class FirewallResult:
    world_start: Fraction
    procedure_start: Fraction
    world_end: Fraction
    procedure_end: Fraction
    normative_active: bool
    world_outflow: Fraction
    procedure_rent_paid: Fraction


def unpartitioned_firewall_witness() -> FirewallResult:
    """A world loss exhausts the shared fund before procedure rent is due."""
    shared = Q(1)
    world_rent = Q(1, 4)
    world_match = Q(3, 4)
    procedure_due = Q(1, 4)
    world_outflow = world_rent + world_match
    shared -= world_outflow
    active = shared >= procedure_due
    paid = procedure_due if active else Q(0)
    if active:
        shared -= paid
    return FirewallResult(
        world_start=Q(1),
        procedure_start=Q(1),
        world_end=shared,
        procedure_end=shared,
        normative_active=active,
        world_outflow=world_outflow,
        procedure_rent_paid=paid,
    )


def ring_fenced_firewall_witness() -> FirewallResult:
    """The same world loss cannot reach the procedure treasury."""
    world = Q(1)
    procedure = Q(1, 4)
    world_outflow = Q(1, 4) + Q(3, 4)
    procedure_due = Q(1, 4)
    world -= world_outflow
    active = procedure >= procedure_due
    paid = procedure_due if active else Q(0)
    if active:
        procedure -= paid
    return FirewallResult(
        world_start=Q(1),
        procedure_start=Q(1, 4),
        world_end=world,
        procedure_end=procedure,
        normative_active=active,
        world_outflow=world_outflow,
        procedure_rent_paid=paid,
    )


def nonzero_subsidy_counterexample(
    cap: Fraction,
) -> Dict[str, Union[Fraction, bool]]:
    """Any positive cap can break strong, surplus-free conservativity."""
    if cap <= 0:
        raise ValueError("a positive cap is required")
    procedure_due = cap
    procedure_start = cap
    transferred = cap
    procedure_after_subsidy = procedure_start - transferred
    return {
        "cap": cap,
        "procedure_due": procedure_due,
        "transferred": transferred,
        "procedure_after_subsidy": procedure_after_subsidy,
        "target_survives": procedure_after_subsidy >= procedure_due,
    }


def slack_cap_preserves(
    *, procedure_obligation: Fraction, certified_slack: Fraction, transfer: Fraction
) -> bool:
    if min(procedure_obligation, certified_slack, transfer) < 0:
        raise ValueError("nonnegative values required")
    procedure_start = procedure_obligation + certified_slack
    return transfer <= certified_slack and (
        procedure_start - transfer >= procedure_obligation
    )


def max_floor(products: Iterable[Fraction]) -> Fraction:
    values = tuple(products)
    return max(values, default=Q(0))


def max_shock(
    products: Sequence[Fraction], killed_index: int
) -> Dict[str, Fraction]:
    if killed_index < 0 or killed_index >= len(products):
        raise IndexError("killed chain not present")
    old = max_floor(products)
    survivors = products[:killed_index] + products[killed_index + 1 :]
    new = max_floor(survivors)
    return {"old_floor": old, "new_floor": new, "floor_drop": old - new}


def accrual_floor(
    left: Fraction, right: Fraction, bridge_strength: Fraction
) -> Fraction:
    """Interpolation from MAX to the independent-union lower bound."""
    if not (Q(0) <= left <= Q(1) and Q(0) <= right <= Q(1)):
        raise ValueError("leverage products must lie in [0,1]")
    if not Q(0) <= bridge_strength <= Q(1):
        raise ValueError("bridge strength must lie in [0,1]")
    high = max(left, right)
    low = min(left, right)
    return high + bridge_strength * low * (Q(1) - high)


def accrual_shock(
    left: Fraction, right: Fraction, bridge_strength: Fraction
) -> Dict[str, Fraction]:
    old = accrual_floor(left, right, bridge_strength)
    new = accrual_floor(Q(0), right, bridge_strength)
    return {"old_floor": old, "new_floor": new, "floor_drop": old - new}


def movement_charge(
    exposure: Fraction, old_reference: Fraction, new_reference: Fraction
) -> Fraction:
    signed = -exposure * (old_reference - new_reference)
    return max(Q(0), signed)


def flow_adequacy_reserve(
    *,
    canonical_cost: Fraction,
    procedure_count: int,
    procedure_delay: int,
    world_slots: int,
    world_delay: int,
    gamma: Fraction,
) -> Fraction:
    if min(procedure_count, procedure_delay, world_slots, world_delay) < 0:
        raise ValueError("counts and delays must be nonnegative")
    return canonical_cost + (
        procedure_count * procedure_delay + world_slots * world_delay
    ) * gamma


def normalize_flow_trace(
    trace: Sequence[Tuple[str, str, str, Fraction]],
    inverse_name_map: Mapping[str, str],
) -> Tuple[Tuple[str, str, str, Fraction], ...]:
    """Pull a twin flow trace back to the first record's names."""
    normalized = []
    for kind, payer, recipient, amount in trace:
        normalized.append(
            (
                kind,
                inverse_name_map.get(payer, payer),
                inverse_name_map.get(recipient, recipient),
                amount,
            )
        )
    return tuple(normalized)
