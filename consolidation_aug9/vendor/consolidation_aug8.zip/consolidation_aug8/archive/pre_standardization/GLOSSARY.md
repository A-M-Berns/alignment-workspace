# Canonical vocabulary and notation

This file is the sole canonical naming authority for the consolidation. The right column of the rename table gives the names used in the mathematics. Legacy names appear here and in `INTERPRETATION.md` only.

## Fixed vocabulary

**Leverage** is the multiplicative or network-amplified consequence of nested warranted floors. A **warrant** is a sourced defeasible transmission schema. An **endorsement** is a public commitment to a warrant or claim. A **book** is the active finite constraint set plus provenance. A **floor** is a lower-bound constraint. **Answerability** is the challenge-relative property defined by the selected stock or flow criterion. **Rent** is the literal per-period transfer in flow semantics. A **challenge** is an admitted typed request with stake and disposition rules. A **stake** is the challenger's escrowed amount.

## Mathematical objects

| Symbol | Meaning |
|---|---|
| \(\Omega,W,P\) | finite outcomes, represented world vectors, and \(\operatorname{conv}(W)\) |
| \(\mu\) | credence in \(\Delta(\Omega)\) |
| \(R,S(R)\) | active reason book and its permitted region |
| \(S_t,q_t,a_t\) | permitted quote region, reference, core coefficient |
| \(p_t,x_t,H_t\) | quote, executed position, post-trade cumulative exposure |
| \(g_t,G_N\) | one-date and prefix settlement payoff |
| \(\varepsilon_t,E_N\) | variational-inequality error and accumulated error |
| \(D_N\) | adverse exposure-weighted reference movement |
| \(K_t^{ans}\) | finite challenge kernel state |
| \(s^{ch}\) | challenge stake |
| \(r_K(k),R_K(k)\) | period-\(k\) rent and cumulative rent |
| \(C^{ans}\) | stock lock capacity |
| \(F_a(t)\) | flow balance of account \(a\) |
| \(D_P,D_W\) | procedure and world service latencies |
| \(n_P,J_W\) | procedure and world concurrency bounds |
| \(\Psi,B_R\) | consuming repair potential and its initial value |
| \(N_{match}\) | false-match bound before repair-pending status |

## Exhaustive rename table

| Legacy name | Canonical name |
|---|---|
| AnsLearn; Flow-AnsLearn | terminally answerable-learning criterion; flow terminal learning criterion (descriptive placeholders, author-reserved) |
| FAS; flow-FAS | exposed-answerable after stationarity; flow exposed-answerability condition |
| ARC; flow-ARC | authorized repair coverage |
| ARC-Reach | reachable-book repair coverage |
| ARC-Era | every-era repair coverage |
| ARC-Term; Terminal ARC | terminal-book coverage condition (placeholder, author-reserved) |
| FOA; FOA-R; FOA-X | finite-obligation adequacy bound; displayed as \(\operatorname{Adeq}_K\) |
| AN; AN-U | stake-margin axiom; uniform stake-margin axiom |
| firewall | account separation |
| dynamic seam conservativity | protected dynamic-trace conservativity |
| seam twins; world/procedure twins | record-seam-equivalent traces |
| record twins; flow twins | record-equivalent states; record-automorphism orbits |
| twin group | record automorphism group |
| certified-surplus cap | certified slack transfer bound |
| siege | recurrent complaint sequence |
| martyrdom | underfunding-triggered correct-target suspension |
| extortion | uncovered recurrent rent extraction |
| enforcement | covered and adequately funded repeated-complaint regime |
| Sybil splitting; Sybil resistance | index splitting; robustness to index splitting |
| Hume-bypass | reason-to-settlement bypass |
| No-Trader Principle | self-financing separation theorem |
| Moving-Book Obstruction | moving-region gain obstruction |
| Public-Twin Extensionality | record extensionality |
| Authorized Surprise | prior-authorized correction theorem |
| Earlier-Authorized Correction Lemma | prior-authorized correction theorem |
| No Transfer Without Structure | local-change nonpropagation |
| No Ontology-Free Unique Transfer | extensional transfer underdetermination |
| Target--Remainder Theorem | target persistence and exact completion |
| No Neutral Staging | allocation nonuniqueness |
| No Universal Progress Scalar | no target-independent fraction order |
| No Realization from Recognition | recognition-without-service counterexample |
| No-Bypass | ontology noninterference and activation separation |
| Moving-Book liability | adverse reference-movement charge |
| Bounded Dogmatism | procedure stock deadline |
| haunting | persistence of an unaddressed defect |
| whitewashing | cumulative revision hidden by local comparisons |
| anti-Sybil / coalition firewall | coalition aggregation and index-splitting robustness |
| MAX compiler | maximum compiler |
| accrual compiler | independent-union/accrual compiler |
| PCMC | positive moving-correspondence interface |
| JCC | joint collateral compactness condition |
| LIC | logical induction criterion |
| E1 | fixed-world exploitation criterion |
| E2 | moving-plausible-world exploitation criterion |

## Semantic warnings

- Stock opportunity cost is not flow rent.
- Stock capacity is not flow wealth.
- Service completion is not terminal disposition.
- Authorization, solvency, and allocation priority are separate predicates.
- A proposal is not operative until activation.
- Record equivalence is always relative to a stated signature and equivariance condition.

