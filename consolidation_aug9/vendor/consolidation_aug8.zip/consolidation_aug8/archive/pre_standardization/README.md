# Consolidation, August 8

This folder is a self-contained statement and verification package for the retained mathematics of the `LI-plus-leverage` corpus as of 2026-08-08. It presents two connected lines neutrally: leverage and operative force; and finite challenge-based answerability. Their exact interface is shared public books, activation records, and fresh force admission. Contribution hierarchy is not fixed here.

## Folder map

- `THEORY_1_FOUNDATIONS.md` through `THEORY_6_PARAMETERIZED_ANSWERABILITY.md`: definitions, statements, proofs, counterexamples, and sharpness boundaries in dependency order.
- `GLOSSARY.md`: canonical vocabulary, notation, and the exhaustive old-to-new name table.
- `LEDGER.md`: one row for every formal monograph claim, with hypotheses, status, provenance, sharpness, and verification.
- `VERIFICATION.md`: trust audit, executable coverage, and Lean scope.
- `FOR_HUMANS.md`: standalone plain-language account.
- `INTERPRETATION.md`: non-authoritative readings and design commentary.
- `OPEN_PROBLEMS.md`: mathematical frontiers and author-reserved decisions.
- `src/`, `tests/`: exact-rational Tier A and Tier B suite. Run `python3 tests/run.py` from this folder.
- `lean/`: vendored formal kernel and four new bounded formalization targets.
- `FROZEN_INPUT_CHECKSUMS.json`: SHA-256 records for consulted and vendored sources.
- `DEVIATIONS.md`: source problems and consolidation limitations.
- `DECISION_LEDGER.md`: every discretionary consolidation choice.

## Evidence discipline

Passing finite code is evidence for the displayed finite instances only. General theorems are supported by the complete rederivations in the monograph. The ledger uses only the mandated status vocabulary. Conditional statements list their conditions; refutations display their witnesses; open questions are not promoted.

## One-command verification

From this directory:

```sh
python3 tests/run.py
```

The runner executes both Python tiers, checks claim-ledger coverage and retired-name exclusion, and compiles both Lean files `sorry`-free. It uses the Mathlib checkout at `/Users/anson/AgentFoundations` by default; set `MATHLIB_DIR` to another Mathlib-enabled Lake project if needed. Mathlib is the only external mathematical dependency.

## Discard-test audit

The discard test passes for retained mathematical value. The six theory parts define every symbol and reprove every retained theorem; the ledger fixes status and provenance; exact computations and counterexamples are executable without repository imports; existing and new Lean source is vendored; and the checksum manifest freezes the evidence consulted. Deleting the rest of the repository would lose phase chronology, experimental process narration, superseded designs, and full original regression implementations, but no retained theorem, proof, decisive witness, exact number, status boundary, canonical definition, or open mathematical question. Tier B retains the long-tail numerical assertions rather than every historical implementation detail; that intentional distinction is recorded in `VERIFICATION.md` and does not alter mathematical content.

