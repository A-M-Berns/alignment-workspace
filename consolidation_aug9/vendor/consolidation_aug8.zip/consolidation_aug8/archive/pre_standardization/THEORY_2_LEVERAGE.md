# Part II. Leverage and finite constraint geometry

## 1. The leverage identity

Let \(A,R,B\subseteq\Omega\) and \(c_P,c_A,c_S\in[0,1]\). Define
\[
\delta_P=\mu(A)-c_P,\quad
\delta_A=\mu(A\cap R)-c_A\mu(A),
\]
\[
\delta_S=\mu(A\cap R\cap B)-c_S\mu(A\cap R),\quad
\delta_B=\mu(B)-\mu(A\cap R\cap B).
\]

**Leverage theorem.** {#C-LEV} **Status: PROVED+MACHINE-CHECKED.** If the four slacks are nonnegative, then
\[
\mu(B)\ge c_Pc_Ac_S,
\]
and exactly
\[
\mu(B)-c_Pc_Ac_S
=\delta_B+\delta_S+c_S\delta_A+c_Sc_A\delta_P. \tag{2.1}
\]
The coefficient is sharp for every \((c_P,c_A,c_S)\).

**Proof.** Substitute the definitions on the right of (2.1) and cancel. Each remaining term is nonnegative. For sharpness, use four atoms with masses
\[
c_Pc_Ac_S,\quad c_Pc_A(1-c_S),\quad c_P(1-c_A),\quad 1-c_P
\]
on \(A\cap R\cap B,A\cap R\cap B^c,A\cap R^c,A^c\), and take \(B=A\cap R\cap B\). All slacks vanish. \(\square\)

Deleting any lower-bound premise permits its corresponding factor to fall to zero, so all three premises are necessary for the stated product.

## 2. Certificate regions and sharp network bounds

**Finite certificate-region theorem.** {#C-CERT} **Status: PROVED+INDEPENDENTLY-REDERIVED.** A finite set of affine certificate rows cuts out a closed convex polytope in \(\Delta(\Omega)\). With rational coefficients, feasibility is decidable by exact rational linear programming, and every bounded rational linear objective attains a rational optimum at a rational vertex.

**Proof.** Each row is a closed halfspace. Their finite intersection with the compact simplex is closed, convex, and bounded. Rational elimination decides feasibility. A linear objective attains an optimum on a nonempty compact polytope; some vertex lies in its optimum face, and rational elimination gives rational vertex coordinates. \(\square\)

**Network leverage and dual certificate.** {#C-NETWORK} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Every warrant path gives a valid product lower bound by repeated application of the leverage theorem. The sharp global bound on target \(T\) is
\[
\min_{\mu}\ \mu(T)\quad\text{subject to }\mu\in\Delta(\Omega)\text{ and all active rows}.
\]
For a feasible instance, finite-dimensional strong duality supplies a finite linear certificate of the optimum. For an infeasible instance, Farkas' lemma supplies a finite contradiction certificate.

**Proof.** Induct along each path for validity. The preceding theorem supplies the primal rational polytope. Strong duality gives equal primal and dual optima; the infeasible alternative is Farkas' theorem. Overlapping paths can share constraints, so the minimum need not equal any single path product. \(\square\)

The fresh exact suite recomputes the four-atom instance \((3/4)(2/3)(4/5)=2/5\) and its matching primal and dual values.

## 3. Certified serviceability

Let \(P\subset\mathbb R^d\) be a nonempty rational polytope, \(a\in(0,1]\cap\mathbb Q\), and requested rows \(A_ip\le b_i\). Let \(r_i\ge0\) have positive rational weights \(w_i\), and let \(h_P(A_i)=\max_{z\in P}A_iz\).

**Core-certified relaxation theorem.** {#C-COMPILER} **Status: PROVED+INDEPENDENTLY-REDERIVED.** The program
\[
\min_{q\in P,r\ge0}\sum_iw_ir_i,
\qquad (1-a)A_iq+a h_P(A_i)\le b_i+r_i
\]
is a feasible rational linear program with a rational optimum. Its repaired region
\[
S=\{p\in P:A_ip\le b_i+r_i\ \forall i\}
\]
contains \(q+a(P-q)\).

**Proof.** Each support value is the rational optimum of a linear program. The displayed constraints are linear in \((q,r)\). Large relaxations give feasibility; compactness of \(P\), positivity of weights, and closedness give attainment; rational linear-programming theory gives a rational optimum. For \(z\in P\),
\[
A_i(q+a(z-q))=(1-a)A_iq+aA_iz\le(1-a)A_iq+ah_P(A_i)\le b_i+r_i.
\]
Thus every contracted point is in \(S\). \(\square\)

The optimizer need not be unique. For \(P=[0,1]\), \(a=1/2\), and requests \(p\ge3/4,p\le1/4\), every \(q\in[0,1]\) supports total relaxation one with \(r_L=3/4-q/2\), \(r_U=1/4+q/2\). A selection rule is therefore additional input.

For a box \(P=[0,1]^d\) with intervals \([l_j,u_j]\), a core of coefficient \(a\) exists exactly when each repaired interval has width at least \(a\). Minimum unweighted widening is \([a-(u_j-l_j)]_+\); for \(a<1\), references satisfy
\[
\frac{l'_j}{1-a}\le q_j\le\frac{u'_j-a}{1-a}.
\]

## 4. Self-financing separation

**Self-financing separation theorem.** {#C-SELF-FIN} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Let \(W=\{w_i\}_{i=1}^m\), let \(\mu_i>0\) sum to one, and quote forever \(p=\sum_i\mu_iw_i\). If an ordinary self-financing cumulative payoff satisfies \(G_N(w_j)\ge-B\) for every \(j,N\), then
\[
G_N(w_i)\le B\frac{1-\mu_i}{\mu_i}.
\]
This remains true if \(p\) violates an extra nonlogical row.

**Proof.** Each trade has zero \(\mu\)-expected payoff at \(p\), hence \(\sum_j\mu_jG_N(w_j)=0\). Therefore
\[
\mu_iG_N(w_i)=-\sum_{j\ne i}\mu_jG_N(w_j)\le B(1-\mu_i).
\]
Divide by full-support \(\mu_i\). \(\square\)

Full support is necessary: a zero-mass world can carry arbitrary gain without changing expectation. The theorem proves that an extra warrant row cannot in general be enforced by ordinary bounded-downside settlement trading alone.

## 5. Full-coupling conditioning boundary

Let finite nonempty sets \(X,Y\) have allowed marginal sets \(\varnothing\ne\mathcal E\subseteq\Delta(X)\) and \(\mathcal N\subseteq\Delta(Y)\). Let \(\mathcal J_{all}\) contain every joint distribution whose two marginals lie in those sets. For \(A\subseteq X\), let \(\mathcal N_A^+\) be the set of conditional \(Y\)-distributions given \(A\), omitting joints with zero probability for \(A\).

**Full-coupling non-contraction.** {#C-COUP-NC} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If some \(e_0\in\mathcal E\) has \(e_0(A)>0\), then \(\mathcal N\subseteq\mathcal N_A^+\). The containment may be strict.

**Proof.** For each \(n\in\mathcal N\), the independent product \(e_0\otimes n\) is in \(\mathcal J_{all}\), and its conditional \(Y\)-distribution given \(A\) is exactly \(n\). For strictness, take binary \(X,Y\), both allowed marginal sets equal to the singleton one-half, and write \(\theta=P(A\cap B)\in[0,1/2]\). Then \(P(B\mid A)=2\theta\) ranges over \([0,1]\). \(\square\)

**Full-coupling posterior characterization.** {#C-COUP-CHAR} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Put \(\mathcal A=\{e(A):e\in\mathcal E,e(A)>0\}\). A distribution \(m\in\Delta(Y)\) belongs to \(\mathcal N_A^+\) exactly when there are \(\alpha\in\mathcal A\) and \(n\in\mathcal N\) such that either \(\alpha=1\) and \(m=n\), or \(0<\alpha<1\) and \(\alpha m(y)\le n(y)\) for every \(y\). Equivalently, \(n=\alpha m+(1-\alpha)m'\) for some \(m'\in\Delta(Y)\).

**Proof.** Any admissible joint obeys total probability with \(m'\) its conditional distribution on \(A^c\), proving necessity. Conversely, coordinatewise domination makes \(m'=(n-\alpha m)/(1-\alpha)\) nonnegative with coordinates summing to one. Choose \(e\in\mathcal E\) with \(e(A)=\alpha\), use conditional distribution \(m\) on \(A\) and \(m'\) on \(A^c\), and obtain a joint with marginal \(n\) and posterior \(m\). The \(\alpha=1\) case is immediate. \(\square\)

The positive-probability hypothesis is necessary for ordinary conditioning. Equality rather than non-contraction requires \(\mathcal N\) to be closed under every displayed component operation; the binary witness shows it is not automatic.
