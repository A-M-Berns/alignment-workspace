# Part V. Finite challenge semantics and construction

The following are exactly the retained claims whose truth value or mathematical content changes with pricing semantics; claims unchanged across the translation remain tagged only in the ledger.

| Claim family | Stock semantics | Flow semantics |
|---|---|---|
| deadline | C-STOCK-DEADLINE gives the capacity deadline \(\min\{k:R(k)\ge C^{ans}\}\) | C-FLOW-EXHAUST is the run-relative first strict funding failure; matched inflow can make the failure set empty |
| persistent false exposure | C-STOCK-FALSE permits indefinite repetition with replenishment and released locks | C-FLOW-FALSE forces disposition on a finite unreplenished account because paid stake and rent are cumulative outflow |
| bare and repaired bridge | C-BARE-BRIDGE is false; C-BRIDGE requires operational adequacy and bounded net outflow | the bare bridge remains false; the repaired bridge reads adequacy through paid obligations and atomic pre-debit triggers |
| concurrency requirement | C-STOCK-CONCUR bounds simultaneously required lock | flow concurrency enters an exact peak-outflow endowment and is not obtained by substituting wealth for stock capacity |
| account interaction | no stock analogue follows from lock capacity alone | C-CROSS-EFFECT gives the exact balance interval on which pooling changes an atomic payment outcome |
| record symmetry | C-STOCK-GAUGE preserves the stock transition signature | C-FLOW-GAUGE holds only after balances, recipients, transfers, and payment outcomes are added to the preserved signature |
| construction | C-STOCK-CONSTRUCT uses a sufficient lock-capacity bound and bounded-net-outflow bridge | the parameterized flow construction uses exact fenced peak outflows, pre-debit triggers, and literal per-period transfers |

## 1. Stock semantics

Write \(R(k)=\sum_{j=1}^kr(j)\). A standing procedure challenge of age \(k\) requires lock \(s^{ch}+R(k)\) against capacity \(C^{ans}\). Its disposition is answer, authorized revision, or suspension.

**Procedure stock deadline.** {#C-STOCK-DEADLINE} **Status: PROVED+INDEPENDENTLY-REDERIVED.** An unanswered admitted procedure challenge reaches a terminal disposition by
\[
T=\min\{k:R(k)\ge C^{ans}\};
\]
for constant \(r(k)=\gamma_{rent}\), \(T=\lceil C^{ans}/\gamma_{rent}\rceil\).

**Proof.** Before that date the required stock is below capacity. At the first date it reaches capacity, the transition rule cannot retain the unanswered active challenge and must take one of the three terminal branches. Constant rent gives \(R(k)=k\gamma_{rent}\), whose least qualifying integer is the ceiling. \(\square\)

**Same-day stock bound.** {#C-STOCK-CONCUR} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If admitted stakes are at most \(\bar s\) and the token door admits at most \(Q\) simultaneous new challenges, same-day required lock is at most \(Q\bar s\), plus the declared aged locks already present.

**Proof.** Add the at most \(Q\) independent stake requirements and the existing requirements. The exact instance \(Q=2,\bar s=1/4\) locks \(1/2\). \(\square\)

In particular, the retained unexposed one-half-floor seed book is contentful and stock-solvent at capacity one against the declared admission class, because its maximum same-day lock is one-half.

**Persistent false-floor stock counterexample.** {#C-STOCK-FALSE} **Status: REFUTED (witness displayed).** Stock solvency alone does not force revision of a false exposed floor. With \(c=1/2,f=0,s^{ch}=1/4,C^{ans}=1,\gamma_{rent}=1/4\), external replenishment can pay every completed world challenge while world mode locks only stake; after \(N\) matches the paid loss is \(N/4\), yet the floor remains active.

**Proof.** Each match is admitted within capacity, settled, and replenished before the next. No stock rule accumulates the paid losses into a prohibition, and each lock is released at settlement. Thus the trace extends for every \(N\). \(\square\)

Adding a bounded-net-outflow condition and forbidding poststationary suspension supplies the missing financial premise.

**Bare stock bridge failure.** {#C-BARE-BRIDGE} **Status: REFUTED (witness displayed).** Stock answerability-solvency does not imply exposed correctness, and exposed correctness alone does not supply a nonvacuous converse without an operational test guarantee.

**Proof.** The persistent false-floor trace is stock-solvent and not exposed-correct, refuting the forward implication. In the reverse direction, a capacity invariant can prevent the challenge needed to test the claimed response, so the implication is vacuous until a recurrent adequate testing class is named. \(\square\)

**Public-record conjugacy.** {#C-STOCK-GAUGE} **Status: PROVED+INDEPENDENTLY-REDERIVED.** A sort-preserving bijection of identifiers that preserves all public fields conjugates every stock transition and observable defined equivariantly from them.

**Proof.** Induct on dates. Each guard is an equality, order, membership, or rational comparison preserved by the bijection; each update applies the same constructor to renamed fields. Therefore the next states correspond, and so do equivariant observables. \(\square\)

## 2. The terminal learning bridge

Call a run **exposed-answerable after stationarity** when, after its last book change, every persistent admissible exposed challenge is answered or repaired without suspension caused by book-controlled silence, and every persistent false exposed floor is revised or suspended for an evidential reason. Call a policy **terminally answerable-learning relative to a challenger class** when every eventually stationary run has that property and the terminal book meets the declared truth and repair clauses. These are descriptive placeholders; their final names are author-reserved.

Operational adequacy consists of bounded stake, the token envelope, work-conserving service, and a latency/capacity comparison sufficient to admit and service the required tests.

**Adequacy is necessary.** {#C-BRIDGE-FAIL} **Status: REFUTED (witness displayed).** Without operational adequacy, the bare terminal bridge is false. A true floor with \(c=1/2,f=1,M=5,s^{ch}=1/4,C^{ans}=1,\gamma_{rent}=1/2\) can be suspended at effective age two because resource competition prevents timely service.

**Proof.** The standing lock reaches capacity at age two by the deadline formula. The book is true, so the suspension records resource failure rather than a false floor. Hence terminal truth does not imply exposed answerability without adequacy. \(\square\)

**Relativized terminal biconditional.** {#C-BRIDGE} **Status: PROVED+INDEPENDENTLY-REDERIVED.** On eventually stationary finite runs satisfying operational adequacy and the bounded-net-outflow condition, terminally answerable-learning relative to the persistent testing class holds if and only if the terminal book is exposed-answerable after stationarity.

**Proof.** Forward direction is the criterion's terminal clause. Conversely, adequacy eventually services every persistent test; bounded net outflow rules out indefinite paid false exposure; and the no-poststationary-suspension clause excludes satisfying the criterion by silence-triggered suspension. The assumed terminal condition supplies answers or authorized repairs, so every criterion clause holds. \(\square\)

## 3. Addressing, drift, and convergence

**Persistent addressing.** {#C-ADDRESS} **Status: PROVED+INDEPENDENTLY-REDERIVED.** A valid repair of a challenged floor must weaken to at most the challenged truth frequency, or retain an explicit unresolved successor burden. Thus \(3/4\to1/2\) addresses a frequency-\(1/2\) defect, while \(3/4\to2/3\) does not discharge it.

**Proof.** The address predicate compares the successor floor with the checked frequency. The first satisfies the comparison; the second exceeds it. If the comparison fails, the burden-preservation branch retains the defect key. \(\square\)

**Frozen-origin drift bound.** {#C-DRIFT} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If each authorized revision stores its displacement from the original version, cumulative change cannot be hidden by locally small steps: an origin-relative cap is crossed at the first prefix whose total displacement exceeds it. The exact sequence \(1/4,3/8,1/2,5/8,3/4\) has four local moves of \(1/8\) but total origin displacement \(1/2\).

**Proof.** The stored origin is constant, so the last displacement is \(3/4-1/4=1/2\), independent of intermediate partition. \(\square\)

**Leverage-chain calibration.** {#C-CHAIN-CAL} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Conjunction rows implement a three-level warrant chain with bound \((4/5)(3/4)(2/3)=2/5\). The displayed stock implementation needs lock \(9/4<3\) and cost \(3/2\); the general declared response-cost term is \(bd\kappa\), and the flow reserve specialization is \(55/32\).

**Proof.** Apply the leverage theorem to the three conjunction events. The remaining numbers are direct sums of the declared exact rational obligations, recomputed by the suite. \(\square\)

**Bounded-outflow exposed convergence.** {#C-EXPOSED-CONV} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Under recurrent settlement tests, if each completed false-floor loss costs at least \(e>0\) and cumulative net outflow is at most \(B_O\), a false exposed floor survives at most \(\lfloor B_O/e\rfloor\) completed loss rounds and must be revised or inactive by the next.

**Proof.** After \(m\) completed losses, net outflow is at least \(me\). If \(m>\lfloor B_O/e\rfloor\), then \(me>B_O\), contradicting the bound. Thus the next qualifying test cannot close against the same active false floor. \(\square\)

**Finite repair consumption implies stabilization.** {#C-CONSUME} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If every accepted repair strictly decreases a nonnegative integer potential \(\Psi\), there are at most \(B_R=\Psi(K_0)\) active-book transitions. If \(\mathcal B\) is the finite book-status set and each tracked status changes at most once within an era, total active-book status changes are at most \(B_R+(B_R+1)|\mathcal B|\).

**Proof.** A strictly decreasing sequence of nonnegative integers starting at \(B_R\) has at most \(B_R\) steps and therefore at most \(B_R+1\) eras. Each transition contributes once; within each era every tracked book status changes at most once under the consuming status rule, giving the displayed sum. \(\square\)

**Reusable-route cycle.** {#C-REVISION-CYCLE} **Status: REFUTED (witness displayed).** Without route consumption, two earlier-authorized addressing routes can alternate \(1/3\leftrightarrow2/3\) forever.

**Proof.** Apply the upward route at \(1/3\) and the downward route at \(2/3\), restoring the other route's source state each time. Both local address checks pass and the cycle repeats. \(\square\)

**Cesàro stabilization failure.** {#C-CESARO} **Status: REFUTED (witness displayed).** Alternating zero and one in blocks with \(L_{k+1}=(k+1)S_k\), where \(S_k\) is all earlier length, gives occupation-average subsequences converging to zero and one.

**Proof.** At the end of a new block, its length is \((k+1)\) times all prior length, so the fraction occupied by its value is at least \((k+1)/(k+2)\), tending to one. Alternating block values gives the two subsequences. \(\square\)

**Missing-route obstruction.** {#C-NO-ROUTE} **Status: REFUTED (witness displayed).** A finite kernel with a false persistent floor and no authorized route that answers, weakens, or suspends it admits no universal terminally answerable-learning policy that respects authorization.

**Proof.** Persistent testing exposes the false floor. The policy cannot change it without an authorized edge and cannot leave it while meeting the terminal criterion. Both allowed choices fail. Adding one valid route removes this obstruction, giving the exact minus-one/plus-one calibration. \(\square\)

## 4. Restricted stock construction

Let syntactic authorized repair coverage mean that every reachable admissible defect has a finite checked route path whose edges strictly consume \(\Psi\). Let \(B_R=\Psi(K_0)\), \(J_W\) be world-match concurrency, \(e(\cdot)\) the world lock function, \(b,d,\kappa,c_R\) the declared finite construction parameters, and \(M\) the finite settlement bound.

**Finite repair-certificate theorem.** {#C-REPAIR-CERT} **Status: PROVED+INDEPENDENTLY-REDERIVED.** In a finite exact route graph, syntactic authorized repair coverage is decidable and implies semantic coverage of every graph-reachable state represented by the certificate.

**Proof.** Enumerate the finite state/defect pairs and run finite graph reachability while checking each edge's authorization, address, account, cost, and strict potential decrease. A certified path is a sequence of actual transition edges; induction on path length proves the semantic endpoint is reachable and the defect answered or repaired. Exhaustive enumeration proves the implication for every represented reachable pair. \(\square\)

The no-route one-state graph fails. Adding one authorized one-token suspension edge makes the same graph pass, which is the sharp plus/minus-one-route witness.

**Restricted stock construction.** {#C-STOCK-CONSTRUCT} **Status: PROVED-CONDITIONAL (conditions listed).** The lexicographic policy that scans exposed inconsistency and past defects, follows checked routes serially, and services finite FIFO world matches is computable, changes books at most \(B_R\) times, and satisfies the terminal criterion. A sufficient total stock bound is
\[
J_We(F_0+bB_R)+B_Rc_R+b(B_R+1)d\kappa.
\]

**Proof.** Every scan, route check, and queue operation is finite. Each route firing decreases \(\Psi\), proving the transition bound. Serialization ensures every edge is checked against the state it changes. The three displayed terms separately cover world matches, once-only route work, and worst-case reference movement over at most \(B_R+1\) eras. Operational adequacy services every admitted persistent test. After the last transition, syntactic coverage supplies either a checked answer or a route for every remaining defect; the missing-route obstruction cannot occur. The terminal bridge then gives the criterion. \(\square\)

Coverage is sufficient, not inferred from semantic correctness. The construction is finite-kernel and does not extend to an infinite language.

## 5. Flow semantics

Let \(F_0\) be an account's initial balance and \(I(k)\) cumulative inflow credited before its first \(k\) rent obligations.

**Exact flow exhaustion time.** {#C-FLOW-EXHAUST} **Status: PROVED+MACHINE-CHECKED.** The first unpaid rent is
\[
T=\min\{k:R(k)>F_0+I(k)\}. \tag{5.1}
\]
If the set is empty there is no funding trigger. With zero inflow and constant rent \(\gamma_{rent}\),
\[
T=\lfloor F_0/\gamma_{rent}\rfloor+1.
\]

**Proof.** Define \(P(k)\) by \(R(k)>F_0+I(k)\). Atomic payment succeeds through obligation \(k\) exactly when \(P(k)\) is false. If \(P\) is inhabited, well-ordering of \(\mathbb N\) gives a least \(T\), with \(P(T)\) and \(\neg P(j)\) for every \(j<T\); if it is empty, every obligation is payable. For zero inflow and constant positive rent, let \(m=\lfloor F_0/\gamma_{rent}\rfloor\). Then
\[
m\gamma_{rent}\le F_0<(m+1)\gamma_{rent},
\]
so every \(k\le m\) is payable and \(m+1\) is the least failure. These leastness and floor steps, and the emptiness result for \(I=R\), are formalized in the compiled kernel. \(\square\)

Matched inflow \(I(k)=R(k)\) defeats every deadline depending only on \(F_0\) and kernel parameters.

**Flow fate of persistent false exposure.** {#C-FLOW-FALSE} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Each completed world challenge against a false exposed floor costs the book \(s^{ch}+R(m)>0\). Recurrent pure testing therefore forces revision or suspension after at most \(\lfloor F_0/(s^{ch}+R(m))\rfloor+1\) such losses on a finite unreplenished account.

**Proof.** Stake is forfeited and rent is nonrefundable on each completed loss. Add the identical positive outflows and apply atomic insolvency. \(\square\)

**Account cross-effect witness.** {#C-CROSS-EFFECT} **Status: REFUTED (witness displayed).** With an earlier world obligation \(a_W\) and next procedure obligation \(a_P\), pooling changes the protected procedure trace exactly for balances
\[
a_W\le F<a_W+a_P,
\]
provided the no-world-loss comparison can pay \(a_P\).

**Proof.** Below \(a_W\), the first obligation triggers before debit. At or above the sum, both are paid. In the intermediate interval, the world debit succeeds and leaves less than \(a_P\), while its comparison twin retains enough. \(\square\)

The canonical values are \(a_W=1,a_P=1/4\), so the interval is \([1,5/4)\).

**Flow record conjugacy.** {#C-FLOW-GAUGE} **Status: PROVED+INDEPENDENTLY-REDERIVED.** The stock conjugacy proof extends when balances, rent recipients, transfer entries, and atomic payment outcomes are included among preserved fields.

**Proof.** These new guards and updates are rational equalities and comparisons, preserved by a sort-respecting record automorphism. The date induction is unchanged. \(\square\)
