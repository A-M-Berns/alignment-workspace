# Interpretive material

**Non-authoritative.** Nothing in the theory, ledger, tests, or Lean files depends on this document. These readings do not add hypotheses or conclusions.

## Institutional readings

The leverage line can be read as a model of sourced commitments whose consequences become constraints on permissible confidence. In a legal setting, a warrant resembles a defeasible rule connecting a predicate to a consequence; in a securities setting, it resembles a public methodology that constrains valuation; in governance, it resembles an adopted reason that remains challengeable by provenance and scope. The mathematics does not decide which commitments deserve authority.

The certified core and variational inequality can be read as an underwriting interface. A constrained quote remains responsive to aggregate demand while a checkable inner copy of the plausible region prevents the service set from becoming arbitrarily thin. The operative-force bound then states the largest worldwise exposure implied by tolerance, downside budgets, and adverse movement of the reference. The scalar “lock” is a promise allowance, not automatically a literal asset, reserve, or regulatory capital measure.

The answerability line can be read as an optimistic verification protocol. A challenger posts stake; a book either answers, changes, or loses the ability to keep the target active. Stock semantics represents the opportunity cost of unresolved obligations. Flow semantics instead pays the challenger period by period. The latter makes silence a literal expense and exposes liquidity interactions between accounts.

Account separation resembles segregation between clearing pools or restricted funds. Its theorem is narrower than a general policy endorsement: pooling helps aggregate solvency but can transmit one component's outcome into another component's suspension decision. The exact safe-policy theorem concerns preservation of protected funding decisions, not whether transfers are legally or ethically appropriate.

## Design commentary

Several distinctions are deliberate. Authorization does not follow from solvency. Scarcity does not select priority. A proposal does not activate itself. Service completion does not prove substantive adequacy. A source summary does not preserve individual identity unless the source map remains checkable. These separations make failure locations visible.

The finite-kernel boundary is both a strength and a limitation. It makes repair coverage, route consumption, exact rational funding, and exhaustive finite witnesses checkable. It does not solve open-ended language growth or arbitrary self-redefinition. The family theorem on growing key counts warns that even a sequence of finite systems loses a uniform funding bound when correct repair-only keys proliferate at a fixed positive rent.

The positive repair-rent result is intentionally adverse. Correct complaints that cause revision earn positive rent. This buys a form of participation but creates bounded enforcement cost. Setting that payment to zero does not break the formal queue theorem, showing that “every enumerated filing is eventually served” is different from “an informed person chooses to file.” A real incentive theorem needs preferences, information, and outside options.

## Legacy metaphors

The retired term “firewall” evoked isolation between world and procedure funding; canonical mathematics now says account separation or protected dynamic-trace conservativity. “Siege” referred to recurrent complaints; its old three-way labels “enforcement,” “martyrdom,” and “extortion” are now the covered-and-funded regime, underfunding-triggered correct-target suspension, and uncovered recurrent rent extraction. “Record twins” meant states in one orbit of a public-record symmetry. “Sybil splitting” meant distributing one behavior across many enumerated indices. “Moving-Book” referred to exploitation caused by repeated crossings of changing permitted regions. “No-Trader” emphasized that ordinary self-financing settlement trades cannot enforce arbitrary nonlogical constraints. “Authorized Surprise” emphasized that an earlier route may license an endpoint not predicted in advance. These aliases remain useful for historical search but are not canonical names.

The older phrase “Hume-bypass” gestured at an illicit jump from a reason constraint to ordinary settlement force. The canonical self-financing separation theorem gives the precise mathematical obstruction: zero expected value at a full-support coherent quote bounds every world payoff of a bounded-downside self-financing strategy, even if the quote violates the extra reason constraint.

## Philosophical positioning

The corpus supplies a theory of public, finite, revisable reason constraints and the costs of making them operative. It is not a theory of truth, moral correctness, natural-language understanding, ideal governance, or complete rational agency. The leverage theorem tells how nested commitments combine; it does not justify the commitments. The learning criterion tracks response to challenges under declared routes; it does not guarantee that the route itself is good. Record symmetry identifies what a public procedure cannot distinguish; it does not show that the hidden difference is unimportant.

The strongest unifying thought is procedural: reasons can be represented, their geometric consequences certified, their operative exposure bounded, their revisions recorded, and their unresolved defects made costly. Whether that is best presented as one theory or as two connected theories is deliberately left to the author.

