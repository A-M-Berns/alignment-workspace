# Open problems and reserved decisions

No item here is a proved claim.

## Ranked mathematical problems

1. **Joint force-channel composition.** Define one public-history transition system joining constrained quote selection to flow answerability, with noninterference before activation, no double charging, compatible suspension/refusal, and preservation of both the operative-force wealth bound and the uniform finite-kernel construction under projection.
2. **Voluntary repair-rent mechanism.** Extend the model with challenger information, values, filing costs, outside options, and an equilibrium or incentive notion. Determine whether one budget-balanced rule can ensure participation on every correct persistent defect, negative payoff for nuisance filings, bounded book loss, and local-finite work-conserving finite-overtaking admission. Phase XI supplies evidence on both sides but no full impossibility.
3. **Computable tight endowment certificates.** Compute reachable-key and false-match bounds without exhaustive run enumeration. On the displayed finite kernel the target is to recover one canonical key and two false matches rather than coarse counts thirty-two and twenty.
4. **Exact predecessor of the adverse movement formula.** Search at theorem level for prior work matching the repaired exposure-weighted, positive-part, post-trade reference-movement formula.
5. **Answerability precedence.** Compare bonded challenge, optimistic verification, deposit, costly argumentation, griefing-ratio, fair admission, and logical-induction trader-universality results to the exact stock/flow theorems.
6. **Focused system formalization.** Extend Lean coverage from the isolated algebra to the finite vector wealth theorem, atomic flow evaluator, exact stock/flow witness, and path-sensitive endowment characterization.

## Phase XI frontiers

- Characterize efficiently computable exact peak endowment for nontrivial challenger classes.
- Determine useful necessary conditions for peak synchronization weaker than uniform-delay closure; exact synchronization itself is already characterized.
- Classify safe nonzero transfer policies on restricted trace classes beyond a fixed horizon without assuming all-balance record-seam richness.
- Characterize compiler extreme points under additional natural axioms stronger than monotonicity and maximum domination.
- Determine which non-equivariant name conventions, if any, are substantively admissible; the mathematics only identifies their symmetry cost.
- Establish mechanism-level participation results only after the missing behavioral primitives are fixed.
- Do not construct an infinite kernel. The only retained unbounded-key result is a family theorem over finite kernels.

## Earlier retained frontiers

- Nonstationary, expanding-language service has no analogue of the stationary decomposition theorem.
- The positive moving-correspondence interface lacks a complete effective constrained-history construction and Lean integration.
- General weighted variable-core bounds for oscillating core strengths need a direct weighted downside premise or a new proof idea.
- Open-ended feature discovery and semantic alias detection are outside the finite version-space theorem.
- Fair staged allocation is not determined by feasibility; additional policy axioms remain to be studied.
- Typed semantics-preserving self-modification needs a version relation transporting fixed-transition proofs.

## Author-reserved decisions

- **Two-line seam and flagship hierarchy:** whether the leverage/operative-force and answerability lines form one theory or two connected theories, and which result is flagship.
- **Past-self rent recipient:** public verification account or burn. All mathematics remains parametric in the recipient.
- **Cross-component transfer as a conduct defect:** whether an invalid transfer becomes an independently challengeable defect. Prevention and transfer theorems do not assume it.
- **Certified slack transfer bound:** whether to adopt the fixed-horizon outgoing cap as policy. It is a theorem about safety, not an adopted rule.
- **Criterion names:** final names for the terminally answerable-learning criterion and terminal-book coverage condition.
- **Subsidy schedule:** retained per-index schedule versus proposed per-provenance schedule. The latter requires provenance detection.

