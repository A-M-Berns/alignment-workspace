# Part VI. Parameterized finite-kernel answerability

## 1. Kernel and challenger classes

Let \(\mathfrak K\) be the class of finite flow kernels. An element \(K\) encodes a finite language, schema and version tables, five-field defect table, route graph with nonreplenishing token vector and integer potential \(\Psi\), finite semantic-key set, finite meta-depth, token envelope, service rules, bounded latencies, rational stakes and costs, positive rational rent schedule \(r_K(k)\), atomic payment/insolvency transition, canonical world settlement, account assignment, and the stake-margin axiom
\[
s^{ch}>R_K(D),\qquad R_K(q)=\sum_{j=1}^qr_K(j).
\]
Put \(B_R=\Psi(K_0)\). Nonempty targets, complaints, and repair-only keys are not implicit.

Named challenger properties are:

- **pure-run closure:** every named filing strategy occurs without unrelated receipt before disposition;
- **persistent-filer closure:** every persistent admissible key has a recurrent pure filer;
- **settlement-test closure:** every persistent exposed floor has a recurrent pure bounded-stake tester;
- **coalition closure:** colluding indices are aggregated for provenance, tokens, and canonical work;
- **enumeration closure:** every computable strategy over the fixed instrument set is enumerated;
- **uniform-delay closure:** delaying every filing by an integer preserves membership;
- **component composition:** disjoint account-local traces can be composed;
- **peak synchronization:** any tuple of attained account-local peaks occurs simultaneously on a composed trace;
- **local finiteness:** finitely many filings become eligible at each finite date;
- **work conservation:** a nonsuspended positive-capacity door services pending eligible work;
- **finite overtaking:** after filing \(x\) becomes eligible, only finitely many later-eligible filings are admitted first;
- **record-seam richness:** the class contains disjoint world/procedure comparison traces and arbitrarily small rational funding slack.

Authorized repair coverage means that named admissible defect keys have checked finite answer or repair paths. Account assignment requires every path edge and canonical answer to name its account before admission. The **terminal-book coverage condition** is the same requirement restricted to unresolved keys at the final active book. Its eventual canonical name is author-reserved.

## 2. Uniform construction and exact funding

Let \(q_K\) be the exact sum of once-only selected route and canonical-answer costs, \(N_{match}\) the exact bound on matches against false not-yet-repair-pending versions, and
\[
\operatorname{Adeq}_K(n_P,D_P,J_W,D_W,K_*,b,B_R,d,N_{match})=
\begin{cases}
P_*=K_*+n_PR_K(D_P),\\
W_*=N_{match}(\bar s+R_K(D_W))+J_WR_K(D_W).
\end{cases} \tag{6.1}
\]
One may take \(K_*=q_K\), or the coarse \(B_Rc_R+b(B_R+1)d\kappa\).

The uniform policy fixes public total orders on schemas, semantic keys, and route identifiers. On each date it performs the following finite transition cycle: settle each due world contract as one atomic match-plus-rent obligation; pay standing rents by immutable challenge identifier from the account stamped at admission, triggering before debit on a shortfall; continue the unique serialized service or repair transaction; if none is active, scan every exposed floor and every semantic key constructible from the finite public snapshots; publish each missing checker-accepted canonical answer and charge its declared procedure cost; otherwise choose the least unresolved defect with exposed inconsistency first, verify that the procedure balance covers the whole selected path plus \(n_PR_K(D_P)\), reserve its nonreplenishing route tokens, mark the target repair-pending, and release the serialized work; when no repair is pending, fill freed world slots FIFO; admit eligible challenges in date-major order and stamp each world or procedure account before admission; perform no unlicensed mutation and no cross-account transfer. All checkers and scans are finite and all comparisons rational.

**Uniform finite-kernel construction.** {#C-GP1} **Status: PROVED+INDEPENDENTLY-REDERIVED.** For every \(K\in\mathfrak K\), authorized start with valid repair certificate, account assignment, latency gate, and balances satisfying (6.1), a uniform finite-code transform produces a computable policy. Under pure-run, persistent-filer, settlement-test, and coalition closure it satisfies the flow terminal learning criterion, changes active books at most \(B_R\) times, and is uniform in the reserved recipient parameter. Under enumeration closure, local finiteness, work conservation, finite overtaking, and global admissions \(A\), the conclusion extends to the enumerated ecology with \(n_P^{\mathcal E}=AD_P\).

**Proof.** The proof separates into the following finite claims.

1. **Computability.** Every scan ranges over a finite language, key table, route table, or queue, and every guard is a decidable rational comparison; hence the displayed cycle is a total computable function of the public prefix.
2. **Transition count.** If the selected repair states are \(K_0,K_1,\ldots,K_m\), then \(\Psi(K_{i+1})<\Psi(K_i)\) and \(\Psi\ge0\), so \(m\le\Psi(K_0)=B_R\).
3. **Procedure funding.** At every prefix, procedure outflow decomposes into once-only selected work, bounded by \(K_*\), and at most \(n_P\) simultaneous rent streams of age at most \(D_P\), bounded by \(n_PR_K(D_P)\). Thus it is at most \(P_*\), and the pre-release reserve test prevents a procedure trigger.
4. **World funding.** Before repair-pending status, at most \(N_{match}\) false-version matches each cost \(\bar s+R_K(D_W)\); afterward at most \(J_W\) terminal streams each cost \(R_K(D_W)\). Their sum is \(W_*\), so the world account also pays every declared construction obligation.
5. **Terminal clauses.** By claim 2 there is a last consuming transition. Persistent-filer and settlement-test closure expose every persistent procedure defect and false exposed floor on pure traces. Authorized coverage supplies a checked answer or a consuming repair, while coalition closure identifies duplicate provenance before tokens, work, and match counts are charged. Hence no covered persistent defect survives after the last consuming transition. On a defect-free answerable tail, \(s^{ch}>R_K(D)\) makes each tested false assertion lose more stake than the rent it pays.
6. **Ecology extension.** For any filing, local finiteness gives finitely many same-date predecessors and finite overtaking gives finitely many later-date predecessors. Work conservation consumes this finite predecessor set and then admits the filing. At most \(A\) admissions at each of the preceding \(D_P\) dates can remain live, so \(n_P^{\mathcal E}=AD_P\).

Claims 3 and 4 establish (6.1), and claim 5 establishes the terminal learning criterion. None of the six claims uses the identity of the reserved recipient. \(\square\)

**Sharpness.** Dropping terminal coverage gives the missing-route obstruction; dropping the latency gate permits a due obligation before service; dropping the reserve bound gives atomic insolvency; dropping finite overtaking permits index-priority starvation. Account separation is not required for solvency, only for cross-component trace conservativity.

For account partition \(\mathcal A\) and run \(\omega\), let \(O_a^\omega(t)\) be cumulative net outflow and define
\[
F_{min}(K,\mathcal C,\mathcal A)=\sum_{a\in\mathcal A}\sup_{\omega\in\mathcal C,t}O_a^\omega(t). \tag{6.2}
\]

**Exact endowment functional and gap frontier.** {#C-GP2} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If peaks are attained, (6.2) is the exact least fenced endowment; otherwise it is the infimum. A path-sensitive sufficient bound is (6.1) with \(K_*=q_K\) and exact \(N_{match}\). Every account admitting a pure challenge whose first receipt cannot precede first rent satisfies
\[
F_{min,a}\ge r_K(1)>0. \tag{6.3}
\]
No parameter-independent finite bound on \(F_{suf}/F_{nec}\) follows from the coarse tuple. On the saturated constant-rent subclass with
\[
n_P=\left\lfloor\frac{\rho_a(D_P+1)+\beta_P}{w_{min}}\right\rfloor
\]
and a simultaneous repair-only burst with no stake income,
\[
F_{min,P}\ge n_P\gamma_{rent}D_P=\Theta(D_P^2),
\]
with a matching quadratic upper term. A one-complaint class is only linear.

**Proof.** Fix an account \(a\). If \(F_a\ge\sup_{\omega,t}O_a^\omega(t)\), then before every atomic debit its cumulative outflow is at most \(F_a\), so no protected obligation triggers. If \(F_a\) is smaller, either an attained peak or a prefix arbitrarily close to the supremum exceeds it, proving necessity or the infimum statement. Fencing makes these account inequalities independent, so their least total is the sum in (6.2).

On a pure first-rent trace, no earlier receipt offsets \(r_K(1)\), whence \(F_{min,a}\ge r_K(1)\). For the coarse-gap claim, adjoining unreachable keys increases coarse counting terms while leaving every \(O_a^\omega(t)\), hence (6.2), unchanged. Finally saturation gives \(n_P=\Theta(D_P)\); a simultaneous repair-only burst contributes \(n_P\) streams each paying \(\gamma_{rent}D_P\), so the lower bound is \(\Theta(D_P^2)\). The construction reserve has the same product. With concurrency fixed at one, the same expression is only \(\gamma_{rent}D_P\), proving that saturation is necessary for the class-wide quadratic conclusion. \(\square\)

**Sharpness.** Equality at \(r_K(1)\) funds the first rent. Without a pure first-rent trace, an earlier receipt can eliminate the lower bound. Without saturation, quadratic dependence is false.

The displayed finite specialization is
\[
(P_{suf},W_{suf})=(79/32,31/8),\quad(P_{min},W_{min})=(17/32,1/2),
\]
so \(F_{min}=33/32\); one rent unit \(1/64\) less fails in either account.

## 3. Terminal coverage and admission fairness

**Terminal-book biconditional.** {#C-GP3} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Fix the construction, pure-run, persistent-filer, settlement-test, coalition closure, the latency gate, stake margin, consuming repairs, and reserves for once-only work and every uncovered transient complaint. Add the four ecology hypotheses when applicable. Then the flow terminal learning criterion holds if and only if every unresolved terminal-book key has authorized repair coverage. One transient era costs at most \(n_P^{\mathcal E}R_K(D_P)\); at most \(B_R\) eras are transient, so their coarse reserve is \(B_Rn_P^{\mathcal E}R_K(D_P)\). Charging the terminal era before tail receipts gives the safe \((B_R+1)\) version.

**Proof.** There are at most \(B_R\) consuming transitions, hence a last transition time \(\tau\). Assume terminal coverage. Every omission before \(\tau\) is transient and is paid from the declared transient reserve. After \(\tau\), every unresolved key belongs to the terminal book; coverage supplies its checked answer or consuming route. A consuming route would contradict the choice of \(\tau\), so the uniform construction closes every persistent terminal key without another book change. The terminal learning clauses follow.

Conversely, let \(x\) be an unresolved uncovered terminal key. Persistent-filer closure supplies a recurrent pure filing of \(x\). If \(x\) is procedure-typed, continued literal rent either produces a funding trigger or remains forever undisposed; if it exposes a false world floor, settlement-test closure produces repeated loss or an unlicensed disposition. Each alternative violates a poststationary criterion clause. Thus terminal coverage is necessary.

During one era at most \(n_P^{\mathcal E}\) complaints each accumulate at most \(R_K(D_P)\), giving \(n_P^{\mathcal E}R_K(D_P)\). Exactly the at most \(B_R\) preterminal eras are transient. Reserving for the terminal era before relying on tail receipts replaces \(B_R\) by the safe \(B_R+1\). \(\square\)

**Sharpness.** Coverage over every reachable or every-era key is strictly unnecessary: remove an uncovered transient target by a covered first edge, and add an unused branch with another uncovered defect. A one-state uncovered terminal kernel shows terminal coverage is load-bearing.

**Admission fairness characterization.** {#C-GP4} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Within nonsuspended doors of finite positive capacity satisfying local finiteness and work conservation, every eligible filing is admitted at a finite date if and only if the order has finite overtaking. This is filing-specific finite waiting, not a uniform numerical delay.

**Proof.** At eligibility, local finiteness leaves finite older backlog; finite overtaking adds only finitely many later predecessors; work conservation exhausts that finite set. Conversely, finite admission has only finitely many earlier capacity slots, hence finitely many overtakers. \(\square\)

**Sharpness.** An infinite initial backlog defeats the result without local finiteness; an idle door defeats it without work conservation. Date-major order satisfies finite overtaking. Index-major order fails when a low index files forever.

## 4. Account partitions

A transfer policy is **funding-decision separable** on protected semantic traces when every pair of record-seam-equivalent traces gives every protected obligation the same paid/trigger comparison outcome.

**Complete transfer characterization.** {#C-GP5} **Status: PROVED+INDEPENDENTLY-REDERIVED.** For every finite account partition and positive rent schedule, a transfer policy preserves protected dynamic traces exactly when it is funding-decision separable. Under record-seam richness and all rational initial balances this reduces to zero cross-component transfer influence. On a fixed horizon, if \(\sigma_a\) is the infimum protected-account slack over relevant prefixes, cumulative outgoing transfer from \(a\) is safe exactly up to \(\sigma_a\), and the bound is maximal. Incoming outcome-dependent transfer is unsafe in the unconditional all-balance class but is not categorically forbidden on a fixed already-adequate horizon.

**Proof.** Enumerate protected obligations in transition order. If funding decisions are separable, the paired traces agree at the first comparison. Equal paid/trigger outcomes select the same protected constructor and preserve record-seam equivalence; induction gives equality at every later protected comparison. This proves sufficiency. If separability fails, its witnessing pair already has a first unequal paid/trigger outcome, so protected dynamic traces differ; this proves necessity.

Now assume record-seam richness and all rational balances. If a cross-component outcome changes a protected balance by nonzero \(\delta\), richness supplies a comparison trace with rational slack strictly between zero and \(|\delta|\). Applying the transfer in the adverse direction crosses that comparison boundary, contradicting separability. Thus zero influence is necessary, and it is plainly sufficient.

On a fixed horizon let required balance at a relevant prefix be \(P_{req}\). By definition, actual balance is at least \(P_{req}+\sigma_a\). After cumulative outgoing transfer \(\chi\), every comparison remains payable exactly when \(P_{req}+\sigma_a-\chi\ge P_{req}\), equivalently \(\chi\le\sigma_a\). If \(\chi>\sigma_a\), an attaining peak or a prefix within \(\chi-\sigma_a\) of the infimum reverses a protected comparison. Hence the cap is maximal in the stated direction and horizon. \(\square\)

**Sharpness.** Remove record-seam richness and some nonzero transfers may never approach a funding boundary. The certified cap is exact only in its protected outgoing direction and fixed horizon; it is not an unconditional policy classification.

**Account coarsening monotonicity.** {#C-GP6A} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Merging any blocks of a finite account partition cannot make a previously paid obligation fail and weakly lowers least total endowment.

**Proof.** Before any trigger, a merged balance is the sum of nonnegative component balances. An obligation payable by one component is payable by their sum. Induct over ordered obligations and successive merges. \(\square\)

**Sharpness.** Allowing negative component balances invalidates the inductive comparison.

**Peak synchronization theorem.** {#C-GP6B} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Suppose local and pooled peaks are finite and attained and component composition holds. The pooled minimum equals the sum of account minima exactly when some admissible run/date simultaneously attains every local peak. Uniform-delay closure plus component composition is sufficient when integer shifts align peak dates, but is not necessary.

**Proof.** Write the attained local peaks as \(p_a\) and the pooled peak as \(P\). At every admissible run/date,
\[
\sum_a O_a(t)\le\sum_a p_a,
\]
so \(P\le\sum_a p_a\). If one run/date attains every \(p_a\), its pooled value is \(\sum_a p_a\), giving equality. Conversely suppose \(P=\sum_a p_a\), and choose a run/date attaining \(P\). Then
\[
0=\sum_a p_a-\sum_aO_a(t)=\sum_a\bigl(p_a-O_a(t)\bigr).
\]
Every summand is nonnegative, so each is zero and all local peaks are simultaneous. This finite-horizon equivalence is formalized in the compiled kernel. Under uniform-delay closure, delay each component trace by the difference between its peak date and a common later integer; component composition then realizes the aligned tuple. The already-aligned singleton witness proves that this delay hypothesis is not necessary. \(\square\)

**Sharpness.** A singleton class with one already-aligned run has equality but is not delay-closed. Without component composition, individually attainable peaks need not coexist.

## 5. Repeated correct complaints, record symmetry, and propagation

**Repeated-complaint regime theorem.** {#C-GP7} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Assume persistent-filer closure, finitely many terminal keys, latency \(D_P\), concurrency \(n_P\), and positive rent. With terminal coverage and exact-peak endowment, answerable complaints net \(R_K(D)-s^{ch}<0\), repair-only complaints net \(R_K(D)>0\), no complaint triggers suspension, and total repair-complaint revenue obeys
\[
E_K\le N_{repair}n_PR_K(D_P)\le N_{keys}n_PR_K(D_P). \tag{6.4}
\]
With coverage but endowment below the exact peak, a correct target may trigger before disposition. Without coverage, recurrent rent has no endowment-independent cap. Thus the exact diagnostic for the first regime is typed disposition without trigger plus an endowment-independent bound; literal boundedness on one finite-endowment run is insufficient.

**Proof.** For an answerable complaint disposed after \(D\le D_P\), challenger payoff is \(R_K(D)-s^{ch}<0\) by the stake-margin axiom. For an authorized repair, stake is returned and literal rent is retained, so payoff is \(R_K(D)>0\). Canonical aggregation permits at most one paid repair event per terminal key. At most \(n_P\) streams run concurrently and each earns at most \(R_K(D_P)\), hence one key contributes at most \(n_PR_K(D_P)\); summing over the repair-only keys proves (6.4).

Exact-peak endowment pays every prefix by (6.2), so no complaint in the first regime triggers. Below that peak, an attaining or approximating prefix gives a trigger. Without terminal coverage, a recurrent pure complaint has no typed terminal constructor; by supplying larger initial endowment one can extend the positive-rent prefix arbitrarily far. Therefore no endowment-independent enforcement bound exists in that regime, even though each single finite-endowment run has finite receipts before its trigger. \(\square\)

**Sharpness.** Dropping finite key count or a uniform first-rent lower bound destroys (6.4). Dropping exact-peak endowment admits the underfunding trace. The finite specialization has exact revenue \(3/32\), while the loose key bound is \(3\).

Let \(\operatorname{Aut}_{rec}(K)\) be the group of sort-preserving automorphisms of the public record signature preserving transition relations, rational fields, settlement schedules, account assignments, and initial balances.

**Record-automorphism invariance.** {#C-GP8} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Execution is equivariant under \(\operatorname{Aut}_{rec}(K)\). Every scalar functional factoring through the orbit quotient is constant on each orbit; structured equivariant outputs transform with the automorphism. A separating functional must use an input outside the quotient signature or a non-equivariant convention on literal names.

**Proof.** Let \(g\in\operatorname{Aut}_{rec}(K)\). At date zero, \(g\) preserves the initial record by hypothesis. Assume execution prefixes satisfy \(h'_t=g\cdot h_t\). Every next-step guard is built from a preserved sort, relation, rational field, schedule, assignment, or balance, so it has the same truth value on the two prefixes. The selected constructor is therefore the same constructor with every record argument acted on by \(g\), giving \(h'_{t+1}=g\cdot h_{t+1}\). Induction proves execution equivariance.

If \(\Phi=\bar\Phi\circ\pi\), where \(\pi\) maps a record to its orbit, then \(\pi(g\cdot h)=\pi(h)\), hence \(\Phi(g\cdot h)=\Phi(h)\). Conversely, invariance makes \(\bar\Phi([h])=\Phi(h)\) well defined. This factorization equivalence and a two-record literal-name counterexample are formalized in the compiled kernel. A functional separating \(h\) from \(g\cdot h\) therefore cannot factor through the quotient. \(\square\)

**Sharpness.** A program returning the balance attached to the lexicographically first literal name is record-computable but not equivariant and can separate a renamed orbit.

For finite active-chain multiset \(A\subseteq[0,1]\), let a compiler be a computable symmetric \(C(A)\in[0,1]\), with \(C(\varnothing)=0\).

**Event-driven compiler theorem.** {#C-GP9} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Removing occurrence \(j\) changes compiled level by
\[
\Delta_j^C=C(A)-C(A\setminus\{j\}),
\]
and incurs local movement charge \([-H_Y\Delta_j^C]_+\). Monotonicity is exactly what ensures \(\Delta_j^C\ge0\). Among bounded monotone compilers satisfying \(C(A)\ge\max A\), maximum is pointwise least and the constant-one-on-nonempty compiler is pointwise greatest. The two-chain accrual formula lies between maximum and independent union and is not a global extreme.

**Proof.** Immediately before removal the level is \(C(A)\); immediately after it is \(C(A\setminus\{j\})\), so subtraction gives \(\Delta_j^C\). The movement term is the adverse part of \(-H_Y\Delta_j^C\). Since \(A\setminus\{j\}\subseteq A\), monotonicity gives \(C(A\setminus\{j\})\le C(A)\), hence \(\Delta_j^C\ge0\); conversely, nonnegative removal differences for every one-element deletion iterate to monotonicity under every finite insertion.

For every nonempty \(A\), maximum domination gives \(\max A\le C(A)\), while the codomain gives \(C(A)\le1\). The maximum compiler and the map equal to one on nonempty inputs are symmetric, monotone, bounded, and maximum-dominating, so these inequalities are attained pointwise and are the lattice extremes. \(\square\)

**Sharpness.** Without monotonicity a removal shock may be negative. The exact levels \(1/3,1/2\) with bridge \(3/4\) yield compiled \(5/8\) and first shock \(1/8\), while maximum shields a nonleading chain.

## 6. Uniform negative boundaries

**No inflow-independent flow deadline.** {#C-GN1} **Status: PROVED+INDEPENDENTLY-REDERIVED.** For every silence-capable finite kernel, unanswered admissible complaint, and finite deadline depending only on initial endowment and kernel parameters, inflow \(I(k)=R_K(k)\) prevents funding failure at every date.

**Proof.** \(R_K(k)\le F_0+I(k)=F_0+R_K(k)\). Thus the strict trigger inequality never holds. \(\square\)

**Sharpness.** A kernel with mandatory finite disposition has no silence trace. Bounded total inflow restores the exact run-relative exhaustion formula.

**No first-rent bootstrap.** {#C-GN2} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If pure-run closure supplies a door-valid challenge, no receipt precedes its first rent, and \(F_a(0)<r_K(1)\), every policy admitting it fails at the first obligation.

**Proof.** Atomic payment compares the balance with \(r_K(1)\); the strict shortfall triggers before debit. \(\square\)

**Sharpness.** Equality funds the first rent. Empty kernels, no filing, pre-rent receipts, or non-work-conserving refusal fall outside the statement.

**Exact pooled cross-effect interval.** {#C-GN3} **Status: PROVED+INDEPENDENTLY-REDERIVED.** In a record-seam-rich kernel with disjoint world and protected procedure targets, earlier obligation \(a_W\), and next procedure obligation \(a_P\), a pooling cross-effect exists exactly for \(a_W\le F<a_W+a_P\), assuming the comparison trace can pay \(a_P\).

**Proof.** If \(F<a_W\), the world obligation triggers before debit in both the pooled trace and the protected comparison, so it creates no cross-effect. If \(F\ge a_W+a_P\), pooling pays both obligations, as does the comparison by hypothesis. If \(a_W\le F<a_W+a_P\), the pooled trace pays \(a_W\) and leaves \(F-a_W<a_P\), so the procedure obligation triggers; the comparison trace retains the world amount and pays \(a_P\). These cases are exhaustive and give exactly the half-open interval. \(\square\)

**Sharpness.** Outside the interval the world obligation itself fails or both obligations succeed. Kernels without the seam pair have no such witness.

**Transient coverage is unnecessary.** {#C-GN4} **Status: PROVED+INDEPENDENTLY-REDERIVED.** For every kernel admitting a covered edge \(K_0\to K_1\) that removes the target of an uncovered transient defect, the construction may skip uncertified keys and still satisfy the terminal criterion when transient cost is funded. Adding an unused reachable branch with an uncovered defect also makes reachable-wide coverage fail without changing the run.

**Proof.** The first covered edge eliminates the only active target of the uncovered key. Thereafter terminal coverage and the construction theorem apply. The unused branch is never entered, so it changes reachability coverage but not execution. \(\square\)

**Sharpness.** A one-state uncovered terminal kernel is the missing-route obstruction; terminal coverage cannot be dropped.

**Positive repair rent and the open incentive frontier.** {#C-GN5} **Status: PROVED-CONDITIONAL (conditions listed).** In the frozen flow semantics, every correct complaint repaired after \(D\ge1\) earns exactly \(R_K(D)>0\), so no positive rent schedule makes all correct repair complaints unprofitable. Formal admission universality remains true under a modified zero-repair-rent rule because it depends only on local finiteness, work conservation, and finite overtaking. In an extension where filing is voluntary, a correct informed challenger has a zero-payoff outside option, challengers weakly maximize payoff, and behavioral universality requires filing, strict unprofitability is incompatible with behavioral universality.

**Proof.** There are three logically separate statements.

1. Under the frozen positive-rent rule, authorized revision returns stake and does not refund accumulated rent. A correct repair complaint disposed after \(D\ge1\) therefore has payoff \(R_K(D)>0\). Thus no positive schedule makes every such complaint unprofitable.
2. Under the modified zero-repair-rent rule, the queue proof of admission uses only local finiteness, work conservation, and finite overtaking. None mentions challenger payoff, so formal admission universality is unchanged.
3. Add the four behavioral hypotheses. Strict unprofitability makes filing payoff negative, while nonfiling yields zero. Weak payoff maximization therefore selects nonfiling, contradicting the hypothesis that behavioral universality requires the informed correct complaint to be filed.

The third conclusion is conditional on the added behavioral model; it is not a theorem of the frozen transition system. \(\square\)

**Open frontier.** The frozen kernel has no values, information, filing costs, or equilibrium concept. Whether a budget-balanced rule can combine participation for correct persistent defects, negative nuisance payoff, bounded book loss, and fair admission is open.

**Unbounded-key family boundary.** {#C-GN6} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Let \((K_m)\) be finite kernels with \(q_m\to\infty\) distinct reachable repair-only keys. Assume persistent-filer closure, every key is filed before repair, realized latency at least one, and \(\inf_m r_{K_m}(1)=\epsilon>0\). Honest repair-complaint revenue is at least \(q_m\epsilon\), hence unbounded across the family. No family-uniform solvency bound may ignore key cardinality.

**Proof.** Each distinct filed repair-only key returns stake and pays at least its first rent \(\epsilon\). Summing over \(q_m\) keys gives the lower bound, which diverges. Each \(K_m\) remains finite. \(\square\)

**Sharpness.** Answerable-only keys may forfeit stake; never-filed keys earn nothing; and rents tending to zero can keep the sum bounded. These are exactly the hypotheses excluded from the theorem.
