# Verification report

## Result

The consolidation suite is designed to run with one command from this folder and no import from the source repository. All numerical calculations use `fractions.Fraction`; no floating-point comparison appears in a decisive test. Final execution results are recorded at the end of this file.

## Hand rederivation

Every theorem in the six theory files was rewritten from definitions local to this folder. The most load-bearing rederivations were the four-slack leverage identity, rational-polytope compiler, operative-force inequality with the corrected terminal index, collateralized migration implication, terminal learning bridges in both semantics, exact peak endowment functional, terminal-book biconditional, funding-decision separability, peak synchronization, and record-automorphism no-go. No proof cites a phase file as a proof step.

The source issue found during rederivation is the historical operative-force boundary-term error already identified by the independent audit. The consolidation uses `q_(N-1)` for `N` trades and `N-1` movements. Other inherited qualifications are preserved rather than repaired by new research; see `DEVIATIONS.md`.

## Tier A: fresh implementation

`src/exact.py` and `tests/test_tier_a.py` were written from scratch. They check:

- leverage equality and the sharp four-atom witness;
- an exact vertex-enumerated serviceability LP with matching dual value `2/5`;
- the operative-force summation identity on a nontrivial vector path with three trades and two movements;
- the stock deadline `4`, flow pure-run failure `5`, and matched-inflow nonfailure;
- stock false-floor and flow finite-wealth fates;
- repair-completeness calibration without and with one route;
- the displayed-kernel specialization `79/32`, `31/8`, `17/32`, `1/2`, and `33/32`, including one-rent-unit shortfalls;
- exact repeated-complaint revenue `3/32` versus loose bound `3`;
- the two-obligation pooled cross-effect interval `[1,5/4)`;
- closure-epoch self-financing and exact intra-cycle deficit `1/2`;
- record conjugation, compiler shocks, and pooled versus aligned peaks.

Tier A agrees with the retained source numbers.

## Tier B: vendored long tail

Tier B has two layers. `tests/test_tier_b_vendored.py` is a compact adapted copy of the most decisive long-tail assertions. In addition, the standalone exact-rational witness modules from Stage III-B, IV-E, and VI–XI are copied byte-for-byte as `src/vendored_*.py`, and their relevant test suites are copied as `tests/test_vendored_*.py`. Test-file changes are limited to local import rewiring and skip decorators on six repository-layout, old-ledger, or upstream-checksum tests. The consolidation's manifest and claim/status audits replace those six checks. Source checksums are in `FROZEN_INPUT_CHECKSUMS.json`; the runner verifies every byte-identical vendored source module against it.

The direct Tier B sources are `phase_iii_b_typed_audit/passes/liveness/test_liveness_experiment.py`, `phase_iv/iv_e_mathematical_hardening/src/witnesses.py`, `phase_iv/iv_e_mathematical_hardening/tests/test_witnesses.py`, and `tests/test_witnesses.py` under each of `phase_vi_answerability`, `phase_vii_answerable_learning`, `phase_viii_construction`, `phase_ix_flow_kernel`, `phase_x_existence`, and `phase_xi_theorem_ledger`. Their hashes are individually present in the manifest.

The complete historical 790-test harness was not copied. The relevant exact witness suites are present and executable; integration and implementation regressions outside the mathematical dependency closure are excluded by the discard filter. Vendoring preserves source evidence and does not upgrade any general theorem.

## Lean

`lean/PhaseIVE.lean` is the vendored scalar Phase IV-E kernel. It covers the leverage slack and bound, convex certificate regions, anchored comparison, scalar wealth assembly, positive-part subadditivity/minimality, target algebra, successor self-ratification, version-space order kernels, append persistence, safe iteration, and the two-world self-financing bound.

The improvement-pass menu was evaluated before selection:

- **General exhaustion time — accepted:** leastness under an inhabited failure predicate, the rational-floor pure-run formula, and emptiness under matched inflow form the actual arithmetic spine and contain nontrivial well-ordering and floor steps.
- **Finite overtaking iff eventual admission — rejected:** a faithful statement requires a formal operational door, capacity slots, and work-conservation trace rather than an abstract order that would make one direction definitional; that infrastructure exceeds this bounded pass.
- **Peak synchronization — accepted:** the reverse implication from equality of pooled and summed peaks to simultaneous component attainment is the sharp equality condition and requires a finite nonnegative-gap argument.
- **Compiler lattice extremes — rejected:** after the compiler axioms are assumed, the two pointwise extreme inequalities are their defining lower and upper bounds, while a monotonicity-dropped example would not formalize the event-driven transition content.
- **Orbit invariance with counterexample — accepted:** quotient factorization iff group-action invariance plus an explicit computable name-sensitive failure checks both the positive theorem and its sharp boundary.

Four substantive bounded targets now compile:

1. **Repaired summation identity.** `summationByParts` and `summationByPartsWithPrices` remain unchanged and prove the general finite scalar-coordinate identity with `n+1` trades and `n` internal moves, including execution prices. Coordinatewise application plus linearity is the vector identity; the file does not formalize finite-dimensional inner products.
2. **General exhaustion time.** `exhaustionTime_spec` proves that the least failing index exists under the canonical divergence hypothesis, fails there, and is payable at every earlier index. `constantRentExhaustionTime` proves the full rational-floor formula, and `matchedInflowHasNoExhaustionTime` proves that matched inflow makes the failure set empty. The definitions encode the exact atomic funding comparison over monotone rational cumulative schedules, but not the rest of the challenge transition system. This exactly machine-checks the arithmetic and leastness content of C-FLOW-EXHAUST; its ledger status is upgraded accordingly.
3. **Finite-horizon peak synchronization.** `peakSynchronizationIff`, using `peakAlignmentAtDate` as a feeder lemma, proves for finitely many accounts and dates that the attained pooled peak equals the sum of attained account peaks iff all account peaks occur at one date. It does not encode challenger component-composition or the sufficient relative-delay construction, so C-GP6B retains independently rederived status.
4. **Orbit quotient and counterexample.** `factorsThroughOrbit_iff` proves for an arbitrary group action that a functional factors through the orbit quotient iff it is invariant under every group element. `firstLiteralValue_not_invariant` supplies a finite two-name record with Boolean fields and a computable functional reading the lexicographically first literal field; a swapping permutation defeats invariance. It does not encode the flow transition signature or the date induction proving execution equivariance, so C-GP8 retains independently rederived status.

Earlier candidate evaluations remain unchanged: the finite-gamble Farkas equivalence would require substantial cone/separation infrastructure, a complete ledger/solvency evaluator would exceed the bounded target, and the stock capacity deadline does not share the flow theorem's funding predicate.

Both Lean files compile with no `sorry`. Mathlib idealizes exact real/rational arithmetic in the stated finite objects; no computability, complexity, or mechanism behavior is inferred from compilation.

The final run used Lean `4.28.0-rc1` (commit `3b0f2862196c6a8af9eb0025ee650252694013dd`) and Mathlib checkout `58d8468384df017604272605bb0ec709826199e7` supplied by the available Lake environment.

## Automated document audits

The runner verifies that every `{#C-...}` monograph claim has a ledger row, no retired canonical name occurs in the theory files, the Lean sources contain no `sorry`, and the checksum manifest is nonempty and well formed. Manual inspection additionally checked that interpretive language is quarantined and that every Part VI theorem has a sharpness entry or explicit open frontier.

## Final run

On 2026-08-08, the improvement-pass command `python3 tests/run.py` completed successfully from `consolidation_aug8/`: all 140 Python tests passed, with six deliberate obsolete repository-layout/checksum checks skipped and no mathematical test skipped. The claim/status, retired-name, checksum, and new six-part LaTeX audits passed. Every byte-identical vendored source matched its frozen checksum. `lean/PhaseIVE.lean` and the upgraded `lean/Aug8.lean` both compiled `sorry`-free under Lean `4.28.0-rc1` commit `3b0f2862196c6a8af9eb0025ee650252694013dd` and Mathlib commit `58d8468384df017604272605bb0ec709826199e7`. The runner ended with `ALL GREEN: Tier A, Tier B, document audits, and Lean`.
