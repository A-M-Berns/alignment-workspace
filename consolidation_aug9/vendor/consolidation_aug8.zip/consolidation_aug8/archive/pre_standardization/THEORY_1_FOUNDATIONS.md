# Part I. Finite state, records, and service

This monograph has two mathematical lines with a precise but limited interface. The leverage line maps sourced warrant constraints to permitted credences and then studies constrained quote selection. The answerability line maps public challenges to answers, revisions, suspensions, funding obligations, and learning conditions. They share finite languages, public append-only records, active books, and an activation interface. Neither line proves the other. Which line is primary is not a mathematical question and remains author-reserved.

All sets called finite below are literally finite. All numerical inputs are rational unless a theorem explicitly uses real vector spaces. Empty sums are zero.

## 1. Finite probability and constraint syntax

Let \(\Omega\) be a nonempty finite set and \(\Delta(\Omega)\) its probability simplex. A proposition is a subset of \(\Omega\). A **warrant** is a sourced, scoped, defeasible schema \(\rho:\alpha\rightsquigarrow\beta\) with an applicability condition. An active warrant instance supplies a rational affine row \(\ell_j(\mu)\ge0\). A **book** is a finite set of active rows together with provenance and status records. Its permitted region is
\[
S(R)=\{\mu\in\Delta(\Omega):\ell_j(\mu)\ge0\text{ for every active row }j\}.
\]
A **floor** is a lower-bound row. A rebuttal adds support for an opposed conclusion. An undercutter changes or removes a transmission premise. Suspension removes an active row without deleting its occurrence. A repair is a declared map to weakened rows with nonempty permitted region.

## 2. Public histories

A public history is a finite append-only sequence of dated events. Required event fields are identifiers, provenance, scope, governing versions, dependency paths, statuses, and any numerical obligation. A deterministic transition is a function of the public prefix; a randomized transition is a probability kernel on prefixes. An activation event is distinct from derivability: a proposal has no operative projection until an authorized activation record exists.

**Record extensionality.** {#C-REC-EXT} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Equal public histories yield equal deterministic outputs and equal randomized output distributions.

**Proof.** Equal inputs to a function have equal outputs. Applying the same fact to a probability-kernel-valued function gives equality of distributions. \(\square\)

This does not identify unrecorded causes. Adding authenticated fields can refine the input equivalence relation.

**Append-only persistence.** {#C-APPEND} **Status: PROVED+MACHINE-CHECKED.** If an event occurs in prefix \(h\), it occurs in every extension \(h\mathbin{+\!+}h'\). Hence recorded authorization, objections, burdens, evidence, target data, and operative acts survive later status changes.

**Proof.** Induct on \(h'\), or use membership in list concatenation. No extension step deletes an element of the prefix. \(\square\)

The hypothesis is necessary: a mutable-history transition may erase an earlier event in one step.

## 3. Finite service queues

An obligation has an immutable identifier, positive rational required work, arrival date, FIFO position, and remaining work. At round \(t\), workload \(a_t\) arrives and a server supplies at most \(C>0\). Service completion is not terminal disposition; disposition needs a separate congruent certificate.

**Overload waiting impossibility.** {#C-QUEUE-OVERLOAD} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If independent work arrives at rate \(R>C\) each round, no scheduling policy guarantees every obligation completion within a fixed \(W<\infty\). The least integer counting witness is
\[
T=\left\lfloor\frac{CW}{R-C}\right\rfloor+1.
\]

**Proof.** The first \(T\) rounds create \(RT\) work. A \(W\)-round promise requires it served by \(T+W\), when capacity is at most \(C(T+W)\). The displayed choice makes \((R-C)T>CW\), a contradiction. \(\square\)

Safety does not imply service: the transition that records every arrival and performs zero work preserves every identifier while starving all items.

**Token-envelope FIFO bound.** {#C-QUEUE-FIFO} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Suppose
\[
\sum_{k=s}^t a_k\le \rho(t-s+1)+\beta,\qquad 0\le\rho<C.
\]
A work-conserving FIFO server has post-service backlog at most \(\beta\), pre-service workload at most \(2\beta+\rho\), and completion delay at most
\[
D=\left\lceil\frac{2\beta+\rho}{C}\right\rceil.
\]

**Proof.** Unrolling \(Q_t=(Q_{t-1}+a_t-C)_+\) gives
\[
Q_t=\max\!\left(0,\max_{1\le s\le t}\left[\sum_{k=s}^t a_k-C(t-s+1)\right]\right).
\]
For an interval of length \(m\ge1\), the bracket is at most \(\beta-(C-\rho)m\le\beta\). Also \(a_t\le\rho+\beta\), giving pre-service work at most \(2\beta+\rho\). Later work joins behind a fixed item, so work conservation removes everything ahead of it in the displayed number of rounds. \(\square\)

Dropping \(\rho<C\) admits persistent overload. Dropping work conservation admits an idle server.

**Identity conservation under aggregation.** {#C-QUEUE-ID} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Let \(\mathcal U\) be finite source/scope atoms and represent an obligation by a vector in the free commutative monoid \(\mathbb N^{(\mathcal U)}\). If every split, merge, migration, and disposition preserves
\[
L_t+T_t=L_{t+1}+T_{t+1},
\]
then every original atom occurs at exactly one live or terminal accounting position at every finite prefix.

**Proof.** The equality preserves each basis coefficient. Induction over transitions preserves every coefficient from its initial value one. A missing atom changes a coefficient to zero; a duplicate changes it above one. \(\square\)

A summary that omits the source map cannot certify this property on a class with two source sets having the same summary: the checker receives identical inputs for distinct omitted identities.

## 4. Shared challenge syntax and two pricing semantics

The common syntactic layer consists of a finite language \(\mathcal L\), finite schema set, finite five-field defect table, finite semantic-key set, finite route graph, finite meta-depth, books, floors, challenges, routes, and public records. A challenge has a key, mode, stake, admission date, latency, and disposition. Both semantics use token-gated admission and bounded service latency.

In **stock semantics**, the procedure cost of age \(k\) is locked opportunity cost \(s^{ch}+R(k)\), where \(R(k)=\sum_{j=1}^k r(j)\). Capacity \(C^{ans}\) limits simultaneous locks. A procedure challenge forces answer, revision, or suspension when its required lock reaches capacity. World-mode suspension locks only base stake after the mode split.

In **flow semantics**, rent \(r(k)>0\) is a literal per-period transfer from the named book account while the challenge remains open. At each due atomic obligation, a balance below the amount triggers suspension before debit. Stake is held separately and is returned or forfeited by the disposition rule.

Translation preserves books, challenges, routes, records, stake, latency, and cumulative schedule \(R\); it replaces the stock predicate “required lock is within capacity” by the flow predicate “every due transfer is payable from initial balance plus prior inflow.” Thus stock capacity is not flow wealth.

| Retained result family | Stock | Flow | Exact modification |
|---|---:|---:|---|
| procedure persistence deadline | yes | refuted in universal form | flow uses run-relative exhaustion time |
| same-day concurrency bound | yes | yes | locks versus liquid obligations |
| persistent false exposed floor | counterexample | does not persist with finite unreplenished wealth | flow pays stake plus accumulated rent |
| public-record conjugacy | yes | yes | balances and rent flows are added to the conjugacy |
| bare terminal bridge | refuted | refuted | operational adequacy is required |
| repaired terminal bridge | yes | yes-modified | flow uses paid obligations and atomic triggers |
| stock construction | yes | not portable | flow construction uses account assignment and stronger reserve bounds |
| finite repair-completeness calibration | yes | yes-modified | flow route edges name accounts and costs |
| account-separation and propagation | not present in base stock model | yes | flow-only balance and compiler results |

This is the family-level translation table. `LEDGER.md` supplies the exhaustive claim-level table: every retained claim has a stock, flow, both, both-modified, or not-applicable tag.
