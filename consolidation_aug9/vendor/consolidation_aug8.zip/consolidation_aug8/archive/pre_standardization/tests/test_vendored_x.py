import hashlib
import json
import unittest
from fractions import Fraction as Q
from pathlib import Path

from src.vendored_x import (
    DK,
    MERGED,
    PROCEDURE,
    WORLD,
    alignment_lemma_witness,
    best_alignment_delay,
    dk_aligned_merged_schedule,
    dk_anti_nuisance_holds,
    dk_minimal_reserves,
    dk_procedure_schedule,
    dk_rent,
    dk_schedule,
    dk_siege_revenue,
    dk_sufficient_reserves,
    dk_theta,
    dk_world_schedule,
    dovetail_admissions,
    drop_arc_coverage_witness,
    drop_foa_witness,
    drop_latency_gate_witness,
    firewall_merge_comparison,
    ix_a4_unbounded_siege,
    merge_accounts,
    minimal_reserve,
    no_bootstrap_from_zero,
    patronage_monotonicity,
    run_ledger,
    siege_payoff,
    starvation_witness,
    sybil_subsidy_comparison,
    sybil_throughput,
    tail_challenge_net,
    tail_cycle_balances,
    tail_intracycle_dip,
    tail_timing_witness,
    total_siege_revenue_bound,
)


ROOT = Path(__file__).resolve().parents[2]


@unittest.skip("superseded by FROZEN_INPUT_CHECKSUMS.json and tests/run.py")
class FrozenInputTests(unittest.TestCase):
    def test_phase_vi_ix_inputs_match_recorded_checksums(self) -> None:
        checksum_file = ROOT / "phase_x_existence" / "FROZEN_INPUT_CHECKSUMS.json"
        expected = json.loads(checksum_file.read_text(encoding="utf-8"))
        self.assertGreater(len(expected), 0)
        for relative, digest in expected.items():
            payload = (ROOT / relative).read_bytes()
            self.assertEqual(hashlib.sha256(payload).hexdigest(), digest, relative)

    def test_phase_ix_is_inside_the_frozen_set(self) -> None:
        checksum_file = ROOT / "phase_x_existence" / "FROZEN_INPUT_CHECKSUMS.json"
        expected = json.loads(checksum_file.read_text(encoding="utf-8"))
        for phase in (
            "phase_vi_answerability",
            "phase_vii_answerable_learning",
            "phase_viii_construction",
            "phase_ix_flow_kernel",
        ):
            self.assertTrue(
                any(key.startswith(phase + "/") for key in expected), phase
            )


class DisplayedKernelTests(unittest.TestCase):
    def test_anti_nuisance_axiom_holds_on_DK(self) -> None:
        self.assertTrue(dk_anti_nuisance_holds())
        self.assertEqual(dk_rent(DK["D_W"]), Q(1, 16))
        self.assertLess(dk_rent(DK["D_W"]), DK["stake"])

    def test_transient_date_bound(self) -> None:
        self.assertEqual(dk_theta(), 35)

    def test_exact_minimal_reserves(self) -> None:
        self.assertEqual(
            dk_minimal_reserves(), {PROCEDURE: Q(17, 32), WORLD: Q(1, 2)}
        )

    def test_minimum_funds_every_obligation(self) -> None:
        result = run_ledger(
            dk_schedule(), {PROCEDURE: Q(17, 32), WORLD: Q(1, 2)}
        )
        self.assertFalse(result.any_trigger)

    def test_one_rent_unit_below_the_minimum_triggers(self) -> None:
        short_p = run_ledger(
            dk_schedule(), {PROCEDURE: Q(17, 32) - DK["gamma"], WORLD: Q(1, 2)}
        )
        short_w = run_ledger(
            dk_schedule(), {PROCEDURE: Q(17, 32), WORLD: Q(1, 2) - DK["gamma"]}
        )
        self.assertTrue(short_p.any_trigger)
        self.assertTrue(short_w.any_trigger)

    def test_sufficient_bound_dominates_the_minimum(self) -> None:
        suff, minimum = dk_sufficient_reserves(), dk_minimal_reserves()
        self.assertEqual(suff, {PROCEDURE: Q(79, 32), WORLD: Q(31, 8)})
        self.assertGreater(suff[PROCEDURE], minimum[PROCEDURE])
        self.assertGreater(suff[WORLD], minimum[WORLD])

    def test_world_settlement_date_is_one_atomic_obligation(self) -> None:
        due = [
            e.amount for e in dk_world_schedule()
            if e.date == DK["D_W"] and e.kind == "rent+match"
        ]
        self.assertEqual(due, [DK["gamma"] + DK["stake"]] * DK["J_W"])


class NecessityQuadrupleTests(unittest.TestCase):
    def test_drop_foa_kills_an_already_correct_book(self) -> None:
        result = drop_foa_witness()
        self.assertTrue(result.any_trigger)
        self.assertEqual(result.triggered[0][3], Q(1, 4))

    def test_drop_arc_coverage_is_a_funding_trap(self) -> None:
        witness = drop_arc_coverage_witness()
        self.assertEqual(witness["per_round_extraction"], Q(3, 4))
        self.assertEqual(witness["funded_rounds"], 4)
        self.assertTrue(witness["result"].any_trigger)

    def test_drop_latency_gate_makes_a_correct_book_bleed(self) -> None:
        witness = drop_latency_gate_witness()
        self.assertEqual(witness["inflated_challenger_net"], Q(1, 4))
        self.assertEqual(witness["canonical_challenger_net"], Q(-1, 4))
        self.assertTrue(witness["unbounded"])

    def test_dropping_the_firewall_does_not_kill_the_construction(self) -> None:
        """Adverse finding AF-X.1: merging never lowers available funding."""
        comparison = firewall_merge_comparison()
        self.assertEqual(comparison["fenced_total"], Q(33, 32))
        self.assertEqual(comparison["merged_min"], Q(33, 32))
        self.assertEqual(comparison["premium"], Q(0))

    def test_merged_pool_funds_every_ring_fenced_obligation(self) -> None:
        fenced = dk_minimal_reserves()
        pooled = run_ledger(
            merge_accounts(dk_schedule()),
            {MERGED: fenced[PROCEDURE] + fenced[WORLD]},
        )
        self.assertFalse(pooled.any_trigger)

    def test_peak_alignment_lemma(self) -> None:
        witness = alignment_lemma_witness()
        self.assertEqual(witness["fenced_total"], Q(5, 4))
        self.assertEqual(witness["merged_undelayed"], Q(3, 4))
        self.assertEqual(witness["merged_delay_optimized"], Q(5, 4))
        self.assertEqual(witness["premium_against_delay_closed_class"], Q(0))

    def test_no_delay_beats_the_declared_DK_worst_case(self) -> None:
        best = best_alignment_delay()
        self.assertEqual(
            minimal_reserve(dk_aligned_merged_schedule(), MERGED), Q(33, 32)
        )
        self.assertIsInstance(best, int)


class TailSelfFinancingTests(unittest.TestCase):
    def test_per_challenge_net_is_positive_by_the_axiom(self) -> None:
        self.assertEqual(
            tail_challenge_net(
                stake=Q(1, 2), periods=1, gamma=Q(1, 4), forfeits=True
            ),
            Q(1, 4),
        )
        self.assertEqual(
            tail_challenge_net(
                stake=DK["stake"], periods=DK["D_W"], gamma=DK["gamma"],
                forfeits=True,
            ),
            Q(1, 16),
        )

    def test_closure_epoch_balances_are_nondecreasing(self) -> None:
        balances = tail_cycle_balances(
            reserve=Q(1, 2), stake=Q(1, 2), periods=1, gamma=Q(1, 4), cycles=6
        )
        self.assertEqual(balances[-1], Q(2))
        for earlier, later in zip(balances, balances[1:]):
            self.assertGreaterEqual(later, earlier)

    def test_date_by_date_nondecrease_is_refuted(self) -> None:
        """Honest income arrives one date after the rent it must cover."""
        dip = tail_intracycle_dip(concurrent=2, periods=1, gamma=Q(1, 4))
        self.assertEqual(dip, Q(1, 2))
        underfunded = tail_timing_witness(
            reserve=Q(1, 4), concurrent=2, periods=1, gamma=Q(1, 4),
            stake=Q(1, 2),
        )
        self.assertTrue(underfunded.any_trigger)
        funded = tail_timing_witness(
            reserve=dip, concurrent=2, periods=1, gamma=Q(1, 4), stake=Q(1, 2)
        )
        self.assertFalse(funded.any_trigger)
        self.assertEqual(funded.final[PROCEDURE], Q(1))
        self.assertGreater(funded.final[PROCEDURE], dip)

    def test_working_capital_equals_the_FOA_R_rent_term(self) -> None:
        self.assertEqual(
            tail_intracycle_dip(
                concurrent=DK["n_P"], periods=DK["D_P"], gamma=DK["gamma"]
            ),
            DK["n_P"] * dk_rent(DK["D_P"]),
        )


class EndowmentTests(unittest.TestCase):
    def test_no_bootstrap_from_zero(self) -> None:
        self.assertEqual(no_bootstrap_from_zero(DK["gamma"]), Q(1, 64))
        self.assertGreater(no_bootstrap_from_zero(DK["gamma"]), 0)
        empty = run_ledger(dk_schedule(), {PROCEDURE: Q(0), WORLD: Q(0)})
        self.assertTrue(empty.any_trigger)

    def test_procedure_minimum_scales_linearly_in_n_P(self) -> None:
        base = dk_minimal_reserves()[PROCEDURE]
        doubled = base + DK["n_P"] * dk_rent(DK["D_P"])
        self.assertEqual(doubled - base, Q(3, 32))

    def test_patronage_clause_holds_on_the_pure_run(self) -> None:
        audit = patronage_monotonicity(
            dk_schedule(),
            {PROCEDURE: Q(17, 32), WORLD: Q(1, 2)},
            {PROCEDURE: Q(0), WORLD: Q(0)},
        )
        self.assertTrue(audit["pure_run_solvent"])

    def test_recorded_inflow_never_creates_a_trigger(self) -> None:
        for reserve in (Q(0), Q(1, 4), Q(17, 32)):
            audit = patronage_monotonicity(
                dk_schedule(),
                {PROCEDURE: reserve, WORLD: reserve},
                {PROCEDURE: Q(5), WORLD: Q(5)},
            )
            self.assertTrue(audit["inflow_adds_no_trigger"])


class EcologyTests(unittest.TestCase):
    def test_index_major_admission_starves(self) -> None:
        witness = starvation_witness()
        self.assertTrue(witness["index_major_starves"])
        self.assertIsNone(witness["index_major_admission_date"])

    def test_date_major_admission_is_starvation_free(self) -> None:
        witness = starvation_witness()
        self.assertEqual(witness["date_major_admission_date"], 3)

    def test_every_eligible_filing_is_eventually_admitted(self) -> None:
        filings = [(i, t) for i in range(1, 5) for t in range(1, 5)]
        admitted = dovetail_admissions(
            filings, per_date=1, horizon=200, index_major=False
        )
        self.assertTrue(all(value is not None for value in admitted.values()))

    def test_splitting_does_not_divide_the_subsidy(self) -> None:
        """Adverse finding AF-X.2: per-index schedules are not self-diluting."""
        comparison = sybil_subsidy_comparison(
            original_index=5, split_indices=[5, 6, 7, 8], budget=Q(1, 8)
        )
        self.assertFalse(comparison["self_dilutes"])
        self.assertGreater(comparison["split_total"], comparison["single"])

    def test_splitting_stays_inside_the_summable_ecology_total(self) -> None:
        comparison = sybil_subsidy_comparison(
            original_index=1, split_indices=list(range(1, 40)), budget=Q(1, 8)
        )
        self.assertTrue(comparison["split_within_ecology_total"])
        self.assertEqual(comparison["ecology_total"], Q(1, 8))

    def test_splitting_cannot_beat_the_dovetail_throughput_bound(self) -> None:
        for split in (1, 2, 4, 8):
            result = sybil_throughput(per_date=2, split_count=split, horizon=10)
            self.assertLessEqual(result["admitted"], result["dovetail_bound"])


class SiegeBoundaryTests(unittest.TestCase):
    def test_answered_complaint_is_strictly_losing(self) -> None:
        self.assertEqual(
            siege_payoff(
                stake=DK["stake"], periods=DK["D_P"], gamma=DK["gamma"],
                disposition="checked-answer",
            ),
            Q(-7, 64),
        )

    def test_repair_only_complaint_is_strictly_profitable(self) -> None:
        """Adverse finding AF-X.3: siege is bounded, not unprofitable."""
        payoff = siege_payoff(
            stake=DK["stake"], periods=DK["D_P"], gamma=DK["gamma"],
            disposition="authorized-revision",
        )
        self.assertEqual(payoff, Q(1, 64))
        self.assertGreater(payoff, 0)

    def test_total_siege_revenue_is_finite(self) -> None:
        revenue = dk_siege_revenue()
        self.assertEqual(revenue["displayed_key_revenue"], Q(3, 32))
        self.assertEqual(revenue["loose_key_bound"], Q(3))
        self.assertEqual(
            revenue["loose_key_bound"],
            DK["b"] * (DK["B_R"] + 1) * DK["d"] * DK["n_P"] * dk_rent(DK["D_P"]),
        )

    def test_siege_revenue_is_inside_the_procedure_minimum(self) -> None:
        revenue = total_siege_revenue_bound(
            keys=1, concurrent=DK["n_P"], periods=DK["D_P"], gamma=DK["gamma"]
        )
        self.assertLessEqual(revenue, dk_minimal_reserves()[PROCEDURE])

    def test_ix_a4_unbounded_siege_needs_a_dropped_hypothesis(self) -> None:
        """Without repair coverage the whole reserve is extracted."""
        self.assertEqual(ix_a4_unbounded_siege(Q(1), Q(1, 4)), Q(1))
        for reserve in (Q(1), Q(4), Q(16)):
            self.assertEqual(ix_a4_unbounded_siege(reserve, Q(1, 4)), reserve)

    def test_no_complaint_suspends_its_target_at_the_minimum(self) -> None:
        result = run_ledger(
            dk_schedule(), {PROCEDURE: Q(17, 32), WORLD: Q(1, 2)}
        )
        self.assertEqual(result.triggered, ())


if __name__ == "__main__":
    unittest.main()
