import hashlib
import json
import unittest
from fractions import Fraction as Q
from pathlib import Path

from src.vendored_ix import (
    accrual_shock,
    flow_adequacy_reserve,
    funding_failure_period,
    max_shock,
    movement_charge,
    nonzero_subsidy_counterexample,
    normalize_flow_trace,
    nuisance_payoff,
    pure_run_failure_period,
    ring_fenced_firewall_witness,
    serial_false_floor,
    slack_cap_preserves,
    unpartitioned_firewall_witness,
    world_round_transfer,
)


ROOT = Path(__file__).resolve().parents[2]


@unittest.skip("superseded by FROZEN_INPUT_CHECKSUMS.json and tests/run.py")
class FrozenInputTests(unittest.TestCase):
    def test_phase_vi_viii_inputs_match_recorded_checksums(self) -> None:
        checksum_file = ROOT / "phase_ix_flow_kernel" / "FROZEN_INPUT_CHECKSUMS.json"
        expected = json.loads(checksum_file.read_text(encoding="utf-8"))
        self.assertGreater(len(expected), 0)
        for relative, digest in expected.items():
            payload = (ROOT / relative).read_bytes()
            self.assertEqual(hashlib.sha256(payload).hexdigest(), digest, relative)


class FlowKernelTests(unittest.TestCase):
    def test_old_deadline_is_replaced_by_strict_exhaustion(self) -> None:
        self.assertEqual(pure_run_failure_period(Q(1), Q(1, 4)), 5)

    def test_inflow_can_remove_a_general_deadline(self) -> None:
        self.assertIsNone(
            funding_failure_period(
                Q(0), [Q(1, 4)] * 8, [Q(1, 4)] * 8
            )
        )

    def test_false_floor_drip_recycling(self) -> None:
        result = serial_false_floor(
            initial_book_wealth=Q(3),
            stake=Q(1, 2),
            periods_open=1,
            gamma=Q(1, 4),
        )
        self.assertEqual(result["per_round_extraction"], Q(3, 4))
        self.assertEqual(result["completed_rounds"], 4)
        self.assertEqual(result["first_unfunded_round"], 5)
        self.assertEqual(result["challenger_gain"], Q(3))

    def test_consistent_world_challenge_loses_under_latency_gate(self) -> None:
        result = world_round_transfer(
            stake=Q(1, 2), periods_open=1, gamma=Q(1, 4), floor_false=False
        )
        self.assertEqual(result["challenger_net"], Q(-1, 4))

    def test_nuisance_farming_is_strictly_losing(self) -> None:
        self.assertEqual(nuisance_payoff(Q(1, 2), 1, Q(1, 4)), Q(-1, 4))

    def test_substantive_siege_is_profitable(self) -> None:
        periods_paid = pure_run_failure_period(Q(1), Q(1, 4)) - 1
        self.assertEqual(periods_paid, 4)
        self.assertEqual(periods_paid * Q(1, 4), Q(1))

    def test_latency_inflation_changes_false_complaint_payoff(self) -> None:
        inflated = world_round_transfer(
            stake=Q(1, 2), periods_open=3, gamma=Q(1, 4), floor_false=False
        )
        canonical = world_round_transfer(
            stake=Q(1, 2), periods_open=1, gamma=Q(1, 4), floor_false=False
        )
        self.assertEqual(inflated["challenger_net"], Q(1, 4))
        self.assertEqual(canonical["challenger_net"], Q(-1, 4))


class FirewallTests(unittest.TestCase):
    def test_unpartitioned_hume_witness(self) -> None:
        result = unpartitioned_firewall_witness()
        self.assertEqual(result.world_outflow, Q(1))
        self.assertFalse(result.normative_active)

    def test_ring_fence_blocks_the_same_adversary(self) -> None:
        result = ring_fenced_firewall_witness()
        self.assertEqual(result.world_end, Q(0))
        self.assertEqual(result.procedure_rent_paid, Q(1, 4))
        self.assertTrue(result.normative_active)

    def test_any_positive_cap_breaks_surplus_free_strong_form(self) -> None:
        result = nonzero_subsidy_counterexample(Q(1, 8))
        self.assertFalse(result["target_survives"])

    def test_certified_slack_supports_a_nonzero_cap(self) -> None:
        self.assertTrue(
            slack_cap_preserves(
                procedure_obligation=Q(1, 2),
                certified_slack=Q(1, 4),
                transfer=Q(1, 8),
            )
        )
        self.assertFalse(
            slack_cap_preserves(
                procedure_obligation=Q(1, 2),
                certified_slack=Q(1, 8),
                transfer=Q(1, 4),
            )
        )

    def test_flow_adequacy_reserve(self) -> None:
        self.assertEqual(
            flow_adequacy_reserve(
                canonical_cost=Q(3, 2),
                procedure_count=6,
                procedure_delay=1,
                world_slots=2,
                world_delay=4,
                gamma=Q(1, 64),
            ),
            Q(55, 32),
        )


class PropagationAndGaugeTests(unittest.TestCase):
    def test_max_shields_a_nonmaximal_chain(self) -> None:
        shock = max_shock((Q(1, 3), Q(1, 2)), 0)
        self.assertEqual(shock["floor_drop"], Q(0))
        terminal = max_shock((Q(1, 2),), 0)
        self.assertEqual(terminal["floor_drop"], Q(1, 2))

    def test_max_unique_leader_moves_by_order_statistic_gap(self) -> None:
        shock = max_shock((Q(3, 4), Q(1, 2)), 0)
        self.assertEqual(shock["floor_drop"], Q(1, 4))

    def test_accrual_bridge_exposes_first_shock(self) -> None:
        shock = accrual_shock(Q(1, 3), Q(1, 2), Q(3, 4))
        self.assertEqual(shock["old_floor"], Q(5, 8))
        self.assertEqual(shock["new_floor"], Q(1, 2))
        self.assertEqual(shock["floor_drop"], Q(1, 8))
        self.assertEqual(
            movement_charge(Q(-2), shock["old_floor"], shock["new_floor"]),
            Q(1, 4),
        )

    def test_flow_record_twins_are_conjugate(self) -> None:
        left = (
            ("rent", "book", "alice", Q(1, 4)),
            ("forfeit", "alice", "book", Q(1, 2)),
        )
        right = (
            ("rent", "book-prime", "ada", Q(1, 4)),
            ("forfeit", "ada", "book-prime", Q(1, 2)),
        )
        normalized = normalize_flow_trace(
            right, {"book-prime": "book", "ada": "alice"}
        )
        self.assertEqual(normalized, left)


if __name__ == "__main__":
    unittest.main()
