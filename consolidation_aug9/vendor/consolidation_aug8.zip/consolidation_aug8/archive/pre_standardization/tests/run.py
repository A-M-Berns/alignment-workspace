#!/usr/bin/env python3
"""One-command runner for exact tests, document audits, and Lean."""
from __future__ import annotations
import hashlib, json, os, pathlib, re, subprocess, sys, unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def documents():
    return sorted(ROOT.glob("THEORY_*.md"))

def audit_documents():
    retired=["martyrdom","siege","firewall","Sybil","Hume-bypass","record twins",
             "Moving-Book","No-Trader","Authorized Surprise","Target--Remainder",
             "Bounded Dogmatism","haunting","whitewashing","PCMC"]
    text="\n".join(p.read_text() for p in documents())
    for word in retired:
        if re.search(rf"\b{re.escape(word)}\b",text,re.I):
            raise AssertionError(f"retired canonical name in monograph: {word}")
    if "sorry" in "\n".join(p.read_text() for p in (ROOT/"lean").glob("*.lean")):
        raise AssertionError("Lean source contains sorry")
    missing_command=re.compile(
        r"(?<!\\)\b(?:quad|qquad|cdot|times|leq|geq|operatorname|mathrm|"
        r"mathbf|mathcal|mathfrak|tag)\b")
    math_segment=re.compile(r"\\\((.*?)\\\)|\\\[(.*?)\\\]",re.S)
    for p in documents():
        body=p.read_text()
        for opening,closing,label in ((r"\(",r"\)","inline"),(r"\[",r"\]","display")):
            if body.count(opening)!=body.count(closing):
                raise AssertionError(f"unbalanced {label} math delimiters in {p.name}")
        for match in math_segment.finditer(body):
            segment=match.group(1) if match.group(1) is not None else match.group(2)
            line=body.count("\n",0,match.start())+1
            if missing_command.search(segment):
                raise AssertionError(f"missing LaTeX command backslash in {p.name}:{line}")
            depth=0
            for char in re.sub(r"\\[{}]","",segment):
                if char=="{": depth+=1
                elif char=="}": depth-=1
                if depth<0: raise AssertionError(f"unbalanced math braces in {p.name}:{line}")
            left_count=len(re.findall(r"\\left(?![A-Za-z])",segment))
            right_count=len(re.findall(r"\\right(?![A-Za-z])",segment))
            if depth or left_count!=right_count:
                raise AssertionError(f"unbalanced math grouping in {p.name}:{line}")
    ledger=(ROOT/"LEDGER.md").read_text()
    allowed=(r"PROVED\+MACHINE-CHECKED|PROVED\+INDEPENDENTLY-REDERIVED|"
             r"PROVED \(single derivation\)|PROVED-CONDITIONAL \(conditions listed\)|"
             r"REFUTED \(witness displayed\)|OPEN")
    ledger_status={m.group(1):m.group(2) for m in re.finditer(
        rf"\| (C-[A-Z0-9-]+)[^\n]*\| ({allowed}) \|",ledger)}
    theory_claims=set()
    for p in documents():
        body=p.read_text()
        for claim in re.findall(r"\{#(C-[A-Z0-9-]+)\}",body):
            theory_claims.add(claim)
            if claim not in ledger: raise AssertionError(f"missing ledger row {claim}")
        for claim,status in re.findall(rf"\{{#(C-[A-Z0-9-]+)\}} \*\*Status: ({allowed})\.\*\*",body):
            if ledger_status.get(claim)!=status:
                raise AssertionError(f"status mismatch {claim}: {status} / {ledger_status.get(claim)}")
    if theory_claims != set(ledger_status):
        raise AssertionError(f"ledger/theory claim mismatch: {sorted(set(ledger_status)^theory_claims)}")

def verify_manifest():
    data=json.loads((ROOT/"FROZEN_INPUT_CHECKSUMS.json").read_text())
    if data.get("algorithm")!="sha256" or not data.get("files"):
        raise AssertionError("checksum manifest is empty or malformed")
    source="phase_iv/iv_e_mathematical_hardening/formal/PhaseIVE.lean"
    copied=hashlib.sha256((ROOT/"lean"/"PhaseIVE.lean").read_bytes()).hexdigest()
    if data["files"].get(source)!=copied:
        raise AssertionError("vendored PhaseIVE.lean differs from frozen source")
    vendored={
        "src/vendored_iii_liveness.py":"phase_iii_b_typed_audit/passes/liveness/liveness_experiment.py",
        "src/vendored_iv.py":"phase_iv/iv_e_mathematical_hardening/src/witnesses.py",
        "src/vendored_vi.py":"phase_vi_answerability/src/witnesses.py",
        "src/vendored_vii.py":"phase_vii_answerable_learning/src/witnesses.py",
        "src/vendored_viii.py":"phase_viii_construction/src/witnesses.py",
        "src/vendored_ix.py":"phase_ix_flow_kernel/src/witnesses.py",
        "src/vendored_x.py":"phase_x_existence/src/witnesses.py",
        "src/vendored_xi.py":"phase_xi_theorem_ledger/src/witnesses.py",
    }
    for local,upstream in vendored.items():
        digest=hashlib.sha256((ROOT/local).read_bytes()).hexdigest()
        if data["files"].get(upstream)!=digest:
            raise AssertionError(f"vendored source differs from frozen source: {local}")

def run_lean():
    mathlib=pathlib.Path(os.environ.get("MATHLIB_DIR","/Users/anson/AgentFoundations"))
    if not (mathlib/"lakefile.lean").exists():
        raise RuntimeError("Mathlib not found; set MATHLIB_DIR to a Mathlib checkout")
    env=os.environ.copy()
    files=[ROOT/"lean"/"PhaseIVE.lean",ROOT/"lean"/"Aug8.lean"]
    for f in files:
        subprocess.run(["lake","env","lean",str(f)],cwd=mathlib,env=env,check=True)

if __name__=="__main__":
    audit_documents(); verify_manifest()
    suite=unittest.defaultTestLoader.discover(str(ROOT/"tests"),pattern="test_*.py")
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful(): sys.exit(1)
    run_lean()
    print("ALL GREEN: Tier A, Tier B, document audits, and Lean")
