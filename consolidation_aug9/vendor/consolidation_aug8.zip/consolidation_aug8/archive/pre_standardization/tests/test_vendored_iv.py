import unittest
from fractions import Fraction as Q

from src.vendored_iv import (
    canonical_staging_fraction,
    convergent_crossing_prefix,
    dynamic_order_costs,
    leverage_tight,
    polyhedral_nonunique_repairs,
    public_twin,
    six_case_version_space,
)


class HardenedWitnessTests(unittest.TestCase):
    def test_leverage_tight_witness(self):
        masses = leverage_tight(Q(1, 2), Q(2, 3), Q(4, 5))
        self.assertEqual(masses[0], Q(4, 15))
        self.assertEqual(sum(masses), 1)

    def test_moving_book_harmonic_prefix(self):
        gains, total = convergent_crossing_prefix(4, 20)
        self.assertEqual(gains[0], Q(1, 2))
        self.assertEqual(total, sum(Q(2, n) for n in range(4, 21)))
        self.assertGreater(total, 2)

    def test_polyhedral_repair_nonuniqueness(self):
        self.assertEqual(polyhedral_nonunique_repairs(Q(0)), (Q(3, 4), Q(1, 4)))
        self.assertEqual(polyhedral_nonunique_repairs(Q(1)), (Q(1, 4), Q(3, 4)))

    def test_canonical_two_thirds(self):
        self.assertEqual(canonical_staging_fraction(), Q(2, 3))

    def test_dynamic_order_values(self):
        self.assertEqual(dynamic_order_costs(), (Q(7, 40), Q(1, 10)))

    def test_six_case_selection_and_holdout(self):
        result = six_case_version_space()
        self.assertEqual(result["eligible"], ("high-dependency",))
        self.assertEqual(result["selected"], "high-dependency")
        self.assertTrue(result["c4"])
        self.assertFalse(result["c5"])

    def test_public_twins(self):
        rule = lambda history: tuple(reversed(history))
        self.assertEqual(*public_twin(rule, (1, 2, 3)))


if __name__ == "__main__":
    unittest.main()

