"""Tier B: adapted copies of long-tail exact witness assertions.

Provenance and source hashes are recorded in VERIFICATION.md and the checksum
manifest.  These tests preserve, but do not upgrade, the source evidence.
"""
from fractions import Fraction as Q
import unittest
from src.exact import *


class TierBVendored(unittest.TestCase):
    def test_stock_lock_and_product_chain(self):
        self.assertEqual(Q(1,4)+Q(1,4),Q(1,2))
        self.assertEqual(Q(4,5)*Q(3,4)*Q(2,3),Q(2,5))
        self.assertEqual(Q(9,4),Q(2)+Q(1,4))
        self.assertLess(Q(9,4),Q(3)); self.assertEqual(Q(3,2),Q(6,4))
        self.assertEqual(Q(55,32),Q(55,32))
        self.assertLessEqual(Q(1,2),Q(1,2)); self.assertGreater(Q(2,3),Q(1,2))

    def test_drift_and_propagation_fixtures(self):
        self.assertEqual([Q(1,4)+i*Q(1,8) for i in range(5)],
                         [Q(1,4),Q(3,8),Q(1,2),Q(5,8),Q(3,4)])
        self.assertEqual(Q(3,4)-Q(5,8),Q(1,8))
        self.assertEqual(Q(1)//Q(1,4),4)
        self.assertEqual(3+(3+1)*4,19)
        for k in range(1,8):
            self.assertGreaterEqual(Q(k+1,k+2),Q(2,3))

    def test_dynamic_order_counterexample(self):
        self.assertEqual(Q(7,40)-Q(1,10),Q(3,40))

    def test_maximal_staging(self):
        lam=Q(2,3)
        self.assertEqual(Q(3,10)*lam-Q(3,20),Q(1,20))

    def test_queue_bounds(self):
        rho,beta,capacity=Q(1),Q(2),Q(2)
        self.assertEqual(beta,2); self.assertEqual(2*beta+rho,5)
        self.assertEqual((2*beta+rho+capacity-1)//capacity,3)
        self.assertGreater(Q(3)*9,Q(2)*(9+4))

    def test_flow_bypass_original(self):
        self.assertTrue(pooled_bypass(Q(1),Q(1,4),Q(9,8)))
        self.assertEqual((Q(1),Q(1)+Q(1,4)),(Q(1),Q(5,4)))

    def test_compiler_extremes(self):
        a=(Q(1,3),Q(1,2))
        independent=caccrual(a)
        self.assertLessEqual(cmax(a),independent); self.assertLess(independent,Q(1))

    def test_six_case_version_space(self):
        self.assertEqual(six_case_selection(),
                         (("high-dependency",),"high-dependency",True,False))


if __name__ == "__main__": unittest.main()
