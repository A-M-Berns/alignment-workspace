import unittest
from fractions import Fraction as Q

from src.vendored_iii_liveness import (
    Job,
    aggregate_sources,
    aggregation_conserves_identity,
    arrival_envelope_holds,
    fifo_simulate,
    flooding_witness,
    identity_conserved,
    identity_vector,
    history_identity_conserved,
    lossy_aggregate_signature,
    newest_first_starvation_prefix,
    qualified_fairness_bounds,
    shared_response_covers_every_source,
)


class LivenessPassTests(unittest.TestCase):
    def test_flooding_witness_is_exact(self):
        horizon, demand, service = flooding_witness(Q(2), Q(3), 4)
        self.assertEqual(horizon, 9)
        self.assertEqual(demand, 27)
        self.assertEqual(service, 26)

    def test_fifo_overload_preserves_every_identity(self):
        batches = tuple(
            (Job(f"a-{t}", Q(1)), Job(f"b-{t}", Q(1))) for t in range(6)
        )
        trace = fifo_simulate(batches, Q(1))
        self.assertTrue(identity_conserved(batches, trace))
        self.assertTrue(any(step.overload_announced for step in trace))
        self.assertEqual(trace[-1].workload_after_service, Q(6))

    def test_token_bucket_fixture_obeys_qualified_bounds(self):
        workloads = (Q(3), Q(0), Q(2), Q(0), Q(1), Q(1))
        self.assertTrue(arrival_envelope_holds(workloads, Q(1), Q(2)))
        bounds = qualified_fairness_bounds(Q(2), Q(1), Q(2))
        self.assertEqual(bounds.backlog_after_service, Q(2))
        self.assertEqual(bounds.workload_before_service, Q(5))
        self.assertEqual(bounds.fifo_completion_rounds, 3)
        batches = tuple(
            tuple(Job(f"{t}-{j}", Q(1)) for j in range(int(work)))
            for t, work in enumerate(workloads)
        )
        trace = fifo_simulate(batches, Q(2))
        self.assertLessEqual(
            max(step.workload_after_service for step in trace),
            bounds.backlog_after_service,
        )

    def test_aggregation_conserves_formal_identities(self):
        left = identity_vector(("minority",))
        right = identity_vector(("majority",))
        aggregate = aggregate_sources("agg", ("minority", "majority"))
        self.assertTrue(
            aggregation_conserves_identity(
                (left, right), (aggregate.source_vector,), ()
            )
        )
        self.assertFalse(
            aggregation_conserves_identity(
                (left, right), (identity_vector(("majority",)),), ()
            )
        )
        self.assertTrue(
            history_identity_conserved((), (left,), (left,), ())
        )
        self.assertFalse(
            history_identity_conserved((), (left,), (right,), ())
        )

    def test_shared_work_needs_per_source_congruence(self):
        aggregate = aggregate_sources("agg", ("o-1", "o-2"))
        self.assertTrue(
            shared_response_covers_every_source(aggregate, ("o-1", "o-2"))
        )
        self.assertFalse(shared_response_covers_every_source(aggregate, ("o-1",)))

    def test_lossy_aggregation_cannot_distinguish_minority_identity(self):
        self.assertEqual(
            lossy_aggregate_signature("same-claim", ("majority", "minority")),
            lossy_aggregate_signature("same-claim", ("majority", "other")),
        )
        self.assertNotEqual(
            identity_vector(("majority", "minority")),
            identity_vector(("majority", "other")),
        )

    def test_newest_first_prefix_never_serves_old_item(self):
        for horizon in range(1, 8):
            observation = newest_first_starvation_prefix(horizon)
            self.assertFalse(observation.oldest_completed)
            self.assertEqual(observation.remaining_ids, ("old",))


if __name__ == "__main__":
    unittest.main()
