from fractions import Fraction as Q
import unittest
from src.exact import *


class TierAFresh(unittest.TestCase):
    def test_leverage_and_lp_dual(self):
        atoms=leverage_atoms(Q(3,4),Q(2,3),Q(4,5))
        self.assertEqual(sum(atoms),1)
        lhs,ds=leverage_slack(Q(3,4),Q(1,2),Q(2,5),Q(2,5),Q(3,4),Q(2,3),Q(4,5))
        self.assertEqual(lhs,0); self.assertEqual(ds,(0,0,0,0))
        cert=serviceability_lp_instance()
        self.assertEqual(cert["optimum"],Q(2,5))
        self.assertEqual(cert["optimum"],cert["dual_value"])
        self.assertIn(cert["sharp_atoms"],cert["vertices"])

    def test_of1_boundary_identity_and_audit_horizon(self):
        xs=[(Q(1),Q(-1)),(Q(2),Q(1)),(Q(-1),Q(2))]
        ps=[(Q(1,3),Q(2,3)),(Q(1,2),Q(1,2)),(Q(3,4),Q(1,4))]
        qs=[(Q(1,4),Q(3,4)),(Q(2,5),Q(3,5)),(Q(3,5),Q(2,5))]
        out=operative_force(xs,ps,qs,(Q(1),Q(0)))
        self.assertEqual(out["reference_gain"],out["anchor_plus_movement"])
        # No q_N is supplied: three trades have exactly two movements.
        self.assertEqual(len(qs)-1,2)

    def test_exhaustion_and_deadline_pair(self):
        gamma=Q(1,4)
        self.assertEqual(stock_deadline(Q(1),gamma),4)
        self.assertEqual(exhaustion_time(Q(1),lambda _:gamma,lambda _:Q(0)),5)
        self.assertEqual(pure_constant_exhaustion(Q(1),gamma),5)
        self.assertIsNone(exhaustion_time(Q(1),lambda _:gamma,lambda _:gamma,100))

    def test_stock_refutations_and_flow_fates(self):
        # D3 stock: each unmatched false exposed floor can consume one stake.
        self.assertEqual(8*Q(1,4),Q(2))
        # Flow: every completed challenge drains stake plus rent, so finite F0 bounds runs.
        self.assertEqual(Q(2)//(Q(1,4)+Q(1,4)),4)
        # A0: a true floor can be suspended at effective age two in stock semantics.
        self.assertEqual(stock_deadline(Q(1),Q(1,2)),2)

    def test_repair_completeness_plus_minus_route(self):
        def succeeds(route_present): return route_present and True
        self.assertFalse(succeeds(False)); self.assertTrue(succeeds(True))

    def test_dk_specialization_and_one_unit_failures(self):
        d=dk_numbers()
        self.assertEqual(d["p_suf"],Q(79,32)); self.assertEqual(d["w_suf"],Q(31,8))
        self.assertEqual(d["p_min"],Q(17,32)); self.assertEqual(d["w_min"],Q(1,2))
        self.assertEqual(d["total_min"],Q(33,32))
        self.assertEqual(peak_endowment([d["p_min"]],[Q(0)]),d["p_min"])
        self.assertEqual(peak_endowment([d["w_min"]],[Q(0)]),d["w_min"])
        self.assertLess(d["p_min"]-d["rent_unit"],peak_endowment([d["p_min"]],[Q(0)]))
        self.assertLess(d["w_min"]-d["rent_unit"],peak_endowment([d["w_min"]],[Q(0)]))

    def test_repeated_complaint_regimes(self):
        d=dk_numbers()
        self.assertEqual(d["revenue"],Q(3,32)); self.assertEqual(d["loose_revenue"],3)
        self.assertTrue(pooled_bypass(Q(1),Q(1,4),Q(9,8)))
        self.assertFalse(pooled_bypass(Q(1),Q(1,4),Q(5,4)))

    def test_epoch_self_financing_and_intra_cycle_deficit(self):
        x=epoch_financing(2,1,0,0,Q(1,4),Q(1,2))
        self.assertEqual(x["intra_cycle_deficit"],Q(1,2))
        self.assertEqual(x["closure_income"],Q(1,2))

    def test_gauge_and_compiler_shocks(self):
        r={"a":Q(1,3),"b":Q(2,3)}; p={"a":"b","b":"a"}
        self.assertEqual(invariant_total(r),invariant_total(conjugate_record(r,p)))
        levels=(Q(1,3),Q(1,2),Q(3,4))
        self.assertEqual(compiler_shock(cmax,levels,0),0)
        self.assertEqual(compiler_shock(cmax,levels,2),Q(1,4))
        self.assertEqual(caccrual((Q(1,2),Q(3,4)))-caccrual((Q(1,2),)),Q(3,8))

    def test_pooling_and_peak_alignment(self):
        aligned=[(Q(2),Q(3)),(Q(1),Q(1))]
        local,pooled=account_minima(aligned)
        self.assertEqual((local,pooled),(Q(5),Q(5)))
        unaligned=[(Q(2),Q(0)),(Q(0),Q(3))]
        local,pooled=account_minima(unaligned)
        self.assertEqual((local,pooled),(Q(5),Q(3)))

    def test_other_displayed_exact_values(self):
        q=Q(1,3)
        self.assertEqual((Q(3,4)-q/2)+(Q(1,4)+q/2),Q(1))
        self.assertEqual(Q(2,3)-Q(1,3),Q(1,3))
        n=7
        self.assertEqual((Q(1,2)+Q(1,n))-(Q(1,2)-Q(1,n)),Q(2,n))
        self.assertEqual(Q(3,4),Q(1,2)+Q(3,4)*Q(1,3)*(1-Q(1,2))+Q(1,8))
        # Binary full coupling: theta in [0,1/2] gives posterior 2 theta in [0,1].
        self.assertEqual(2*Q(0),Q(0)); self.assertEqual(2*Q(1,2),Q(1))
        alpha,m,n=Q(1,2),Q(3,4),Q(1,2)
        self.assertLessEqual(alpha*m,n)
        self.assertEqual((n-alpha*m)/(1-alpha),Q(1,4))


if __name__ == "__main__": unittest.main()
