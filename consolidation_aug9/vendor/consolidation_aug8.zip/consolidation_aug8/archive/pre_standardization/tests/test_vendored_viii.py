import unittest
from fractions import Fraction as Q

from src.vendored_viii import (
    ArcEdge,
    ArcNode,
    certify_arc_paths,
    construction_outflow_bound,
    least_valid_block,
    procedure_lock,
    residual_lock_certificate,
    reusable_cycle,
    run_lexicographic_policy,
    world_challenger_net,
    world_lock,
)


class MechanismWitnessTests(unittest.TestCase):
    def test_msr_kills_consistent_floor_martyr(self) -> None:
        self.assertEqual(world_lock(Q(1, 4), 100), Q(1, 4))
        self.assertLessEqual(world_lock(Q(1, 4), 100), Q(1))
        self.assertGreater(procedure_lock(Q(1, 4), 2, Q(1, 2)), Q(1))

    def test_latency_inflation_repair(self) -> None:
        self.assertEqual(
            least_valid_block([1] * 5, Q(1), Q(1, 6)), 1
        )
        self.assertEqual(
            least_valid_block([0] * 9, Q(0), Q(1, 6)), 1
        )

    def test_missing_route_world_extraction(self) -> None:
        self.assertEqual(world_challenger_net(Q(1, 4), Q(1, 2), [0]), Q(1, 4))
        self.assertEqual(world_challenger_net(Q(1, 4), Q(1, 2), [1]), Q(-1, 4))

    def test_silent_false_floor_has_no_transfer(self) -> None:
        challenger_filings = ()
        self.assertEqual(sum(challenger_filings, Q(0)), Q(0))

    def test_structured_witness_residual_adequacy(self) -> None:
        result = residual_lock_certificate(
            Q_service=8,
            rho=2,
            beta=2,
            w_min=1,
            max_stake=Q(1, 8),
            gamma=Q(1, 64),
            procedure_reserve=Q(2),
            world_slots=8,
            world_reserve=Q(1),
            capacity=Q(3),
        )
        self.assertEqual(result["service_delay"], Q(1))
        self.assertEqual(result["open_count"], Q(6))
        self.assertEqual(result["procedure_lock_bound"], Q(27, 32))
        self.assertEqual(result["actual_total_lock_bound"], Q(59, 32))

    def test_msr_adequacy_witness_fails(self) -> None:
        self.assertGreater(procedure_lock(Q(1, 4), 2, Q(1, 2)), Q(1))


class ArcAndConstructionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.nodes = {
            "false": ArcNode("false", 1, ("exposed-false",)),
            "suspended": ArcNode("suspended", 0, ()),
        }
        self.edges = (
            ArcEdge(
                "false", "suspended", "exposed-false", Q(1, 3)
            ),
        )

    def test_one_route_arc_certificate(self) -> None:
        certify_arc_paths(
            self.nodes,
            self.edges,
            {("false", "exposed-false"): ("exposed-false",)},
        )

    def test_policy_trace_stabilizes(self) -> None:
        self.assertEqual(
            run_lexicographic_policy("false", self.nodes, self.edges),
            ("false", "suspended"),
        )

    def test_missing_route_is_not_arc(self) -> None:
        with self.assertRaises(AssertionError):
            certify_arc_paths(self.nodes, (), {})

    def test_consumption_cycle_does_not_stabilize(self) -> None:
        trace = reusable_cycle(8)
        self.assertEqual(trace[0], trace[-1])
        self.assertEqual(len(set(trace)), 2)

    def test_construction_bound_is_exact_rational(self) -> None:
        bound = construction_outflow_bound(
            world_slots=2,
            extraction=Q(1, 4),
            initial_false=1,
            schemas=2,
            route_budget=1,
            route_cost=Q(1, 3),
            defect_kinds=2,
            answer_cost=Q(1, 10),
        )
        self.assertEqual(bound, Q(79, 30))
        self.assertIsInstance(bound, Q)


if __name__ == "__main__":
    unittest.main()
