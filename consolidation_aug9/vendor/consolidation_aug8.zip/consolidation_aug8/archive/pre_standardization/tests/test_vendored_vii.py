import ast
from fractions import Fraction
from pathlib import Path
import re
import unittest

from src.vendored_vii import (
    BridgeGapWitness,
    cesaro_endpoints,
    consumption_status_change_bound,
    cycle_prefix,
    first_cap_crossing,
    floor_address_is_valid,
    grounds_constructible,
    maximum_false_losses,
    operational_lock_bound,
    pas_product,
    service_delay,
    universal_policy_obstruction,
    warrant_closure,
)


class PhaseVIIWitnessTests(unittest.TestCase):
    def test_a0_bridge_gap(self) -> None:
        witness = BridgeGapWitness()
        self.assertTrue(witness.certifies_gap())
        self.assertEqual(witness.lock(2), Fraction(5, 4))

    def test_constructibility_and_forgery_rejection(self) -> None:
        warrants = (
            (frozenset({"cap:R0"}), "defect:above-half"),
            (frozenset({"seed:P", "warrant:P-A"}), "claim:PA"),
        )
        closure = warrant_closure({"cap:R0"}, warrants)
        self.assertIn("defect:above-half", closure)
        self.assertTrue(
            grounds_constructible({"defect:above-half"}, {"cap:R0"}, warrants)
        )
        self.assertFalse(
            grounds_constructible({"forged:defect"}, {"cap:R0"}, warrants)
        )

    def test_a2_addressing_and_whitewash(self) -> None:
        self.assertTrue(floor_address_is_valid(Fraction(1, 2), Fraction(1, 2)))
        self.assertFalse(floor_address_is_valid(Fraction(2, 3), Fraction(1, 2)))

    def test_a3_split_drift_crossing(self) -> None:
        chain = (
            Fraction(1, 4),
            Fraction(3, 8),
            Fraction(1, 2),
            Fraction(5, 8),
            Fraction(3, 4),
        )
        self.assertEqual(first_cap_crossing(chain, Fraction(1, 2)), 3)
        self.assertTrue(all(right - left == Fraction(1, 8) for left, right in zip(chain, chain[1:])))

    def test_a4_rich_survival_bounds(self) -> None:
        self.assertEqual(
            pas_product(Fraction(4, 5), Fraction(3, 4), Fraction(2, 3)),
            Fraction(2, 5),
        )
        delay = max(service_delay(Fraction(2), Fraction(2), Fraction(8)), 4)
        self.assertEqual(delay, 4)
        self.assertEqual(
            operational_lock_bound(
                Fraction(2),
                Fraction(2),
                Fraction(1),
                delay,
                Fraction(1, 8),
                Fraction(1, 64),
            ),
            Fraction(9, 4),
        )
        self.assertLess(Fraction(9, 4), Fraction(3))
        self.assertEqual(6 * 4 * Fraction(1, 16), Fraction(3, 2))

    def test_b1_extraction_rate_bound(self) -> None:
        self.assertEqual(maximum_false_losses(Fraction(7, 4), Fraction(1, 4)), 7)

    def test_b2_cycle_never_stabilizes_on_prefix(self) -> None:
        prefix = cycle_prefix(20)
        self.assertEqual(set(prefix), {Fraction(1, 3), Fraction(2, 3)})
        self.assertTrue(all(left != right for left, right in zip(prefix, prefix[1:])))

    def test_b3_consumption_bound(self) -> None:
        self.assertEqual(
            consumption_status_change_bound({"r1": 2, "r2": 3}, 4),
            29,
        )

    def test_b4_cesaro_has_opposed_endpoint_subsequences(self) -> None:
        endpoints = cesaro_endpoints(12)
        odd = [point.a_fraction for point in endpoints if point.block % 2 == 1]
        even = [point.a_fraction for point in endpoints if point.block % 2 == 0]
        self.assertGreater(odd[-1], Fraction(5, 6))
        self.assertLess(even[-1], Fraction(1, 7))

    def test_b5_universal_construction_obstruction(self) -> None:
        self.assertTrue(
            universal_policy_obstruction(
                Fraction(1, 2), Fraction(0), Fraction(1, 2), Fraction(1), 0
            )
        )
        self.assertFalse(
            universal_policy_obstruction(
                Fraction(1, 2), Fraction(0), Fraction(1, 2), Fraction(1), 1
            )
        )

    def test_no_float_literals_in_source(self) -> None:
        source = Path(__file__).parents[1] / "src" / "vendored_vii.py"
        tree = ast.parse(source.read_text(encoding="utf-8"))
        floats = [
            node
            for node in ast.walk(tree)
            if isinstance(node, ast.Constant) and isinstance(node.value, float)
        ]
        self.assertEqual(floats, [])

    @unittest.skip("superseded by the consolidation claim/status audit")
    def test_decision_ledger(self) -> None:
        ledger = (Path(__file__).parents[1] / "DECISION_LEDGER.md").read_text(
            encoding="utf-8"
        )
        rows = re.findall(
            r"^\| ([AB][1-5]) [^|]*\| \*\*(PROVED|REFUTED|BLOCKED)\*\* \|",
            ledger,
            flags=re.MULTILINE,
        )
        self.assertEqual(
            dict(rows),
            {
                "A1": "PROVED",
                "A2": "PROVED",
                "A3": "PROVED",
                "A4": "PROVED",
                "B1": "PROVED",
                "B2": "REFUTED",
                "B3": "PROVED",
                "B4": "REFUTED",
                "B5": "REFUTED",
            },
        )
        self.assertIn("| **REFUTED** | The Phase VI reverse implication", ledger)


if __name__ == "__main__":
    unittest.main()
