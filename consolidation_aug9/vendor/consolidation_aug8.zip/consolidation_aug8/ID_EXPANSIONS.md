# Stable identifier expansions
Stable identifiers are frozen. This table records the pre-pass and canonical expansions; unchanged expansions are listed too so the map is exhaustive.
| ID | Old expansion | New expansion | Source tree |
|---|---|---|---|
| `AM-E1` | exact harm-refinement trace | exact harm-refinement trace | `normative-learner` |
| `AM-J0` | occurrence-cell conservation | occurrence-cell conservation | `normative-learner` |
| `AM-J1` | finite migration verifier | finite migration verifier | `normative-learner` |
| `AM-J2` | migration reference-shock theorem | migration reference-jump theorem | `normative-learner` |
| `AM-J3` | one-step accountable migration theorem | one-step accountable migration theorem | `normative-learner` |
| `AM-J4` | local discrepancy composition | local discrepancy composition | `normative-learner` |
| `AM-N1` | finite revision trilemma | finite revision trilemma | `normative-learner` |
| `AM-X1` | preserved claim/lost ancestry | preserved claim/lost ancestry | `normative-learner` |
| `AM-X10` | universal-arena underdetermination | universal-arena underdetermination | `normative-learner` |
| `AM-X11` | duplicate disposition cells | duplicate disposition cells | `normative-learner` |
| `AM-X12` | partial activation | partial activation | `normative-learner` |
| `AM-X13` | late burden reassignment | late burden reassignment | `normative-learner` |
| `AM-X14` | incomplete rollback | incomplete rollback | `normative-learner` |
| `AM-X15` | disclosure-as-loss-authorization | disclosure-as-loss-authorization | `normative-learner` |
| `AM-X16` | split authority duplication | split authority duplication | `normative-learner` |
| `AM-X17` | asserted terminal coverage | asserted eventual route coverage | `normative-learner` |
| `AM-X2` | split challenge orphan | split challenge orphan | `normative-learner` |
| `AM-X3` | merged incompatibility loss | merged incompatibility loss | `normative-learner` |
| `AM-X4` | changed outstanding payoff | changed outstanding payoff | `normative-learner` |
| `AM-X5` | preactivation force | preactivation force | `normative-learner` |
| `AM-X6` | inexpressibility-as-discharge | inexpressibility-as-discharge | `normative-learner` |
| `AM-X7` | duplicate loss entry | duplicate loss entry | `normative-learner` |
| `AM-X8` | coupling-as-authorization | coupling-as-authorization | `normative-learner` |
| `AM-X9` | lossless collapse | lossless collapse | `normative-learner` |
| `C-ACTIVATION` | proposal/activation separation | proposal/activation separation | `consolidation_aug8` |
| `C-ADDRESS` | persistent addressing | persistent addressing | `consolidation_aug8` |
| `C-ALIAS` | visible-definition alias invariance | visible-definition alias invariance | `consolidation_aug8` |
| `C-ALLOC-NONUNIQ` | allocation nonuniqueness | allocation nonuniqueness | `consolidation_aug8` |
| `C-APPEND` | append-only persistence | append-only persistence | `consolidation_aug8` |
| `C-BARE-BRIDGE` | bare stock bridge | bare stock bridge | `consolidation_aug8` |
| `C-BRIDGE` | relativized biconditional | relativized biconditional | `consolidation_aug8` |
| `C-BRIDGE-FAIL` | bare bridge failure | bare bridge failure | `consolidation_aug8` |
| `C-CERT` | certificate region | certificate region | `consolidation_aug8` |
| `C-CESARO` | Cesàro stabilization failure | Cesàro stabilization failure | `consolidation_aug8` |
| `C-CHAIN-CAL` | chain calibration | chain calibration | `consolidation_aug8` |
| `C-COMPILER` | core-certified relaxation | core-certified relaxation | `consolidation_aug8` |
| `C-COMPOSE` | end-to-end composition | end-to-end composition | `consolidation_aug8` |
| `C-CONS-EXT` | projection-conservative extension | projection-conservative extension | `consolidation_aug8` |
| `C-CONSUME` | consuming stabilization | consuming stabilization | `consolidation_aug8` |
| `C-COUP-CHAR` | posterior characterization | posterior characterization | `consolidation_aug8` |
| `C-COUP-NC` | full-coupling non-contraction | full-coupling non-contraction | `consolidation_aug8` |
| `C-CROSS-EFFECT` | pooled cross-effect | pooled cross-effect | `consolidation_aug8` |
| `C-DRIFT` | frozen-origin accounting | frozen-origin drift cap | `consolidation_aug8` |
| `C-DUP` | represented-provenance duplication invariance | represented-provenance duplication invariance | `consolidation_aug8` |
| `C-EXPOSED-CONV` | exposed convergence | capped-outflow exposed convergence | `consolidation_aug8` |
| `C-FEATURE-EXT` | feature-interface extensionality | feature-interface extensionality | `consolidation_aug8` |
| `C-FIXED-ENDPOINT` | fixed-endpoint acquisition boundary | fixed-endpoint acquisition boundary | `consolidation_aug8` |
| `C-FIXED-KERNEL` | fixed-transition boundary | fixed-transition boundary | `consolidation_aug8` |
| `C-FLOW-EXHAUST` | exact flow exhaustion | exact flow exhaustion | `consolidation_aug8` |
| `C-FLOW-FALSE` | false-floor flow fate | false-bound flow fate | `consolidation_aug8` |
| `C-FLOW-GAUGE` | flow conjugacy | flow conjugacy | `consolidation_aug8` |
| `C-GN1` | no inflow-independent deadline | no inflow-independent deadline | `consolidation_aug8` |
| `C-GN2` | no first-rent bootstrap | no first-charge bootstrap | `consolidation_aug8` |
| `C-GN3` | exact pooled interval | exact pooled interval | `consolidation_aug8` |
| `C-GN4` | transient coverage unnecessary | transient coverage unnecessary | `consolidation_aug8` |
| `C-GN5` | repair rent/incentive frontier | repair charge/incentive frontier | `consolidation_aug8` |
| `C-GN6` | unbounded-key family | unbounded-key family | `consolidation_aug8` |
| `C-GP1` | uniform finite-kernel construction | uniform finite-mechanism construction | `consolidation_aug8` |
| `C-GP2` | exact endowment/gap | exact endowment/gap | `consolidation_aug8` |
| `C-GP3` | terminal-book biconditional | eventual-route-coverage biconditional | `consolidation_aug8` |
| `C-GP4` | admission fairness | admission fairness | `consolidation_aug8` |
| `C-GP5` | transfer characterization | transfer characterization | `consolidation_aug8` |
| `C-GP6A` | coarsening monotonicity | coarsening monotonicity | `consolidation_aug8` |
| `C-GP6B` | peak synchronization | peak synchronization | `consolidation_aug8` |
| `C-GP7` | repeated-complaint regimes | repeated-complaint regimes | `consolidation_aug8` |
| `C-GP8` | record-automorphism invariance | record-automorphism invariance | `consolidation_aug8` |
| `C-GP9` | compiler shocks/extremes | reference jumps/extremes | `consolidation_aug8` |
| `C-INF-CLOSE` | finite closure | finite closure | `consolidation_aug8` |
| `C-LEV` | leverage theorem | leverage theorem | `consolidation_aug8` |
| `C-MAX-STAGE` | maximal stage | maximal stage | `consolidation_aug8` |
| `C-MIGRATION` | collateralized migration | collateralized migration | `consolidation_aug8` |
| `C-MOVE-AGG` | static aggregation | static aggregation | `consolidation_aug8` |
| `C-MOVE-MIN` | local charge minimum | local liability minimum | `consolidation_aug8` |
| `C-MOVE-OBS` | moving-region obstruction | moving-region obstruction | `consolidation_aug8` |
| `C-MOVING-INTERFACE` | positive moving-correspondence interface | positive moving-correspondence interface | `consolidation_aug8` |
| `C-NETWORK` | network LP/dual | network LP/dual | `consolidation_aug8` |
| `C-NO-FALSE-COMPLETE` | positive remainder exclusion | positive remainder exclusion | `consolidation_aug8` |
| `C-NO-ROUTE` | missing-route obstruction | missing-route obstruction | `consolidation_aug8` |
| `C-OF-IND` | individual corollary | individual corollary | `consolidation_aug8` |
| `C-OF0` | anchored comparison | anchored comparison | `consolidation_aug8` |
| `C-OF1` | operative-force wealth | operative-force wealth cap | `consolidation_aug8` |
| `C-OF2` | variable core | variable core | `consolidation_aug8` |
| `C-OFSB` | repaired summation identity | repaired summation identity | `consolidation_aug8` |
| `C-ONTOLOGY-NI` | ontology noninterference | ontology noninterference | `consolidation_aug8` |
| `C-PRIOR-CORR` | prior-authorized correction | prior-authorized correction | `consolidation_aug8` |
| `C-PROGRESS-NOSCALAR` | no intrinsic fraction order | no intrinsic fraction order | `consolidation_aug8` |
| `C-PROV-IRR` | provenance irreducibility | provenance irreducibility | `consolidation_aug8` |
| `C-QUEUE-FIFO` | token-envelope FIFO | token-envelope FIFO cap | `consolidation_aug8` |
| `C-QUEUE-ID` | identity conservation | identity conservation | `consolidation_aug8` |
| `C-QUEUE-OVERLOAD` | waiting impossibility | waiting impossibility | `consolidation_aug8` |
| `C-REC-EXT` | record extensionality | record extensionality | `consolidation_aug8` |
| `C-RECOGNITION` | recognition without service | recognition without service | `consolidation_aug8` |
| `C-REPAIR-CERT` | finite repair certificate | finite repair certificate | `consolidation_aug8` |
| `C-REVISION-CYCLE` | reusable-route cycle | reusable-route cycle | `consolidation_aug8` |
| `C-SCALAR-NOGO` | shared-scalar impossibility | shared-scalar impossibility | `consolidation_aug8` |
| `C-SELF-FIN` | self-financing separation | self-financing separation | `consolidation_aug8` |
| `C-SELF-SUPPORT` | audit-relative self-support exclusion | audit-relative self-support exclusion | `consolidation_aug8` |
| `C-SEPARATED` | separated-service crossing | separated-service crossing | `consolidation_aug8` |
| `C-SIX-CASE` | six-case audit | six-case audit | `consolidation_aug8` |
| `C-SOLV-AUTH` | solvency/authorization/priority separation | solvency/authorization/priority separation | `consolidation_aug8` |
| `C-STAGE-SAFE` | staged safety | staged safety | `consolidation_aug8` |
| `C-STATIONARY-SERVICE` | decomposition | decomposition | `consolidation_aug8` |
| `C-STOCK-CONCUR` | same-day stock bound | same-day stock cap | `consolidation_aug8` |
| `C-STOCK-CONSTRUCT` | restricted stock construction | restricted stock construction | `consolidation_aug8` |
| `C-STOCK-DEADLINE` | stock deadline | stock deadline | `consolidation_aug8` |
| `C-STOCK-FALSE` | persistent false stock floor | persistent false stock bound | `consolidation_aug8` |
| `C-STOCK-GAUGE` | stock conjugacy | stock conjugacy | `consolidation_aug8` |
| `C-SUCCESSOR` | successor self-endorsement obstruction | successor self-endorsement obstruction | `consolidation_aug8` |
| `C-TARGET` | target persistence/completion | target persistence/completion | `consolidation_aug8` |
| `C-TARGET-LIVE` | conditional completion | conditional completion | `consolidation_aug8` |
| `C-TRANSFER-LOCAL` | local nonpropagation | local nonpropagation | `consolidation_aug8` |
| `C-TRANSFER-UNDER` | extensional transfer underdetermination | extensional transfer underdetermination | `consolidation_aug8` |
| `C-VERSION` | finite version space | finite version space | `consolidation_aug8` |
| `NL-E1` | Exact joint trace claim. | Exact joint trace claim. | `normative-learner` |
| `NL-J0` | Joint-certificate decidability. | Joint-certificate decidability. | `normative-learner` |
| `NL-J1` | Compiler-shock payoff-range lemma. | Reference-jump payoff-range lemma. | `normative-learner` |
| `NL-J2` | Finite compiler-shock bound. | Finite reference jump cap. | `normative-learner` |
| `NL-J3` | Joint theorem. | Joint theorem. | `normative-learner` |
| `NL-J4` | Typed liability decomposition. | Typed liability decomposition. | `normative-learner` |
| `NL-X1` | 1. Proposal-bypass witness. | 1. Proposal-bypass witness. | `normative-learner` |
| `NL-X10` | 10. Duplicate-channel witness. | 10. Duplicate-channel witness. | `normative-learner` |
| `NL-X11` | 11. Market-priority interference witness. | 11. Market-priority interference witness. | `normative-learner` |
| `NL-X12` | 12. Reusable-crossing witness. | 12. Reusable-crossing witness. | `normative-learner` |
| `NL-X13` | 13. Finite-change-only movement cap. | 13. Finite-change-only movement cap. | `normative-learner` |
| `NL-X14` | 14. Quote-before-activation witness. | 14. Quote-before-activation witness. | `normative-learner` |
| `NL-X15` | 15. Late-account-assignment witness. | 15. Late-account-assignment witness. | `normative-learner` |
| `NL-X16` | 16. Suspension-shock boundary. | 16. Suspension-jump boundary. | `normative-learner` |
| `NL-X17` | 17. Service-inadequacy witness. | 17. Service-inadequacy witness. | `normative-learner` |
| `NL-X18` | 18. Uncertified-compiler activation witness. | 18. Uncertified-compiler activation witness. | `normative-learner` |
| `NL-X2` | 2. Unrecorded-movement witness. | 2. Unrecorded-movement witness. | `normative-learner` |
| `NL-X3` | 3. Shared-reward-scalar obstruction. | 3. Shared-reward-scalar obstruction. | `normative-learner` |
| `NL-X4` | 4. Funding-to-authorization obstruction. | 4. Funding-to-authorization obstruction. | `normative-learner` |
| `NL-X5` | 5. Compiled-suspension witness. | 5. Compiled-suspension witness. | `normative-learner` |
| `NL-X6` | 6. Expansion-stable suspension. | 6. Expansion-stable suspension. | `normative-learner` |
| `NL-X7` | 7. Pooled protected-trace witness. | 7. Pooled protected-trace witness. | `normative-learner` |
| `NL-X8` | 8. Geometry-only repair obstruction. | 8. Geometry-only repair obstruction. | `normative-learner` |
| `NL-X9` | 9. No-disposition obstruction. | 9. No-disposition obstruction. | `normative-learner` |
