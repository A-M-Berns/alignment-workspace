"""Exact-rational Phase X witnesses.

Every function certifies a finite trace or bound cited in `PROOFS.md`.  There
is no simulation, randomness, or floating point.  Phase VI--IX are read as
statements only; no upstream module is imported.

The ledger evaluator below is the shared engine.  A *schedule* is a list of
`Event` records in nondecreasing (date, step) order.  A positive amount is a
book obligation (outflow), a negative amount is a receipt.  Step numbers are
the Model IX date-order positions:

    1  scheduled outcomes / maturity
    3  due obligation processed by immutable challenge ID
    5  committed response, revision, disposition, then door admission

The evaluator applies the Model IX atomic rule: an obligation of amount a is
paid iff the designated account holds at least a, otherwise the insolvency
trigger fires and nothing is transferred.
"""

from dataclasses import dataclass
from fractions import Fraction
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple


Q = Fraction

WORLD = "W"
PROCEDURE = "P"
MERGED = "M"


# ---------------------------------------------------------------- ledger core


@dataclass(frozen=True)
class Event:
    date: int
    step: int
    account: str
    amount: Fraction
    kind: str
    cid: str = ""


@dataclass(frozen=True)
class RunResult:
    final: Dict[str, Fraction]
    peak_deficit: Dict[str, Fraction]
    triggered: Tuple[Tuple[int, str, str, Fraction], ...]

    @property
    def any_trigger(self) -> bool:
        return bool(self.triggered)


def _sorted(schedule: Iterable[Event]) -> List[Event]:
    return sorted(schedule, key=lambda e: (e.date, e.step))


def run_ledger(
    schedule: Iterable[Event], reserves: Mapping[str, Fraction]
) -> RunResult:
    """Replay a schedule under the Model IX atomic payment rule."""
    balance = {account: Fraction(value) for account, value in reserves.items()}
    outflow = {account: Q(0) for account in balance}
    peak = {account: Q(0) for account in balance}
    triggered: List[Tuple[int, str, str, Fraction]] = []
    for event in _sorted(schedule):
        if event.account not in balance:
            raise KeyError(f"no reserve declared for account {event.account!r}")
        if event.amount > 0:
            if balance[event.account] < event.amount:
                triggered.append(
                    (event.date, event.account, event.kind, event.amount)
                )
                continue
            balance[event.account] -= event.amount
            outflow[event.account] += event.amount
        else:
            balance[event.account] -= event.amount
            outflow[event.account] += event.amount
        if outflow[event.account] > peak[event.account]:
            peak[event.account] = outflow[event.account]
    return RunResult(
        final=dict(balance), peak_deficit=dict(peak), triggered=tuple(triggered)
    )


def minimal_reserve(schedule: Iterable[Event], account: str) -> Fraction:
    """Least initial balance of `account` funding every obligation.

    The peak of cumulative net outflow is exactly the least sufficient reserve:
    at that reserve no comparison fails, and any smaller rational reserve fails
    the obligation attaining the peak.
    """
    running = Q(0)
    peak = Q(0)
    for event in _sorted(schedule):
        if event.account != account:
            continue
        running += event.amount
        if running > peak:
            peak = running
    return peak


def merge_accounts(schedule: Iterable[Event]) -> List[Event]:
    """Delete the fencing: reassign every obligation to one pooled account."""
    return [
        Event(e.date, e.step, MERGED, e.amount, e.kind, e.cid)
        for e in _sorted(schedule)
    ]


def shift(schedule: Iterable[Event], dates: int) -> List[Event]:
    """Delay a whole sub-schedule; used by the peak-alignment lemma."""
    return [
        Event(e.date + dates, e.step, e.account, e.amount, e.kind, e.cid)
        for e in schedule
    ]


# ------------------------------------------------- displayed mechanism DK (§B-X.2)
#
# b = 4 schemas: beta1, beta2 exposed and settlement-false; beta3 exposed and
# settlement-consistent; Y unexposed normative.  d = 2 semantic objection kinds:
# d1 canonically answerable at reply cost zeta, d2 repair-only through route r3.
# Psi0 = 3 one-token routes r1, r2, r3, each of declared cost c_R on account P.

DK = {
    "gamma": Q(1, 64),
    "stake": Q(1, 8),
    "zeta": Q(1, 16),
    "c_R": Q(1, 8),
    "D_P": 1,
    "n_P": 6,
    "J_W": 2,
    "D_W": 4,
    "Psi0": 3,
    "b": 4,
    "d": 2,
    "F_0": 2,
}


def dk_charge(dates: int) -> Fraction:
    return dates * DK["gamma"]


def dk_anti_nuisance_holds() -> bool:
    """(AN): the declared bond exceeds the drip over the declared latency."""
    return DK["stake"] > dk_charge(DK["D_P"]) and DK["stake"] > dk_charge(DK["D_W"])


def dk_transient_date_cap() -> int:
    """C2.1a transient date cap reused under flow."""
    return (DK["Psi0"] + DK["b"] * (DK["Psi0"] + 1) * DK["d"]) * DK["D_P"]


def dk_procedure_schedule() -> List[Event]:
    """Worst-case procedure-account run for Pi^X on DK.

    Date 0: the policy publishes the one canonical response for (Y,d1) and
    releases repair r1; n_P substantive duplicate filings on the repair-only
    key (Y,d2) are admitted.  Date 1: their charge falls due, r2 and r3 are
    charged, and r3 commits as an authorized revision -- so every stake is
    RETURNED and the account receives no income at all on this run.
    """
    gamma, c_R, zeta, n_P = DK["gamma"], DK["c_R"], DK["zeta"], DK["n_P"]
    events = [
        Event(0, 5, PROCEDURE, zeta, "canonical-response", "Y.d1"),
        Event(0, 5, PROCEDURE, c_R, "route-cost", "r1"),
    ]
    for j in range(n_P):
        events.append(Event(1, 3, PROCEDURE, gamma, "charge", f"P{j}"))
    events.append(Event(1, 5, PROCEDURE, c_R, "route-cost", "r2"))
    events.append(Event(1, 5, PROCEDURE, c_R, "route-cost", "r3"))
    # r3 is an authorized revision: stakes return, so no forfeiture credit.
    return events


def dk_world_schedule() -> List[Event]:
    """Worst-case world-account run for Pi^X on DK.

    beta1 is repair-pending from date 0, so both slots are filled against the
    still-open false bound beta2.  Those two frozen contracts settle at date 4
    and cost stake + R(4) each.  Dates 5-8 carry one tail cycle against the
    settlement-consistent bound beta3, whose forfeited stakes arrive only at
    date 8.
    """
    gamma, stake, J_W, m = DK["gamma"], DK["stake"], DK["J_W"], DK["D_W"]
    events: List[Event] = []
    for date in range(1, m + 1):
        for slot in range(J_W):
            # Model IX step 2 forms ONE atomic obligation per challenge per
            # date: the date's charge plus any world match maturing that date.
            due = gamma + stake if date == m else gamma
            kind = "charge+match" if date == m else "charge"
            events.append(Event(date, 3, WORLD, due, kind, f"W.false{slot}"))
    for date in range(m + 1, 2 * m + 1):
        for slot in range(J_W):
            events.append(Event(date, 3, WORLD, gamma, "charge", f"W.true{slot}"))
    for slot in range(J_W):
        events.append(Event(2 * m, 5, WORLD, -stake, "forfeit", f"W.true{slot}"))
    return events


def dk_schedule() -> List[Event]:
    return dk_procedure_schedule() + dk_world_schedule()


def dk_minimal_reserves() -> Dict[str, Fraction]:
    schedule = dk_schedule()
    return {
        PROCEDURE: minimal_reserve(schedule, PROCEDURE),
        WORLD: minimal_reserve(schedule, WORLD),
    }


def dk_sufficient_reserves() -> Dict[str, Fraction]:
    """(FOA-X): the sufficient combinatorial cap, not the minimum."""
    K_P = DK["Psi0"] * DK["c_R"] + DK["b"] * (DK["Psi0"] + 1) * DK["d"] * DK["zeta"]
    transient_cap, m = dk_transient_date_cap(), DK["D_W"]
    matches = DK["J_W"] * (-(-transient_cap // m)) + DK["J_W"]
    lam_W = matches * (DK["stake"] + dk_charge(DK["D_W"]))
    return {
        PROCEDURE: K_P + DK["n_P"] * dk_charge(DK["D_P"]),
        WORLD: lam_W + DK["J_W"] * dk_charge(DK["D_W"]),
    }


# ------------------------------------------------ A-X.2 necessity quadruple


def drop_foa_witness() -> RunResult:
    """Drop (FOA-R): the D5-flow death of an already-terminal book.

    One settlement-consistent exposed bound, canonical horizon 1, s=1/2,
    gamma=1/4, and zero reserve.  RouteCoverage holds vacuously, (AN) holds, the latency
    gate holds, the fencing holds.  The first charge obligation is unfunded.
    """
    schedule = [Event(1, 3, WORLD, Q(1, 4), "charge", "consistent-bound")]
    return run_ledger(schedule, {WORLD: Q(0)})


def drop_route_coverage_witness(
    reserve: Fraction = Q(3), stake: Fraction = Q(1, 2), gamma: Fraction = Q(1, 4)
) -> Dict[str, object]:
    """Drop RouteCoverage coverage: the B5/C3.1 uncorrectable false bound under flow.

    No authorized route exists, so no policy may revise or suspend the bound.
    The settlement-informed challenger recycles one stake forever; each
    completed date extracts stake + R(1).  Finite reserve therefore ends in a
    post-stationary insolvency suspension.
    """
    per_date = stake + gamma
    dates = int(reserve // per_date)
    schedule = [
        Event(2 * k + 1, 3, WORLD, per_date, "charge+match", f"date{k}")
        for k in range(dates + 1)
    ]
    result = run_ledger(schedule, {WORLD: reserve})
    return {
        "per_date_extraction": per_date,
        "funded_dates": dates,
        "trap": True,
        "result": result,
    }


def drop_latency_gate_witness() -> Dict[str, Fraction]:
    """Drop the latency gate: IX-A3 inflation against the constructed policy.

    Against a settlement-CONSISTENT terminal bound, a publisher-selected
    three-date window pays the challenger 3*gamma - s > 0 per date, so
    recurrent testing of a correct book drains it without bound.  The canonical
    least block restores the negative payoff.
    """
    stake, gamma = Q(1, 2), Q(1, 4)
    inflated = 3 * gamma - stake
    canonical = 1 * gamma - stake
    return {
        "inflated_challenger_net": inflated,
        "canonical_challenger_net": canonical,
        "book_net_outflow_per_date": inflated,
        "unbounded": inflated > 0,
    }


def fencing_merge_comparison() -> Dict[str, Fraction]:
    """Drop the fencing: merge the accounts at equal total endowment.

    A merged pool holds the sum of the two ring-fenced balances, so every
    comparison F >= a that succeeded under the fencing still succeeds.  On DK
    the delay-closed adversary can align the two peaks, so the merged minimum
    equals the ring-fenced sum and the fencing's liquidity premium is zero.
    """
    fenced = dk_minimal_reserves()
    aligned = dk_aligned_merged_schedule()
    merged_min = minimal_reserve(aligned, MERGED)
    return {
        "fenced_P": fenced[PROCEDURE],
        "fenced_W": fenced[WORLD],
        "fenced_total": fenced[PROCEDURE] + fenced[WORLD],
        "merged_min": merged_min,
        "premium": fenced[PROCEDURE] + fenced[WORLD] - merged_min,
    }


def dk_aligned_merged_schedule() -> List[Event]:
    """Peak-alignment run: the delay-closed adversary defers the P burst.

    The class is closed under delay, so the adversary maximizes over integer
    shifts of the whole procedure sub-schedule.  The maximizing shift makes the
    procedure peak fall inside the world account's pre-forfeiture deficit.
    """
    return merge_accounts(dk_world_schedule() + shift(
        dk_procedure_schedule(), best_alignment_delay()
    ))


def alignment_lemma_witness() -> Dict[str, Fraction]:
    """Lemma X.5 in isolation: delay-closure recovers the whole fenced sum.

    The world account carries one late obligation and no income; the procedure
    account carries an early charge repaid by an immediate forfeiture.  Merging
    the accounts saves the netted amount only while the adversary leaves the
    peaks apart.  Delaying the procedure filing onto the world peak date
    restores the full ring-fenced requirement.
    """
    world = [Event(3, 3, WORLD, Q(1), "charge+match", "w")]
    procedure = [
        Event(1, 3, PROCEDURE, Q(1, 4), "charge", "p"),
        Event(1, 5, PROCEDURE, Q(-1, 2), "forfeit", "p"),
    ]
    fenced = minimal_reserve(world, WORLD) + minimal_reserve(procedure, PROCEDURE)
    naive = minimal_reserve(merge_accounts(world + procedure), MERGED)
    aligned = max(
        minimal_reserve(merge_accounts(world + shift(procedure, k)), MERGED)
        for k in range(6)
    )
    return {
        "fenced_total": fenced,
        "merged_undelayed": naive,
        "merged_delay_optimized": aligned,
        "premium_against_delay_closed_class": fenced - aligned,
    }


def best_alignment_delay() -> int:
    """Delay maximizing the pooled peak; searched over the finite run window."""
    world = dk_world_schedule()
    procedure = dk_procedure_schedule()
    horizon = 2 * DK["D_W"] + 2
    best, argbest = Q(-1), 0
    for delay in range(horizon + 1):
        pooled = merge_accounts(world + shift(procedure, delay))
        peak = minimal_reserve(pooled, MERGED)
        if peak > best:
            best, argbest = peak, delay
    return argbest


# ------------------------------------------------ B-X.1 tail self-financing


def tail_challenge_net(
    *, stake: Fraction, dates: int, gamma: Fraction, forfeits: bool
) -> Fraction:
    """Book net gain from one completed tail challenge (positive is income)."""
    drip = dates * gamma
    return (stake - drip) if forfeits else -drip


def tail_cycle_balances(
    *, reserve: Fraction, stake: Fraction, dates: int, gamma: Fraction, cycles: int
) -> List[Fraction]:
    """Balances sampled at closure epochs: nondecreasing by (AN)."""
    balances = [reserve]
    for _ in range(cycles):
        balances.append(
            balances[-1] + tail_challenge_net(
                stake=stake, dates=dates, gamma=gamma, forfeits=True
            )
        )
    return balances


def tail_intracycle_dip(
    *, concurrent: int, dates: int, gamma: Fraction
) -> Fraction:
    """Peak unrecovered charge inside one tail cycle: the working capital."""
    return concurrent * dates * gamma


def tail_timing_witness(
    *, reserve: Fraction, concurrent: int, dates: int, gamma: Fraction,
    stake: Fraction,
) -> RunResult:
    """Honest income arrives one date too late: the date-by-date refutation."""
    schedule: List[Event] = []
    for step_date in range(1, dates + 1):
        for j in range(concurrent):
            schedule.append(
                Event(step_date, 3, PROCEDURE, gamma, "charge", f"tail{j}")
            )
    for j in range(concurrent):
        schedule.append(
            Event(dates, 5, PROCEDURE, -stake, "forfeit", f"tail{j}")
        )
    return run_ledger(schedule, {PROCEDURE: reserve})


# ------------------------------------------------------- B-X.2 / B-X.3


def no_bootstrap_from_zero(gamma: Fraction) -> Fraction:
    """F_min >= r(1) > 0: no charge obligation can be met from an empty account."""
    if gamma <= 0:
        raise ValueError("positive charge required")
    return gamma


def patronage_monotonicity(
    schedule: Sequence[Event], reserves: Mapping[str, Fraction],
    inflow: Mapping[str, Fraction],
) -> Dict[str, bool]:
    """Adding recorded inflow never converts a paid obligation into a trigger."""
    bare = run_ledger(schedule, reserves)
    richer = run_ledger(
        schedule,
        {a: reserves[a] + inflow.get(a, Q(0)) for a in reserves},
    )
    bare_ids = {(d, a, k, amt) for d, a, k, amt in bare.triggered}
    rich_ids = {(d, a, k, amt) for d, a, k, amt in richer.triggered}
    return {
        "pure_run_solvent": not bare.any_trigger,
        "inflow_adds_no_trigger": rich_ids <= bare_ids,
    }


# ------------------------------------------------- C-X.1/C-X.4 dovetail door


def dovetail_admissions(
    filings: Sequence[Tuple[int, int]],
    *,
    per_date: int,
    horizon: int,
    index_major: bool,
) -> Dict[Tuple[int, int, int], Optional[int]]:
    """Admit filings under the dovetailed door.

    `filings` are (index, filing_date) pairs; a filing is eligible at date t
    when index <= t and filing_date <= t.  At most `per_date` are admitted per
    date.  `index_major` orders the queue by (index, filing_date); otherwise by
    (filing_date, index) -- the repaired, starvation-free order.
    """
    pending: List[Tuple[int, int, int]] = [
        (index, date, seq) for seq, (index, date) in enumerate(filings)
    ]
    admitted: Dict[Tuple[int, int, int], Optional[int]] = {
        key: None for key in pending
    }
    for date in range(horizon + 1):
        eligible = [
            k for k in pending
            if admitted[k] is None and k[0] <= date and k[1] <= date
        ]
        if index_major:
            eligible.sort(key=lambda k: (k[0], k[1], k[2]))
        else:
            eligible.sort(key=lambda k: (k[1], k[0], k[2]))
        for key in eligible[:per_date]:
            admitted[key] = date
    return admitted


def starvation_witness(horizon: int = 60) -> Dict[str, object]:
    """Index-major lexicographic admission starves every index above one."""
    filings = [(1, t) for t in range(horizon + 1)] + [(2, 1)]
    index_major = dovetail_admissions(
        filings, per_date=1, horizon=horizon, index_major=True
    )
    date_major = dovetail_admissions(
        filings, per_date=1, horizon=horizon, index_major=False
    )
    target = (2, 1, len(filings) - 1)
    return {
        "index_major_admission_date": index_major[target],
        "date_major_admission_date": date_major[target],
        "index_major_starves": index_major[target] is None,
    }


def eligible_filers_per_date(date: int) -> int:
    """Dovetail eligibility index <= t makes each date's attempt set finite."""
    return max(0, date)


# --------------------------------------------------------- C-X.3 sybil check


def per_index_subsidy(index: int, budget: Fraction) -> Fraction:
    return budget * Fraction(1, 2 ** index)


def per_index_subsidy_split_witness(
    *, original_index: int, split_indices: Sequence[int], budget: Fraction
) -> Dict[str, object]:
    """Rejected per-index schedule: splitting leaves each copy its own weight."""
    single = per_index_subsidy(original_index, budget)
    split = sum((per_index_subsidy(i, budget) for i in split_indices), Q(0))
    total = budget  # sum_{i>=1} 2^-i * budget
    return {
        "single": single,
        "split_total": split,
        "self_dilutes": split <= single,
        "ecology_total": total,
        "split_within_ecology_total": split <= total,
    }


def sybil_throughput(
    *, per_date: int, split_count: int, horizon: int
) -> Dict[str, int]:
    """Splitting cannot raise total admitted throughput past the dovetail."""
    filings = [
        (i + 1, t) for i in range(split_count) for t in range(horizon + 1)
    ]
    admitted = dovetail_admissions(
        filings, per_date=per_date, horizon=horizon, index_major=False
    )
    count = sum(1 for value in admitted.values() if value is not None)
    return {"admitted": count, "dovetail_cap": per_date * (horizon + 1)}


# --------------------------------------------------- D-X.1 recurrent_complaint_sequence boundary


def recurrent_complaint_sequence_payoff(
    *, stake: Fraction, dates: int, gamma: Fraction, disposition: str
) -> Fraction:
    """Challenger net payoff by typed disposition of a substantive complaint."""
    drip = dates * gamma
    if disposition == "checked-response":
        return drip - stake            # (AN) makes this strictly negative
    if disposition == "authorized-revision":
        return drip                    # stake returned: strictly positive
    if disposition == "insolvency-suspension":
        return drip                    # stake returned, target killed
    raise ValueError(f"unknown disposition {disposition!r}")


def total_recurrent_complaint_sequence_revenue_cap(
    *, keys: int, concurrent: int, dates: int, gamma: Fraction
) -> Fraction:
    """Bounded enforcement charge: once per canonical key, n_P filers per key."""
    return keys * concurrent * dates * gamma


def dk_recurrent_complaint_sequence_revenue() -> Dict[str, Fraction]:
    revenue = total_recurrent_complaint_sequence_revenue_cap(
        keys=1, concurrent=DK["n_P"], dates=DK["D_P"], gamma=DK["gamma"]
    )
    return {
        "per_filer": recurrent_complaint_sequence_payoff(
            stake=DK["stake"], dates=DK["D_P"], gamma=DK["gamma"],
            disposition="authorized-revision",
        ),
        "responded_filer": recurrent_complaint_sequence_payoff(
            stake=DK["stake"], dates=DK["D_P"], gamma=DK["gamma"],
            disposition="checked-response",
        ),
        "displayed_key_revenue": revenue,
        "loose_key_cap": total_recurrent_complaint_sequence_revenue_cap(
            keys=DK["b"] * (DK["Psi0"] + 1) * DK["d"],
            concurrent=DK["n_P"],
            dates=DK["D_P"],
            gamma=DK["gamma"],
        ),
    }


def ix_a4_unbounded_recurrent_complaint_sequence(reserve: Fraction, gamma: Fraction) -> Fraction:
    """IX-A4: with no repair and no response, recurrent_complaint_sequence revenue is the whole reserve."""
    return (reserve // gamma) * gamma
