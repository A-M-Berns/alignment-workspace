"""Finite exact-rational certificates; not a longitudinal simulation."""

from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable, Mapping, Optional, Sequence


Warrant = tuple[frozenset[str], str]


def warrant_closure(base: Iterable[str], warrants: Sequence[Warrant]) -> frozenset[str]:
    closure = set(base)
    changed = True
    while changed:
        changed = False
        for premises, conclusion in warrants:
            if premises <= closure and conclusion not in closure:
                closure.add(conclusion)
                changed = True
    return frozenset(closure)


def gdates_constructible(
    gdates: Iterable[str], base: Iterable[str], warrants: Sequence[Warrant]
) -> bool:
    return set(gdates) <= warrant_closure(base, warrants)


@dataclass(frozen=True)
class BridgeGapWitness:
    bound: Fraction = Fraction(1, 2)
    frequency: Fraction = Fraction(1)
    stake: Fraction = Fraction(1, 4)
    capacity: Fraction = Fraction(1)
    charge: Fraction = Fraction(1, 2)
    settlement_age: int = 5

    def lock(self, age: int) -> Fraction:
        return self.stake + age * self.charge

    def certifies_gap(self) -> bool:
        return (
            self.bound <= self.frequency
            and self.lock(1) <= self.capacity
            and self.lock(2) > self.capacity
            and 2 < self.settlement_age
        )


def bound_address_is_valid(successor: Fraction, threshold: Fraction) -> bool:
    return successor <= threshold


def first_cap_crossing(chain: Sequence[Fraction], cap: Fraction) -> Optional[int]:
    for index, bound in enumerate(chain):
        if bound > cap:
            return index
    return None


def pas_product(
    premise: Fraction, applicability: Fraction, support: Fraction
) -> Fraction:
    return premise * applicability * support


def service_delay(rate: Fraction, burst: Fraction, capacity: Fraction) -> int:
    value = (2 * burst + rate) / capacity
    return -((-value.numerator) // value.denominator)


def operational_lock_cap(
    rate: Fraction,
    burst: Fraction,
    minimum_work: Fraction,
    delay: int,
    maximum_stake: Fraction,
    charge: Fraction,
) -> Fraction:
    admitted = rate * (delay + 1) + burst
    open_count = admitted // minimum_work
    return open_count * (maximum_stake + delay * charge)


def maximum_false_losses(outflow_budget: Fraction, extraction: Fraction) -> int:
    if outflow_budget < 0 or extraction <= 0:
        raise ValueError("budget must be nonnegative and extraction positive")
    return outflow_budget // extraction


def cycle_prefix(length: int) -> tuple[Fraction, ...]:
    if length < 0:
        raise ValueError("length must be nonnegative")
    return tuple(Fraction(1, 3) if i % 2 == 0 else Fraction(2, 3) for i in range(length))


def consumption_status_change_cap(route_budgets: Mapping[str, int], targets: int) -> int:
    if targets < 0 or any(value < 0 for value in route_budgets.values()):
        raise ValueError("budgets and target count must be nonnegative")
    total = sum(route_budgets.values())
    return total + (total + 1) * targets


@dataclass(frozen=True)
class OccupationEndpoint:
    block: int
    a_fraction: Fraction


def cesaro_endpoints(blocks: int) -> tuple[OccupationEndpoint, ...]:
    if blocks < 1:
        return ()
    total = 0
    a_time = 0
    length = 1
    endpoints: list[OccupationEndpoint] = []
    for block in range(1, blocks + 1):
        if block > 1:
            length = block * total
        if block % 2 == 1:
            a_time += length
        total += length
        endpoints.append(OccupationEndpoint(block, Fraction(a_time, total)))
    return tuple(endpoints)


def universal_policy_obstruction(
    bound: Fraction,
    frequency: Fraction,
    settlement_lock: Fraction,
    capacity: Fraction,
    authorized_routes: int,
) -> bool:
    """True exactly for the minimal B5 exposed no-route witness."""
    return (
        bound > frequency
        and settlement_lock <= capacity
        and authorized_routes == 0
    )
