"""Exact-rational witnesses for the Phase XI maximal-generality audit.

The functions here check finite instances and sharpness boundaries.  The
general results in ``PROOFS.md`` are hand proofs; this module never upgrades
their evidence status.  No Phase VI--X source is modified or imported as
theorem authority.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from itertools import permutations
from typing import Callable, Dict, Iterable, List, Mapping, Sequence, Tuple


Q = Fraction


def cumulative_charge(schedule: Sequence[Fraction], dates: int) -> Fraction:
    """C(dates) for a displayed finite prefix of a positive charge schedule."""
    if dates < 0 or dates > len(schedule):
        raise ValueError("dates must lie in the displayed schedule")
    return sum((Q(x) for x in schedule[:dates]), Q(0))


def foa_x(
    *,
    n_p: int,
    d_p: int,
    j_w: int,
    d_w: int,
    k_star: Fraction,
    b: int,
    psi0: int,
    d: int,
    n_match: int,
    charge: Sequence[Fraction],
    stake_cap: Fraction,
) -> Dict[str, Fraction]:
    """The uniform FOA-X function.

    ``b``, ``psi0``, and ``d`` are explicit inputs because the construction
    and its specialization checker record them.  Their contribution has
    already been tightened into the path-sensitive once-only cost ``k_star``
    and the realized false-match count ``n_match``.
    """
    if min(n_p, d_p, j_w, d_w, b, psi0, d, n_match) < 0:
        raise ValueError("mechanism counts are nonnegative")
    return {
        "P": Q(k_star) + n_p * cumulative_charge(charge, d_p),
        "W": n_match * (Q(stake_cap) + cumulative_charge(charge, d_w))
        + j_w * cumulative_charge(charge, d_w),
    }


def exact_minimum(amounts: Sequence[Fraction]) -> Fraction:
    """Peak cumulative net outflow, hence the exact reserve for one trace."""
    running = peak = Q(0)
    for amount in amounts:
        running += Q(amount)
        peak = max(peak, running)
    return peak


def coarse_gap_family(key_cap: int) -> Tuple[Fraction, Fraction]:
    """A family refuting a parameter-independent coarse FOA/minimum ratio.

    Only one key is reachable and costs 1, while the coarse product ``b(B+1)d``
    is declared as ``key_cap``.  One first charge unit is also required.
    """
    if key_cap < 1:
        raise ValueError("key_cap must be positive")
    return Q(key_cap + 1), Q(2)


def saturated_procedure_liquidity(
    d_p: int, *, rho: int = 1, beta: int = 1, w_min: int = 1, gamma: Fraction = Q(1)
) -> Fraction:
    """The realized constant-charge burst giving the conditional quadratic law."""
    n_p = (rho * (d_p + 1) + beta) // w_min
    return n_p * d_p * Q(gamma)


def unsaturated_procedure_liquidity(d_p: int, gamma: Fraction = Q(1)) -> Fraction:
    """Sharpness family with one open complaint: linear, not quadratic."""
    return d_p * Q(gamma)


@dataclass(frozen=True)
class Filing:
    name: str
    eligible: int
    priority: int


def priority_admissions(
    filings: Sequence[Filing], *, capacity: int, horizon: int
) -> Dict[str, int | None]:
    """Work-conserving fixed-priority admission of a locally finite trace."""
    if capacity < 1:
        raise ValueError("capacity must be positive")
    pending: List[Filing] = []
    admitted: Dict[str, int | None] = {f.name: None for f in filings}
    for date in range(horizon + 1):
        pending.extend(f for f in filings if f.eligible == date)
        pending.sort(key=lambda f: (f.priority, f.eligible, f.name))
        for _ in range(min(capacity, len(pending))):
            admitted[pending.pop(0).name] = date
    return admitted


def finite_overtaking(
    target: Filing, admitted_order: Sequence[Filing]
) -> int:
    """Number of later-eligible filings admitted before ``target``."""
    target_position = next(i for i, filing in enumerate(admitted_order) if filing == target)
    return sum(
        filing.eligible > target.eligible for filing in admitted_order[:target_position]
    )


def fencing_bypass_interval(world_due: Fraction, procedure_due: Fraction) -> Tuple[Fraction, Fraction]:
    """Exact pooled balance interval for the B-IX.1 ordered bypass.

    The world obligation must itself be paid and must leave too little for the
    later procedure obligation: ``world_due <= F < world_due + procedure_due``.
    """
    return Q(world_due), Q(world_due) + Q(procedure_due)


def certified_withdrawal_safe(required: Fraction, surplus: Fraction, withdrawal: Fraction) -> bool:
    return Q(required) + Q(surplus) - Q(withdrawal) >= Q(required)


def coarsened_minimum(account_traces: Mapping[str, Sequence[Fraction]]) -> Tuple[Fraction, Fraction]:
    """Return fenced sum and pooled minimum for aligned account traces."""
    lengths = {len(trace) for trace in account_traces.values()}
    if len(lengths) != 1:
        raise ValueError("traces must be aligned")
    fenced = sum((exact_minimum(trace) for trace in account_traces.values()), Q(0))
    pooled = exact_minimum(
        [sum((Q(trace[i]) for trace in account_traces.values()), Q(0)) for i in range(lengths.pop())]
    )
    return fenced, pooled


def non_delay_closed_aligned_class() -> Tuple[Fraction, Fraction]:
    """Peak equality in a singleton class that is not uniform-delay closed."""
    return coarsened_minimum({"W": [Q(1), Q(-1)], "P": [Q(2), Q(-2)]})


def recurrent_complaint_sequence_cap(keys: int, concurrent: int, charge: Sequence[Fraction], latency: int) -> Fraction:
    return keys * concurrent * cumulative_charge(charge, latency)


def enforcement_family_revenue(keys: int, first_charge: Fraction) -> Fraction:
    """One correct repair-only filing per distinct key."""
    return keys * Q(first_charge)


def funding_defeating_inflow(charge: Sequence[Fraction]) -> List[Fraction]:
    """Credits each charge just before it is due, defeating any prefix deadline."""
    return [Q(x) for x in charge]


def no_bootstrap(first_charge: Fraction, initial: Fraction) -> bool:
    return Q(initial) < Q(first_charge)


def transient_uncovered_cost(concurrency: int, charge: Sequence[Fraction], latency: int, eras: int) -> Fraction:
    return eras * concurrency * cumulative_charge(charge, latency)


def max_compiler(levels: Iterable[Fraction]) -> Fraction:
    values = [Q(x) for x in levels]
    return max(values, default=Q(0))


def accrual_compiler(levels: Sequence[Fraction], bridge: Fraction) -> Fraction:
    if len(levels) != 2:
        raise ValueError("the frozen accrual compiler has two inputs")
    high, low = max_compiler(levels), min(Q(x) for x in levels)
    return high + Q(bridge) * low * (1 - high)


def constant_one_compiler(levels: Sequence[Fraction]) -> Fraction:
    return Q(1) if levels else Q(0)


def reference_jump(
    compiler: Callable[[Sequence[Fraction]], Fraction], levels: Sequence[Fraction], killed: int
) -> Fraction:
    before = compiler(levels)
    after = compiler([level for i, level in enumerate(levels) if i != killed])
    return before - after


Record = Tuple[Tuple[str, Fraction], ...]


def rename_record(record: Record, permutation: Mapping[str, str]) -> Record:
    return tuple(sorted((permutation.get(name, name), Q(value)) for name, value in record))


def orbit(record: Record) -> Tuple[Record, ...]:
    names = [name for name, _ in record]
    members = []
    for permuted in permutations(names):
        members.append(rename_record(record, dict(zip(names, permuted))))
    return tuple(sorted(set(members)))


def quotient_functional(record: Record) -> Fraction:
    """An isomorphism-invariant record functional."""
    return sum((value for _, value in record), Q(0))


def lexical_functional(record: Record) -> Fraction:
    """Sharpness: record-computable but not equivariant under renaming."""
    return next(value for name, value in record if name == min(name for name, _ in record))


def terminal_route_coverage_biconditional(terminal_covered: bool, transient_cost_funded: bool) -> bool:
    """Finite truth-table instance of the repaired C.X.2 hypotheses."""
    return terminal_covered and transient_cost_funded


def boundedness_diagnostic(
    *, covered: bool, adequate: bool, keys: int, concurrent: int, charge_total: Fraction
) -> Dict[str, object]:
    if covered and adequate:
        return {"regime": "enforcement", "uniform_cap": keys * concurrent * Q(charge_total), "typed": True}
    if covered:
        return {"regime": "starvation", "uniform_cap": None, "typed": False}
    return {"regime": "extraction", "uniform_cap": None, "typed": False}
