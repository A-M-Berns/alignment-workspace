"""Small exact-rational witnesses; this is not a simulation mechanism."""

from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable, Sequence


def ceiling_fraction(value: Fraction) -> int:
    """Return the mathematical ceiling without converting to float."""
    return -((-value.numerator) // value.denominator)


def constant_charge_timeout(capacity: Fraction, charge: Fraction) -> int:
    """D1's T(C, gamma) for strictly positive rational parameters."""
    if capacity <= 0 or charge <= 0:
        raise ValueError("capacity and charge must be strictly positive")
    return ceiling_fraction(capacity / charge)


def token_envelope_holds(
    arrivals: Sequence[Fraction], rate: Fraction, burst: Fraction
) -> bool:
    """Check every finite interval of the Stage III-B arrival envelope."""
    for start in range(len(arrivals)):
        total = Fraction(0)
        for end in range(start, len(arrivals)):
            total += arrivals[end]
            length = end - start + 1
            if total > rate * length + burst:
                return False
    return True


def overload_backlog(
    dates: int, arrival_work: Fraction, service_capacity: Fraction
) -> Fraction:
    """Finite shadow of Stage III-B B9 under persistent overload."""
    if dates < 0:
        raise ValueError("dates must be nonnegative")
    if arrival_work < 0 or service_capacity < 0:
        raise ValueError("work and capacity must be nonnegative")
    return dates * max(Fraction(0), arrival_work - service_capacity)


@dataclass(frozen=True)
class ContentfulWitness:
    bound: Fraction
    service_capacity: Fraction
    arrival_rate: Fraction
    arrival_burst: Fraction
    maximum_stake: Fraction
    lock_capacity: Fraction
    charge: Fraction

    def maximum_same_date_lock(self) -> Fraction:
        admitted_work = self.arrival_rate + self.arrival_burst
        return admitted_work * self.maximum_stake

    def certifies(self) -> bool:
        return (
            Fraction(0) < self.bound < Fraction(1)
            and self.arrival_rate < self.service_capacity
            and self.arrival_rate + self.arrival_burst <= self.service_capacity
            and self.maximum_same_date_lock() < self.lock_capacity
        )


def d2_witness() -> ContentfulWitness:
    return ContentfulWitness(
        bound=Fraction(1, 2),
        service_capacity=Fraction(2),
        arrival_rate=Fraction(1),
        arrival_burst=Fraction(1),
        maximum_stake=Fraction(1, 4),
        lock_capacity=Fraction(1),
        charge=Fraction(1, 4),
    )


@dataclass(frozen=True)
class FalseBoundTrace:
    dates: int
    outcome: Fraction
    frequency: Fraction
    bound: Fraction
    stake: Fraction
    charge: Fraction
    capacity: Fraction
    challenger_gain: Fraction
    maximum_lock: Fraction

    @property
    def bound_is_false(self) -> bool:
        return self.bound > self.frequency

    @property
    def as_solvent(self) -> bool:
        return self.maximum_lock < self.capacity


def d3_false_bound_trace(dates: int) -> FalseBoundTrace:
    """D3's serial one-case world challenges against y_n = 0."""
    if dates < 0:
        raise ValueError("dates must be nonnegative")
    stake = Fraction(1, 4)
    charge = Fraction(1, 4)
    return FalseBoundTrace(
        dates=dates,
        outcome=Fraction(0),
        frequency=Fraction(0),
        bound=Fraction(1, 2),
        stake=stake,
        charge=charge,
        capacity=Fraction(1),
        challenger_gain=dates * stake,
        maximum_lock=stake + charge,
    )


def relabel_lock_trace(trace: Iterable[Fraction], _external_label: str) -> tuple[Fraction, ...]:
    """D4 certificate: external labels are deliberately not transition inputs."""
    return tuple(trace)


def nc_primitive_response_exists(
    available_premises: frozenset[str], forbidden_lineage: frozenset[str]
) -> bool:
    """Finite certificate for the primitive NC Dismissal witness."""
    return bool(available_premises - forbidden_lineage)
