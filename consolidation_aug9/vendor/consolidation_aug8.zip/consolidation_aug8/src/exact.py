"""Fresh exact-rational evaluators for the retained mathematical claims.

This module has no dependency on the source repository.  It intentionally uses
only fractions and finite enumeration; it is an executable certificate layer,
not a floating-point simulation.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as Q
from itertools import combinations
from math import ceil, floor
from typing import Callable, Iterable, Mapping, Sequence


def dot(x: Sequence[Q], y: Sequence[Q]) -> Q:
    return sum((a * b for a, b in zip(x, y)), Q(0))


def leverage_slack(p_a: Q, p_ar: Q, p_arb: Q, p_b: Q,
                   c_p: Q, c_a: Q, c_s: Q) -> tuple[Q, tuple[Q, Q, Q, Q]]:
    ds = (p_a-c_p, p_ar-c_a*p_a, p_arb-c_s*p_ar, p_b-p_arb)
    rhs = ds[3] + ds[2] + c_s*ds[1] + c_s*c_a*ds[0]
    return p_b-c_p*c_a*c_s, ds


def leverage_atoms(c_p: Q, c_a: Q, c_s: Q) -> tuple[Q, Q, Q, Q]:
    return (c_p*c_a*c_s, c_p*c_a*(1-c_s), c_p*(1-c_a), 1-c_p)


def solve_linear(a: list[list[Q]], b: list[Q]) -> list[Q] | None:
    """Gauss-Jordan solve of a square rational system."""
    n = len(a)
    m = [row[:] + [rhs] for row, rhs in zip(a, b)]
    for c in range(n):
        pivot = next((r for r in range(c, n) if m[r][c]), None)
        if pivot is None:
            return None
        m[c], m[pivot] = m[pivot], m[c]
        q = m[c][c]
        m[c] = [x/q for x in m[c]]
        for r in range(n):
            if r != c and m[r][c]:
                q = m[r][c]
                m[r] = [x-q*y for x, y in zip(m[r], m[c])]
    return [m[i][-1] for i in range(n)]


def lp_vertices(n: int, inequalities: Sequence[tuple[Sequence[Q], Q]]) -> list[tuple[Q, ...]]:
    """Vertices of {x: sum x=1, A x >= b}; sufficient for small witnesses."""
    vertices: set[tuple[Q, ...]] = set()
    for active in combinations(range(len(inequalities)), n-1):
        a = [[Q(1)]*n]
        b = [Q(1)]
        for i in active:
            row, rhs = inequalities[i]
            a.append(list(row)); b.append(rhs)
        x = solve_linear(a, b)
        if x is None:
            continue
        if all(dot(row, x) >= rhs for row, rhs in inequalities):
            vertices.add(tuple(x))
    return sorted(vertices)


def serviceability_lp_instance() -> Mapping[str, object]:
    """Four-atom leverage LP and a dual certificate for min P(B)."""
    cp, ca, cs = Q(3,4), Q(2,3), Q(4,5)
    # atoms: ARB, AR~B, A~R, ~A; nonnegativity plus the three certificate rows
    z = Q(0)
    unit = [tuple(Q(int(i == j)) for i in range(4)) for j in range(4)]
    rows: list[tuple[Sequence[Q], Q]] = [(u, z) for u in unit]
    rows += [
        ((1,1,1,0), cp),
        ((1-ca,1-ca,-ca,0), z),
        ((1-cs,-cs,0,0), z),
    ]
    vs = lp_vertices(4, rows)
    optimum = min(v[0] for v in vs)
    # LL is the dual certificate: target endorsement - product*simplex row is a
    # nonnegative combination of the four slack rows.
    return {"vertices": vs, "optimum": optimum,
            "dual_value": cp*ca*cs, "sharp_atoms": leverage_atoms(cp,ca,cs)}


def operative_force(prefix_x: Sequence[Sequence[Q]], prices: Sequence[Sequence[Q]],
                    refs: Sequence[Sequence[Q]], world: Sequence[Q]) -> Mapping[str, Q]:
    n = len(prefix_x)
    gains = [dot(x, tuple(w-p for w,p in zip(world, price)))
             for x, price in zip(prefix_x, prices)]
    e = [dot(x, tuple(q-p for q,p in zip(ref, price)))
         for x, ref, price in zip(prefix_x, refs, prices)]
    holdings: list[tuple[Q,...]] = []
    h = [Q(0)]*len(world)
    for x in prefix_x:
        h = [a+b for a,b in zip(h,x)]; holdings.append(tuple(h))
    movement = sum((dot(holdings[t], tuple(refs[t][j]-refs[t+1][j]
                    for j in range(len(world)))) for t in range(n-1)), Q(0))
    anchor_gain = sum((dot(x, tuple(refs[-1][j]-prices[t][j]
                         for j in range(len(world)))) for t,x in enumerate(prefix_x)), Q(0))
    return {"gain": sum(gains,Q(0)), "reference_gain": sum(e,Q(0)),
            "anchor_plus_movement": anchor_gain+movement, "movement": movement}


def exhaustion_time(f0: Q, charge: Callable[[int], Q], inflow: Callable[[int], Q],
                    limit: int = 10000) -> int | None:
    r = Q(0); i = Q(0)
    for k in range(1, limit+1):
        r += charge(k); i += inflow(k)
        if r > f0+i:
            return k
    return None


def pure_constant_exhaustion(f0: Q, gamma: Q) -> int:
    return floor(f0/gamma)+1


def stock_deadline(capacity: Q, gamma: Q) -> int:
    return ceil(capacity/gamma)


def peak_endowment(outflows: Sequence[Q], inflows: Sequence[Q]) -> Q:
    balance = Q(0); peak = Q(0)
    for o,i in zip(outflows,inflows):
        balance += o-i; peak=max(peak,balance)
    return peak


def dk_numbers() -> Mapping[str,Q]:
    # Phase-X displayed mechanism, with exact certified path and match counts.
    gamma=Q(1,64); stake=Q(1,8); dp=1; dw=4
    np=6; jw=2; psi0=3; b=4; d=2; reply_cost=Q(1,16); cr=Q(1,8)
    coarse_k=psi0*cr+b*(psi0+1)*d*reply_cost
    p_suf=coarse_k+np*gamma*dp
    w_suf=20*(stake+gamma*dw)+jw*gamma*dw
    p_min=Q(17,32); w_min=Q(1,2)
    return {"coarse_k":coarse_k,"p_suf":p_suf,"w_suf":w_suf,
            "p_min":p_min,"w_min":w_min,"total_min":p_min+w_min,
            "charge_unit":gamma,"revenue":Q(3,32),"loose_revenue":Q(3)}


def pooled_bypass(a_w: Q, a_p: Q, f: Q) -> bool:
    return a_w <= f < a_w+a_p


def account_minima(traces: Iterable[Sequence[Sequence[Q]]]) -> tuple[Q,Q]:
    traces=list(traces)
    local=sum((max((max(row[a] for row in traces)),Q(0)) for a in range(len(traces[0]))),Q(0))
    pooled=max((sum(row,Q(0)) for row in traces),default=Q(0))
    return local,pooled


def finite_overtaking(order: Sequence[str], eligibility: Mapping[str,int]) -> bool:
    pos={x:i for i,x in enumerate(order)}
    return all(sum(1 for y in order[:pos[x]] if eligibility[y]>eligibility[x]) < len(order)
               for x in order)


def reference_jump(compiler: Callable[[tuple[Q,...]],Q], active: Sequence[Q], j:int) -> Q:
    a=tuple(active); return compiler(a)-compiler(a[:j]+a[j+1:])


def cmax(a: tuple[Q,...]) -> Q:
    return max(a,default=Q(0))


def caccrual(a: tuple[Q,...]) -> Q:
    p=Q(1)
    for x in a: p*=1-x
    return 1-p


def conjugate_record(record: Mapping[str,Q], permutation: Mapping[str,str]) -> dict[str,Q]:
    return {permutation.get(k,k):v for k,v in record.items()}


def invariant_total(record: Mapping[str,Q]) -> Q:
    return sum(record.values(),Q(0))


def epoch_financing(np:int, dp:int, jw:int, dw:int, gamma:Q,
                    stake:Q) -> Mapping[str,Q]:
    deficit=(np*dp+jw*dw)*gamma
    closure_income=np*(stake-dp*gamma)+jw*(stake-dw*gamma)
    return {"intra_cycle_deficit":deficit,"closure_income":closure_income}


def six_case_selection() -> tuple[tuple[str,...], str | None, bool | None, bool | None]:
    cases={
        "c0":("manufacturing","high"), "c1":("manufacturing","low"),
        "c2":("healthcare","high"), "c3":("healthcare","low"),
        "c4":("transport","high"), "c5":("transport","low")}
    successes={"c0","c2"}; burdens={"c1","c3"}
    pred={"all":lambda i:True,
          "manufacturing":lambda i:cases[i][0]=="manufacturing",
          "local-c0":lambda i:i=="c0",
          "high-dependency":lambda i:cases[i][1]=="high"}
    eligible=tuple(n for n,f in pred.items()
                   if len({i for i in successes if f(i)})>=2
                   and not {i for i in burdens if f(i)})
    selected=eligible[0] if len(eligible)==1 else None
    return eligible,selected,(pred[selected]("c4") if selected else None),(pred[selected]("c5") if selected else None)
