# Canonical vocabulary and notation

This file is the sole canonical naming authority for the consolidation and its
downstream `normative-learner` project.  Canonical prose and mathematics use the
right-hand entries below.  Legacy spellings survive only in this rename table,
`ID_EXPANSIONS.md`, `AMBIGUITIES.md`, the pre-standardization archives, and
historical interpretation where explicitly labelled.

## Fixed vocabulary

**Leverage** is the multiplicative or network-amplified consequence of nested
warranted bounds. A **warrant** is a sourced defeasible transmission schema. An
**endorsement** is an occurrence-level public commitment to a warrant or claim;
its content may assert a lower or upper **bound**. The active **book**
\(\mathcal E_t\) is the finite endorsement set plus provenance. Its compiled
**permitted region** is \(\mathcal C_t\).

**Answerability** is the challenge-relative property defined by the selected
stock or flow criterion. The umbrella event is **answering**. Its four typed
dispositions are **respond**, **repair**, **suspend**, and **trigger**; *respond*
is the no-active-endorsement-change reply. An objection's field \(A_d\) is its
**reply type**. A **challenge** is an admitted typed request with stake and
disposition rules. A **stake** is the challenger's escrowed amount.

A **charge** is a literal transfer from a book account while an objection stays
open. Singular *charge* denotes the per-date amount \(c_K(k)\); plural *charges*
denotes the cumulative amount \(C_K(k)\). Charges **run**; reason support may
accrue. **Funding** remains the vocabulary for endowment and liquidity.

**Route coverage** means that each covered unresolved key has an authorized
route to respond, repair, or suspend. **Eventual route coverage** is that
condition at the terminal era. Trigger is excluded: it records the consequence
of lacking such a route and cannot witness coverage.

The repeated-complaint formal object is a **recurrent complaint sequence**. Its
three regimes are **enforcement**, **extraction**, and **starvation**.

## Time vocabulary

| Canonical term | Meaning |
|---|---|
| **date** | one object-level transition step |
| **era** | interval between active-book changes |
| **horizon** \(N\) | finite prefix length |
| **phase** | project history only; never an object-level time unit |

## Mathematical objects

| Symbol | Meaning |
|---|---|
| \(\Omega_t\) | finite worlds represented at date \(t\) |
| \(\Delta(\Omega_t)\) | credal simplex; the local payoff carrier is stated separately when needed |
| \(\mu\) | credence state in \(\Delta(\Omega_t)\) |
| \(\mathcal E_t\) | active endorsement book |
| \(\mathcal C_t\) | permitted region compiled from \(\mathcal E_t\) |
| \(q_t\) | public reference |
| \(\theta\) | uniform core coefficient |
| \(\kappa=(1-\theta)/\theta\) | operative-force odds factor |
| \(p_t,x_t,H_t\) | quote, executed position, and post-trade holdings |
| \(g_t,G_N\) | one-date and prefix worldwise payoff |
| \(\varepsilon_t,\varepsilon_{1:N}\) | solver error and accumulated solver error |
| \(R\) | traders' worldwise risk (downside limit), so \(G_n(w)\ge -R\) |
| \(M_N\) | analytic holdings-weighted reference-movement liability; no account debit |
| \(K_t^{ans}\) | state of a finite answerability mechanism instance |
| \(s^{ch}\) | challenge stake |
| \(c_K(k),C_K(k)\) | date-\(k\) literal charge and cumulative literal charges |
| \(C^{ans}\) | stock lock capacity |
| \(F_a(t)\) | flow balance of literal account \(a\) |
| \(D_P,D_W\) | procedure and world service latencies |
| \(n_P,J_W\) | procedure and world concurrency caps |
| \(\Psi,\Psi_0\) | consuming revision potential and its initial value \(\Psi(K_0)\) |
| \(N_{match}\) | false-match cap before repair-pending status |
| \(h\) | LP dual-certificate slack |
| \(\zeta\) | per-reply service cost in the finite construction (formerly the unrelated \(\kappa\)) |

The operative-force gloss is: **winnings ≤ tolerance + rate × (risk +
movement)**, where tolerance is \(\varepsilon_{1:N}/\theta\) and rate is
\(\kappa\). The word *slack* remains reserved here for the LP dual quantity
\(h\), certified account slack, and ordinary algebraic slack.

Minimum required quantities such as \(F_{\min}\), \(P_{\min}\), and
\(W_{\min}\) remain **minima**. They are not caps: renaming them would reverse
their order-theoretic sense.

## Exhaustive rename table

| Legacy name or notation | Canonical name | Scope and exceptions |
|---|---|---|
| \(\Omega\); world-vector set \(W\) | \(\Omega_t\) | Worlds in the dated statics. A payoff-vector set local to a comparison arena is named \(W_\Gamma\). |
| \(P=\operatorname{conv}(W)\) | \(\Delta(\Omega_t)\) | Credal simplex only; procedure account \(P\) and local carrier \(P_\Gamma\) are distinct typed objects. |
| \(R,R_t\) (book) | \(\mathcal E_t\) | Frees \(R\) for risk. Unrelated relation and rate variables receive local names. |
| \(S,S(R),S_t\) | \(\mathcal C_t\) | Compiled permitted region. |
| \(a_t,\alpha,\texttt{alpha}\) (core) | \(\theta\) | Service-arrival \(a_t\) becomes \(u_t\); warrant metavariables use \(\varphi,\psi\); Lean type metavariables use \(\tau\). |
| — | \(\kappa=(1-\theta)/\theta\) | Reserved for the odds factor. The former construction reply-cost \(\kappa\) becomes \(\zeta\). |
| \(E_N,E_*\) | \(\varepsilon_{1:N}\), or the stated horizon cap on it | \(\varepsilon_t\) is unchanged. |
| \(B,-B\) (downside) | \(R,-R\) | Risk only; book notation has moved to \(\mathcal E_t\). |
| \(D_N\) | \(M_N\) | Analytic movement liability, never a literal charge. |
| \(B_R\) | \(\Psi_0\) | Initial revision potential. |
| post-trade cumulative exposure; market exposure | post-trade holdings; market holdings | Epistemic *exposed*, exposure boundary/fringe/deficit/map, and empirical exposure are unchanged. |
| floor (book content) | bound | Lower or upper numeric content asserted by an endorsement. Mathematical integer floor and external `Mathlib.Data.Rat.Floor` are unchanged. |
| row (book object) | endorsement | Matrix, table, and ledger rows are unchanged. |
| wealth/movement/coarse/uniform/upper bound | corresponding cap | A proved ceiling. Lower bounds and funding minima remain bounds/minima. |
| compiler shock; shock scalar; shock recursion | reference jump; jump scalar; jump recursion | No mathematical change. |
| movement charge | movement liability | Analytic proof accounting, not a literal account transfer. |
| kernel (formal object) | mechanism; mechanism instance | External phrases such as fault-proof protocol terminology and the Lean proof checker are not names of this object. |
| AnsLearn; terminally answerable-learning criterion (placeholder) | answerable learner | The class is *the answerable learners*. |
| Flow-AnsLearn | flow answerable learner | Flow semantics. |
| defect; defect grammar/family; typed defect | objection; objection grammar/family; typed objection | External citation phrase *fault proofs* is unchanged. |
| martyrdom; underfunding-triggered correct-target suspension | starvation | *Martyrdom-by-latency* becomes *starvation-by-latency*. |
| extortion; uncovered recurrent rent extraction | extraction | Regime name. |
| covered and adequately funded repeated-complaint regime | enforcement | Regime name. |
| firewall; account separation | fencing; fenced | Pooling remains the absence of fencing. |
| Strong Firewall Theorem | Strong Fencing Theorem | Theorem expansion only; stable IDs do not change. |
| rent; rent stream; rent recipient | charge; charge stream; charge recipient | Literal flow transfer. |
| rent-gradient learner; rent-min optimum | charge-gradient learner; charge-minimising optimum | No change to optimization content. |
| accrue (of charges) | run | *Accrual* remains available for reasons. |
| \(r_K(k),R_K(k)\) | \(c_K(k),C_K(k)\) | Per-date and cumulative charges. |
| round; period (object time) | date | Mathematical periodicity and historical publication periods, if any, are not object-time units. |
| answer (narrow no-change disposition) | respond | Umbrella *answering/answerability* remains. |
| response type \(A_d\) | reply type \(A_d\) | Avoids collision with the respond disposition. |
| ARC; flow-ARC; authorized repair coverage | route coverage | Authorized route to respond, repair, or suspend. |
| syntactic ARC; semantic ARC | syntactic route coverage; semantic route coverage | `miscoverage` is the conformal-prediction objection type and is unchanged. |
| ARC-Reach; reachable-book repair coverage | reachable-book route coverage | — |
| ARC-Era; every-era repair coverage | every-era route coverage | — |
| ARC-Term; Terminal ARC; TRC; terminal-book coverage condition (placeholder) | eventual route coverage | *Eventual coverage* is a prose short form after first definition. |
| terminal coverage; terminal-book coverage | eventual route coverage | Informal remnants of the same terminal-era condition; trigger remains excluded. |
| ARC-iff conjecture | route-coverage biconditional | Stable claim IDs remain frozen. |
| siege | recurrent complaint sequence | Formal object, not a regime name. |
| Hume-bypass | reason-to-settlement bypass | — |
| No-Trader Principle | self-financing separation theorem | — |
| Moving-Book Obstruction | moving-region gain obstruction | — |
| Public-Twin Extensionality | record extensionality | — |
| Authorized Surprise; Earlier-Authorized Correction Lemma | prior-authorized correction theorem | — |
| No Transfer Without Structure | local-change nonpropagation | — |
| No Ontology-Free Unique Transfer | extensional transfer underdetermination | — |
| Target--Remainder Theorem | target persistence and exact completion | — |
| No Neutral Staging | allocation nonuniqueness | — |
| No Universal Progress Scalar | no target-independent fraction order | — |
| No Realization from Recognition | recognition-without-service counterexample | — |
| No-Bypass | ontology noninterference and activation separation | — |
| Bounded Dogmatism | procedure stock deadline | Historical expansion only. |
| haunting | persistence of an unaddressed objection | — |
| whitewashing | cumulative revision hidden by local comparisons | — |
| anti-Sybil / coalition firewall | coalition aggregation and index-splitting robustness | — |
| Sybil splitting; Sybil resistance | index splitting; robustness to index splitting | — |
| seam twins; world/procedure twins | record-seam-equivalent traces | — |
| record twins; flow twins | record-equivalent states; record-automorphism orbits | — |
| twin group | record automorphism group | — |
| certified-surplus cap | certified slack transfer bound | Core policy is zero; nonzero \(\sigma\) is a declared, challengeable leak permission. |
| dynamic seam conservativity | protected dynamic-trace conservativity | — |
| MAX compiler | maximum compiler | — |
| accrual compiler | independent-union/accrual compiler | Reason accrual is the retained sense. |
| PCMC | positive moving-correspondence interface | — |
| JCC | joint collateral compactness condition | — |
| LIC | logical induction criterion | — |
| E1 | fixed-world exploitation criterion | — |
| E2 | moving-plausible-world exploitation criterion | — |

## Semantic warnings

- Stock opportunity cost is not a flow charge.
- Stock capacity is not flow wealth.
- Literal charges are not analytic movement liabilities.
- Semantic loss is not suspension, legacy retention, or a literal liability.
- Service completion is not terminal disposition.
- Authorization, solvency, semantic correspondence, compiler success, and
  allocation priority are separate predicates.
- A proposal is not operative until activation.
- Record equivalence is always relative to a stated signature and equivariance
  condition.
