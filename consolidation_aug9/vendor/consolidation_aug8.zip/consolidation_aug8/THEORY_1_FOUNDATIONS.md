# Part I. Finite state, records, and service

This monograph presents one theory in a fixed order. First, **reasons constrain**:
sourced endorsements compile into permitted credences and constrained quote
selection gives them operative force subject to a wealth cap. Second, **reasons
are revised**: public challenges lead to responses, repairs, suspensions, or
triggers, with funding obligations and learning conditions made explicit. The
joint public-history process `NL-J3` exhibits both as projections of one process.
Leverage and operative force are the thesis; answerability supplies the dynamics.

All sets called finite below are literally finite. All numerical inputs are rational unless a theorem explicitly uses real vector spaces. Empty sums are zero.

## 1. Finite probability and constraint syntax

Let \(\Omega_t\) be a nonempty finite set and \(\Delta(\Omega_t)\) its probability simplex. A proposition is a subset of \(\Omega_t\). A **warrant** is a sourced, scoped, defeasible schema \(\rho:\varphi\rightsquigarrow\psi\) with an applicability condition. An active warrant instance supplies a rational affine endorsement \(\ell_j(\mu)\ge0\). The active **book** \(\mathcal E_t\) is a finite set of active endorsements together with provenance and status records. Its permitted region is
\[
\mathcal C_t=\{\mu\in\Delta(\Omega_t):\ell_j(\mu)\ge0\text{ for every active endorsement }j\}.
\]
An endorsement may assert a lower or upper **bound**. A rebuttal adds support for an opposed conclusion. An undercutter changes or removes a transmission premise. Suspension removes an active endorsement without deleting its occurrence. A repair is a declared map to weakened endorsements with nonempty permitted region.

## 2. Public histories

A public history is a finite append-only sequence of dated events. Required event fields are identifiers, provenance, scope, governing versions, dependency paths, statuses, and any numerical obligation. A deterministic transition is a function of the public prefix; a randomized transition is a probability mechanism on prefixes. An activation event is distinct from derivability: a proposal has no operative projection until an authorized activation record exists.

**Record extensionality.** {#C-REC-EXT} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Equal public histories yield equal deterministic outputs and equal randomized output distributions.

**Proof.** Equal inputs to a function have equal outputs. Applying the same fact to a probability-mechanism-valued function gives equality of distributions. \(\square\)

This does not identify unrecorded causes. Adding authenticated fields can refine the input equivalence relation.

**Append-only persistence.** {#C-APPEND} **Status: PROVED+MACHINE-CHECKED.** If an event occurs in prefix \(h\), it occurs in every extension \(h\mathbin{+\!+}h'\). Hence recorded authorization, objections, burdens, evidence, target data, and operative acts survive later status changes.

**Proof.** Induct on \(h'\), or use membership in list concatenation. No extension step deletes an element of the prefix. \(\square\)

The hypothesis is necessary: a mutable-history transition may erase an earlier event in one step.

## 3. Finite service queues

An obligation has an immutable identifier, positive rational required work, arrival date, FIFO position, and remaining work. At date \(t\), workload \(u_t\) arrives and a server supplies at most \(C>0\). Service completion is not terminal disposition; disposition needs a separate congruent certificate.

**Overload waiting impossibility.** {#C-QUEUE-OVERLOAD} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If independent work arrives at rate \(\lambda>C\) each date, no scheduling policy guarantees every obligation completion within a fixed \(L<\infty\). The least integer counting witness is
\[
T=\left\lfloor\frac{CL}{\lambda-C}\right\rfloor+1.
\]

**Proof.** The first \(T\) dates create \(\lambda T\) work. An \(L\)-date promise requires it served by \(T+L\), when capacity is at most \(C(T+L)\). The displayed choice makes \((\lambda-C)T>CL\), a contradiction. \(\square\)

Safety does not imply service: the transition that records every arrival and performs zero work preserves every identifier while starving all items.

**Token-envelope FIFO cap.** {#C-QUEUE-FIFO} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Suppose
\[
\sum_{k=s}^t u_k\le \rho(t-s+1)+\beta,\qquad 0\le\rho<C.
\]
A work-conserving FIFO server has post-service backlog at most \(\beta\), pre-service workload at most \(2\beta+\rho\), and completion delay at most
\[
D=\left\lceil\frac{2\beta+\rho}{C}\right\rceil.
\]

**Proof.** Unrolling \(Q_t=(Q_{t-1}+u_t-C)_+\) gives
\[
Q_t=\max\!\left(0,\max_{1\le s\le t}\left[\sum_{k=s}^t u_k-C(t-s+1)\right]\right).
\]
For an interval of length \(m\ge1\), the bracket is at most \(\beta-(C-\rho)m\le\beta\). Also \(u_t\le\rho+\beta\), giving pre-service work at most \(2\beta+\rho\). Later work joins behind a fixed item, so work conservation removes everything ahead of it in the displayed number of dates. \(\square\)

Dropping \(\rho<C\) admits persistent overload. Dropping work conservation admits an idle server.

**Identity conservation under aggregation.** {#C-QUEUE-ID} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Let \(\mathcal U\) be finite source/scope atoms and represent an obligation by a vector in the free commutative monoid \(\mathbb N^{(\mathcal U)}\). If every split, merge, migration, and disposition preserves
\[
L_t+T_t=L_{t+1}+T_{t+1},
\]
then every original atom occurs at exactly one live or terminal accounting position at every finite prefix.

**Proof.** The equality preserves each basis coefficient. Induction over transitions preserves every coefficient from its initial value one. A missing atom changes a coefficient to zero; a duplicate changes it above one. \(\square\)

A summary that omits the source map cannot certify this property on a class with two source sets having the same summary: the checker receives identical inputs for distinct omitted identities.

## 4. Shared challenge syntax and two pricing semantics

The common syntactic layer consists of a finite language \(\mathcal L\), finite schema set, finite five-field objection table, finite semantic-key set, finite route graph, finite meta-depth, books, bounds, challenges, routes, and public records. An objection type is a five-tuple of grounds, filing predicate, reply type, judge, and service work. A challenge has a key, mode, stake, admission date, latency, and disposition. Both semantics use token-gated admission and bounded service latency.

### Adopted objection catalogue extensions

| Family | Objection type | Grounds | Filing predicate | Reply type | Judge | Service work |
|---|---|---|---|---|---|---|
| conduct | cross-component transfer | a public fence declaration and a recorded transfer with typed source and destination components | the transfer crosses that declared fence; vacuous when the book contains no fencing claim | show the transfer stayed within the declaration, repair or suspend the affected endorsement, or acknowledge trigger | finite record checker comparing component labels and the active declaration | inspect the declaration and transfer record; emit a typed address or repair certificate |
| provenance | misdeclared provenance | the token-gate provenance class, source records, and the challenged subsidy event | two indices claim distinct subsidy classes but the public ancestry checker places them in one class, or a declared class lacks its cited ancestry | correct and merge the class, justify it from public ancestry, suspend the subsidy claim, or acknowledge trigger | finite provenance-graph reachability checker | reconstruct the cited ancestry and recompute the per-provenance subsidy key |

The subsidy key is the already represented provenance class, not an added
primitive. Semantic similarity does not establish either objection: each filing
predicate reads declared book content and public records.

In **stock semantics**, the procedure cost of age \(k\) is locked opportunity cost \(s^{ch}+C(k)\), where \(C(k)=\sum_{j=1}^k c(j)\). Capacity \(C^{ans}\) limits simultaneous locks. A procedure challenge forces respond, repair, or suspend when its required lock reaches capacity. World-mode suspension locks only base stake after the mode split.

In **flow semantics**, charge \(c(k)>0\) is a literal per-date transfer from the named book account while the challenge remains open. At each due atomic obligation, a balance below the amount triggers suspension before debit. Stake is held separately and is returned or forfeited by the disposition rule.

Translation preserves books, challenges, routes, records, stake, latency, and cumulative schedule \(C\); it replaces the stock predicate “required lock is within capacity” by the flow predicate “every due transfer is payable from initial balance plus prior inflow.” Thus stock capacity is not flow wealth.

| Retained result family | Stock | Flow | Exact modification |
|---|---:|---:|---|
| procedure persistence deadline | yes | refuted in universal form | flow uses run-relative exhaustion time |
| same-day concurrency cap | yes | yes | locks versus liquid obligations |
| persistent false exposed bound | counterexample | does not persist with finite unreplenished wealth | flow pays stake plus accumulated charges |
| public-record conjugacy | yes | yes | balances and charge flows are added to the conjugacy |
| bare terminal bridge | refuted | refuted | operational adequacy is required |
| repaired terminal bridge | yes | yes-modified | flow uses paid obligations and atomic triggers |
| stock construction | yes | not portable | flow construction uses account assignment and stronger reserve caps |
| finite repair-completeness calibration | yes | yes-modified | flow route edges name accounts and costs |
| fencing and propagation | not present in base stock model | yes | flow-only balance and compiler results |

This is the family-level translation table. `LEDGER.md` supplies the exhaustive claim-level table: every retained claim has a stock, flow, both, both-modified, or not-applicable tag.
