# Decision ledger

- Retained claims only when current in the theory index, claim map, Phase XI ledger, or their cited retained authorities; reason: prevent resurrection of superseded material.
- Ordered parts by dependency—finite records, leverage, operative force, learning, two semantics, parameterized flow—rather than phase; reason: discard-test readability.
- Presented one theory in the fixed order reasons constraining, revising reasons, and their joint process; reason: `NL-J3` now supplies the common public-history process and the author has fixed the hierarchy.
- Used one shared challenge syntax followed by side-by-side stock/flow semantics; reason: preserve real translation limits without privileging either.
- Treated the Phase XI general form as primary and displayed finite values as specializations; reason: strongest proved authority.
- Kept finite originals whenever Phase XI marked a wider frontier open or conditional; reason: no new research.
- Replaced colorful or mixed-metaphorical canonical names using the exhaustive glossary table; reason: user naming policy.
- Named the terminal learning class **the answerable learners** and the terminal-era condition **eventual route coverage**; reason: the reserved names are now fixed.
- Made every formal monograph result carry a stable `C-...` anchor; reason: machine-auditable ledger completeness.
- Merged definition-level corollaries into theorem families only when their hypotheses and witnesses remain explicit; reason: avoid inflating the claim hierarchy while preserving content.
- Assigned Tier A to headline computations from every dependency part; reason: independent trust rather than inherited regression success.
- Assigned Tier B to exact long-tail fixtures only; reason: preserve decisive evidence without importing out-of-closure implementation history.
- Selected repaired summation, pooling/peak alignment, flow exhaustion, and record symmetry as new Lean targets; reason: substantive proof risk with bounded formalization scope.
- Did not select full Farkas infrastructure or a complete transition evaluator for Lean; reason: they exceed the bounded target budget without compromising the hand proofs or exact instances.
- Counted machine checking only where the compiled Lean statement covers the relevant algebra and paired it with a complete system-level hand proof; reason: avoid status inflation.
- Kept Mathlib as the sole external build dependency; reason: explicitly permitted and necessary for the vendored formal mechanism.
- Excluded Phase V finite dynamics from theorem authority; reason: current maps classify them as restricted-adapter computational observations.
- Excluded archive and deck content; reason: superseded authority and reserved-item constraints.
- Recorded historical provenance only in the ledger, never as a proof dependency; reason: self-containment.

## Author decisions adopted — 2026-08-08

1. **Mechanically filed past-self charge recipient: BURN.** A past-self filing
   carries no challenger stake, so its delay charge is burned rather than paid to
   a treasury or returned. The charge prices delay rather than funding a person;
   a live challenger earns a bounty by risking stake, while the mechanical filer
   risks none. Past-self charges are therefore intentional deadweight to the
   book and supply curriculum pressure.
2. **Cross-component transfer is a conduct-family objection.** It alleges that a
   recorded transfer crossed a declared fence, where the declaration itself is
   book content. It is vacuous if no fencing was claimed and live for pooled or
   leaking implementations that did claim it. Its five-tuple appears in the
   objection catalogue in Part I.
3. **The core mechanism's certified slack transfer cap is zero.** The
   fixed-horizon nonzero-\(\sigma\) result remains a theorem about a permissible
   relaxation, not policy. An instance may declare leaks permissible; that
   declaration is endorsement content and may itself be challenged by the
   cross-component-transfer objection.
4. **The terminal-era condition is eventual route coverage.** Coverage requires
   an authorized route to respond, repair, or suspend. Trigger is excluded
   because it records the absence of such a route.
5. **The subsidy schedule is per provenance.** It reuses the provenance classes
   already carried by the token gate, preventing index splitting from multiplying
   subsidy. A misdeclared-provenance objection is added to the provenance family;
   its five-tuple appears in Part I.
6. **There is one theory in a fixed order.** Reasons constraining comes first:
   endorsements constrain quotes and `C-OF1` caps exploitation. Revising reasons
   comes second: endorsements are challenged, defended, and revised while charges
   run. The joint public-history process `NL-J3` comes third. Leverage and
   operative force are the thesis; answerability supplies its dynamics.

## Improvement pass — 2026-08-08

- Kept `summationByParts` and `summationByPartsWithPrices` unchanged; reason: the audit found this was the one original new target that met the substantiveness gate.
- Replaced the atomic pooling, single-date matched-inflow, integer-multiple charge, and finite-sum permutation shells with three substantive targets; reason: the deleted statements checked only immediate inequalities or library identities.
- Accepted general exhaustion time, finite-horizon peak synchronization, and orbit factorization with a literal-name counterexample; reason: each matches a canonical theorem boundary and contains a plausibly fallible leastness, equality, or quotient step.
- Rejected the overtaking target for this pass; reason: a faithful nondefinitional statement requires operational door, capacity-slot, and work-conservation infrastructure beyond the bounded target.
- Rejected compiler extremes as a Lean target; reason: their pointwise inequalities follow immediately from the defining caps and would not formalize the event-driven transition content.
- Upgraded only C-FLOW-EXHAUST to PROVED+MACHINE-CHECKED; reason: Lean now proves the inhabited least-failure characterization, every earlier payment, the rational-floor pure-run formula, and the matched-inflow empty-set corollary.
- Kept C-GP6B independently rederived despite its Lean equivalence; reason: the compiled statement does not encode component composition or the relative-delay sufficient condition.
- Kept C-GP8 independently rederived despite its Lean quotient theorem and counterexample; reason: the compiled statement does not encode record-signature preservation or transition equivariance by date induction.
- Fixed the malformed sharpness atoms in Part II §1 by replacing all three `,quad` fragments with `,\quad` and spacing the final atom; full six-part lint found no other malformed command or unbalanced delimiter, brace, or left/right pair.
- Added permanent LaTeX delimiter, brace, left/right, and missing-command checks to the one-command document audit; reason: make the rendering repair regression-resistant.
- Added the compact point-of-use semantics table to Part V; reason: expose only the claim families whose truth or content differs between stock and flow without duplicating the ledger.
- Expanded C-GP1's proof into computability, transition-count, procedure-funding, world-funding, terminal-clause, and ecology intermediate claims; reason: each former sentence combined multiple nontrivial moves.
- Expanded C-GP2's proof at the peak/supremum distinction, fenced-account sum, unreachable-key gap, and saturation-dependent quadratic law; reason: make every endowment conclusion traceable to a displayed intermediate inequality.
- Expanded C-GP3's proof at the last-transition reduction, terminal-coverage necessity, and `Psi0` versus `\Psi_0+1` era accounting; reason: these were the biconditional's load-bearing steps.
- Inspected C-GP4's proof and made no change; reason: its two directions already expose the complete finite-predecessor and finite-slot arguments without suppressing an intermediate inference.
- Expanded C-GP5's proof at trace induction, seam-richness necessity, and fixed-horizon cap maximality; reason: distinguish the unconditional separability classification from the directional numerical cap.
- Expanded C-GP6B's proof with the pooled upper cap and zero-sum nonnegative-gap identity; reason: display the exact equality condition now formalized in Lean.
- Expanded C-GP7's proof into payoff identities, per-key aggregation, exact-peak sufficiency, and the uncovered-key family argument; reason: separate the three repeated-complaint regimes.
- Expanded C-GP8's proof with the transition-conjugacy induction and both directions of quotient factorization; reason: distinguish system equivariance from the formalized quotient lemma.
- Expanded C-GP9's proof at removal monotonicity and pointwise lattice extremality; reason: make the compiler-class axioms used by each conclusion explicit.
- Expanded C-GN3's proof into the three exhaustive funding intervals; reason: remove the proof's cross-reference-only compression.
- Expanded C-GN5's proof into the positive-charge identity, zero-charge formal admission result, and behavioral impossibility; reason: keep the frozen theorem, modified-rule result, and conditional extension logically separate.
- Inspected the informative XI deltas for C-GP2, C-GP4, C-GP5, C-GP6B, and C-GN3 and made no statement changes; reason: saturation, filing-specific finite overtaking, fixed-horizon directional slack, peak synchronization, and the exact half-open interval were already primary hypotheses or conclusions, with the superseded versions explicitly denied.
- Rewrote the Lean target evaluation, scope limits, and status consequences in `VERIFICATION.md`; reason: remove every claim about the deleted shells and state exactly what the replacements compile.
- Updated ledger verification cells for C-GP6A, C-GP6B, C-GP8, and C-GN1; reason: remove deleted-shell evidence and point to the surviving Tier A or substantive Lean checks without status inflation.
- Recorded the improvement-pass isolated final run and exact Lean/Mathlib commits in `VERIFICATION.md`; reason: make the delivered verification state reproducible and distinguish it from the original run.
