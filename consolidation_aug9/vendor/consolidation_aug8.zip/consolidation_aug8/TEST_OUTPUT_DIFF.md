# Test-output diff

This is the exact unified comparison of the baseline and final portable-runner outputs, except that nondeterministic elapsed durations are normalized to <elapsed>. The only semantic output changes are the newly required audit prelude, canonical identifiers/vocabulary, the adopted per-provenance schedule labels, and the explicit Lean status line. No displayed exact-rational value changed.

## consolidation_aug8

~~~diff
--- /tmp/consolidation_before.out
+++ /tmp/consolidation_after.out
@@ -1,7 +1,30 @@
+RENAME CHECK PASSED: 24 pure files byte-round-tripped
+CONTEXTUAL EXCLUDED: consolidation_aug8/DECISION_LEDGER.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/DEVIATIONS.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/FOR_HUMANS.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/GLOSSARY.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/INTERPRETATION.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/LEDGER.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/OPEN_PROBLEMS.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/README.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/THEORY_1_FOUNDATIONS.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/THEORY_2_LEVERAGE.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/THEORY_3_OPERATIVE_FORCE.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/THEORY_4_LEARNING_AND_INSTALLATION.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/THEORY_5_CHALLENGE_SEMANTICS.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/THEORY_6_PARAMETERIZED_ANSWERABILITY.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/VERIFICATION.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/tests/run.py (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: normative-learner/JOINT_THEORY.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: normative-learner/LEDGER.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: normative-learner/MIGRATION_THEORY.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: normative-learner/OPEN_PROBLEMS.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: normative-learner/README.md (see AMBIGUITIES.md)
+CONTEXTUAL FILES: 21
 test_dk_specialization_and_one_unit_failures (test_tier_a.TierAFresh) ... ok
 test_epoch_self_financing_and_intra_cycle_deficit (test_tier_a.TierAFresh) ... ok
 test_exhaustion_and_deadline_pair (test_tier_a.TierAFresh) ... ok
-test_gauge_and_compiler_shocks (test_tier_a.TierAFresh) ... ok
+test_gauge_and_reference_jumps (test_tier_a.TierAFresh) ... ok
 test_leverage_and_lp_dual (test_tier_a.TierAFresh) ... ok
 test_of1_boundary_identity_and_audit_horizon (test_tier_a.TierAFresh) ... ok
 test_other_displayed_exact_values (test_tier_a.TierAFresh) ... ok
@@ -31,30 +54,30 @@
 test_polyhedral_repair_nonuniqueness (test_vendored_iv.HardenedWitnessTests) ... ok
 test_public_twins (test_vendored_iv.HardenedWitnessTests) ... ok
 test_six_case_selection_and_holdout (test_vendored_iv.HardenedWitnessTests) ... ok
-test_any_positive_cap_breaks_surplus_free_strong_form (test_vendored_ix.FirewallTests) ... ok
-test_certified_slack_supports_a_nonzero_cap (test_vendored_ix.FirewallTests) ... ok
-test_flow_adequacy_reserve (test_vendored_ix.FirewallTests) ... ok
-test_ring_fence_blocks_the_same_adversary (test_vendored_ix.FirewallTests) ... ok
-test_unpartitioned_hume_witness (test_vendored_ix.FirewallTests) ... ok
-test_consistent_world_challenge_loses_under_latency_gate (test_vendored_ix.FlowKernelTests) ... ok
-test_false_floor_drip_recycling (test_vendored_ix.FlowKernelTests) ... ok
-test_inflow_can_remove_a_general_deadline (test_vendored_ix.FlowKernelTests) ... ok
-test_latency_inflation_changes_false_complaint_payoff (test_vendored_ix.FlowKernelTests) ... ok
-test_nuisance_farming_is_strictly_losing (test_vendored_ix.FlowKernelTests) ... ok
-test_old_deadline_is_replaced_by_strict_exhaustion (test_vendored_ix.FlowKernelTests) ... ok
-test_substantive_siege_is_profitable (test_vendored_ix.FlowKernelTests) ... ok
+test_any_positive_cap_breaks_surplus_free_strong_form (test_vendored_ix.FencingTests) ... ok
+test_certified_slack_supports_a_nonzero_cap (test_vendored_ix.FencingTests) ... ok
+test_flow_adequacy_reserve (test_vendored_ix.FencingTests) ... ok
+test_ring_fence_blocks_the_same_adversary (test_vendored_ix.FencingTests) ... ok
+test_unpartitioned_hume_witness (test_vendored_ix.FencingTests) ... ok
+test_consistent_world_challenge_loses_under_latency_gate (test_vendored_ix.FlowMechanismTests) ... ok
+test_false_bound_drip_recycling (test_vendored_ix.FlowMechanismTests) ... ok
+test_inflow_can_remove_a_general_deadline (test_vendored_ix.FlowMechanismTests) ... ok
+test_latency_inflation_changes_false_complaint_payoff (test_vendored_ix.FlowMechanismTests) ... ok
+test_nuisance_farming_is_strictly_losing (test_vendored_ix.FlowMechanismTests) ... ok
+test_old_deadline_is_replaced_by_strict_exhaustion (test_vendored_ix.FlowMechanismTests) ... ok
+test_substantive_recurrent_complaint_sequence_is_profitable (test_vendored_ix.FlowMechanismTests) ... ok
 test_phase_vi_viii_inputs_match_recorded_checksums (test_vendored_ix.FrozenInputTests) ... skipped 'superseded by FROZEN_INPUT_CHECKSUMS.json and tests/run.py'
-test_accrual_bridge_exposes_first_shock (test_vendored_ix.PropagationAndGaugeTests) ... ok
+test_accrual_bridge_exposes_first_jump (test_vendored_ix.PropagationAndGaugeTests) ... ok
 test_flow_record_twins_are_conjugate (test_vendored_ix.PropagationAndGaugeTests) ... ok
 test_max_shields_a_nonmaximal_chain (test_vendored_ix.PropagationAndGaugeTests) ... ok
 test_max_unique_leader_moves_by_order_statistic_gap (test_vendored_ix.PropagationAndGaugeTests) ... ok
 test_a1_unrestricted_overload_has_linear_backlog (test_vendored_vi.ExactWitnessTests) ... ok
 test_d1_timeout_bound_and_equality_case (test_vendored_vi.ExactWitnessTests) ... ok
 test_d2_contentful_survival_witness (test_vendored_vi.ExactWitnessTests) ... ok
-test_d3_false_floor_is_as_solvent_but_pays_without_bound (test_vendored_vi.ExactWitnessTests) ... ok
+test_d3_false_bound_is_as_solvent_but_pays_without_bound (test_vendored_vi.ExactWitnessTests) ... ok
 test_d4_external_relabeling_preserves_lock_trace (test_vendored_vi.ExactWitnessTests) ... ok
 test_decision_ledger_has_the_five_fixed_verdicts (test_vendored_vi.ExactWitnessTests) ... skipped 'superseded by the consolidation claim/status audit'
-test_nc_primitive_dismissal_witness_has_no_answer (test_vendored_vi.ExactWitnessTests) ... ok
+test_nc_primitive_dismissal_witness_has_no_response (test_vendored_vi.ExactWitnessTests) ... ok
 test_no_float_literals_in_witness_source (test_vendored_vi.ExactWitnessTests) ... ok
 test_a0_bridge_gap (test_vendored_vii.PhaseVIIWitnessTests) ... ok
 test_a2_addressing_and_whitewash (test_vendored_vii.PhaseVIIWitnessTests) ... ok
@@ -70,56 +93,56 @@
 test_no_float_literals_in_source (test_vendored_vii.PhaseVIIWitnessTests) ... ok
 test_construction_bound_is_exact_rational (test_vendored_viii.ArcAndConstructionTests) ... ok
 test_consumption_cycle_does_not_stabilize (test_vendored_viii.ArcAndConstructionTests) ... ok
-test_missing_route_is_not_arc (test_vendored_viii.ArcAndConstructionTests) ... ok
-test_one_route_arc_certificate (test_vendored_viii.ArcAndConstructionTests) ... ok
+test_missing_route_is_not_route_coverage (test_vendored_viii.ArcAndConstructionTests) ... ok
+test_one_route_route_coverage_certificate (test_vendored_viii.ArcAndConstructionTests) ... ok
 test_policy_trace_stabilizes (test_vendored_viii.ArcAndConstructionTests) ... ok
 test_latency_inflation_repair (test_vendored_viii.MechanismWitnessTests) ... ok
 test_missing_route_world_extraction (test_vendored_viii.MechanismWitnessTests) ... ok
 test_msr_adequacy_witness_fails (test_vendored_viii.MechanismWitnessTests) ... ok
-test_msr_kills_consistent_floor_martyr (test_vendored_viii.MechanismWitnessTests) ... ok
-test_silent_false_floor_has_no_transfer (test_vendored_viii.MechanismWitnessTests) ... ok
+test_msr_kills_consistent_bound_starvation_case (test_vendored_viii.MechanismWitnessTests) ... ok
+test_silent_false_bound_has_no_transfer (test_vendored_viii.MechanismWitnessTests) ... ok
 test_structured_witness_residual_adequacy (test_vendored_viii.MechanismWitnessTests) ... ok
-test_anti_nuisance_axiom_holds_on_DK (test_vendored_x.DisplayedKernelTests) ... ok
-test_exact_minimal_reserves (test_vendored_x.DisplayedKernelTests) ... ok
-test_minimum_funds_every_obligation (test_vendored_x.DisplayedKernelTests) ... ok
-test_one_rent_unit_below_the_minimum_triggers (test_vendored_x.DisplayedKernelTests) ... ok
-test_sufficient_bound_dominates_the_minimum (test_vendored_x.DisplayedKernelTests) ... ok
-test_transient_date_bound (test_vendored_x.DisplayedKernelTests) ... ok
-test_world_settlement_date_is_one_atomic_obligation (test_vendored_x.DisplayedKernelTests) ... ok
+test_anti_nuisance_axiom_holds_on_DK (test_vendored_x.DisplayedMechanismTests) ... ok
+test_exact_minimal_reserves (test_vendored_x.DisplayedMechanismTests) ... ok
+test_minimum_funds_every_obligation (test_vendored_x.DisplayedMechanismTests) ... ok
+test_one_charge_unit_below_the_minimum_triggers (test_vendored_x.DisplayedMechanismTests) ... ok
+test_sufficient_bound_dominates_the_minimum (test_vendored_x.DisplayedMechanismTests) ... ok
+test_transient_date_bound (test_vendored_x.DisplayedMechanismTests) ... ok
+test_world_settlement_date_is_one_atomic_obligation (test_vendored_x.DisplayedMechanismTests) ... ok
 test_date_major_admission_is_starvation_free (test_vendored_x.EcologyTests) ... ok
 test_every_eligible_filing_is_eventually_admitted (test_vendored_x.EcologyTests) ... ok
 test_index_major_admission_starves (test_vendored_x.EcologyTests) ... ok
+test_rejected_per_index_schedule_stays_inside_ecology_total (test_vendored_x.EcologyTests) ... ok
+test_rejected_per_index_subsidy_is_not_self_diluting (test_vendored_x.EcologyTests)
+AF-X.2 is retained as the witness against the rejected schedule. ... ok
 test_splitting_cannot_beat_the_dovetail_throughput_bound (test_vendored_x.EcologyTests) ... ok
-test_splitting_does_not_divide_the_subsidy (test_vendored_x.EcologyTests)
-Adverse finding AF-X.2: per-index schedules are not self-diluting. ... ok
-test_splitting_stays_inside_the_summable_ecology_total (test_vendored_x.EcologyTests) ... ok
 test_no_bootstrap_from_zero (test_vendored_x.EndowmentTests) ... ok
 test_patronage_clause_holds_on_the_pure_run (test_vendored_x.EndowmentTests) ... ok
 test_procedure_minimum_scales_linearly_in_n_P (test_vendored_x.EndowmentTests) ... ok
 test_recorded_inflow_never_creates_a_trigger (test_vendored_x.EndowmentTests) ... ok
 test_phase_ix_is_inside_the_frozen_set (test_vendored_x.FrozenInputTests) ... skipped 'superseded by FROZEN_INPUT_CHECKSUMS.json and tests/run.py'
 test_phase_vi_ix_inputs_match_recorded_checksums (test_vendored_x.FrozenInputTests) ... skipped 'superseded by FROZEN_INPUT_CHECKSUMS.json and tests/run.py'
-test_drop_arc_coverage_is_a_funding_trap (test_vendored_x.NecessityQuadrupleTests) ... ok
 test_drop_foa_kills_an_already_correct_book (test_vendored_x.NecessityQuadrupleTests) ... ok
 test_drop_latency_gate_makes_a_correct_book_bleed (test_vendored_x.NecessityQuadrupleTests) ... ok
-test_dropping_the_firewall_does_not_kill_the_construction (test_vendored_x.NecessityQuadrupleTests)
+test_drop_route_coverage_is_a_funding_trap (test_vendored_x.NecessityQuadrupleTests) ... ok
+test_dropping_the_fencing_does_not_kill_the_construction (test_vendored_x.NecessityQuadrupleTests)
 Adverse finding AF-X.1: merging never lowers available funding. ... ok
 test_merged_pool_funds_every_ring_fenced_obligation (test_vendored_x.NecessityQuadrupleTests) ... ok
 test_no_delay_beats_the_declared_DK_worst_case (test_vendored_x.NecessityQuadrupleTests) ... ok
 test_peak_alignment_lemma (test_vendored_x.NecessityQuadrupleTests) ... ok
-test_answered_complaint_is_strictly_losing (test_vendored_x.SiegeBoundaryTests) ... ok
-test_ix_a4_unbounded_siege_needs_a_dropped_hypothesis (test_vendored_x.SiegeBoundaryTests)
-Without repair coverage the whole reserve is extracted. ... ok
-test_no_complaint_suspends_its_target_at_the_minimum (test_vendored_x.SiegeBoundaryTests) ... ok
-test_repair_only_complaint_is_strictly_profitable (test_vendored_x.SiegeBoundaryTests)
-Adverse finding AF-X.3: siege is bounded, not unprofitable. ... ok
-test_siege_revenue_is_inside_the_procedure_minimum (test_vendored_x.SiegeBoundaryTests) ... ok
-test_total_siege_revenue_is_finite (test_vendored_x.SiegeBoundaryTests) ... ok
+test_ix_a4_unbounded_recurrent_complaint_sequence_needs_a_dropped_hypothesis (test_vendored_x.RecurrentComplaintSequenceBoundaryTests)
+Without route coverage the whole reserve is extracted. ... ok
+test_no_complaint_suspends_its_target_at_the_minimum (test_vendored_x.RecurrentComplaintSequenceBoundaryTests) ... ok
+test_recurrent_complaint_sequence_revenue_is_inside_the_procedure_minimum (test_vendored_x.RecurrentComplaintSequenceBoundaryTests) ... ok
+test_repair_only_complaint_is_strictly_profitable (test_vendored_x.RecurrentComplaintSequenceBoundaryTests)
+Adverse finding AF-X.3: recurrent_complaint_sequence is bounded, not unprofitable. ... ok
+test_responded_complaint_is_strictly_losing (test_vendored_x.RecurrentComplaintSequenceBoundaryTests) ... ok
+test_total_recurrent_complaint_sequence_revenue_is_finite (test_vendored_x.RecurrentComplaintSequenceBoundaryTests) ... ok
 test_closure_epoch_balances_are_nondecreasing (test_vendored_x.TailSelfFinancingTests) ... ok
 test_date_by_date_nondecrease_is_refuted (test_vendored_x.TailSelfFinancingTests)
-Honest income arrives one date after the rent it must cover. ... ok
+Honest income arrives one date after the charge it must cover. ... ok
 test_per_challenge_net_is_positive_by_the_axiom (test_vendored_x.TailSelfFinancingTests) ... ok
-test_working_capital_equals_the_FOA_R_rent_term (test_vendored_x.TailSelfFinancingTests) ... ok
+test_working_capital_equals_the_FOA_R_charge_term (test_vendored_x.TailSelfFinancingTests) ... ok
 test_full_phase_vi_x_tree_matches_manifest (test_vendored_xi.FrozenTreeTests) ... skipped 'superseded by FROZEN_INPUT_CHECKSUMS.json and tests/run.py'
 test_gp2_coarse_gap_has_no_uniform_constant (test_vendored_xi.GeneralPositiveWitnessTests) ... ok
 test_gp2_quadratic_requires_saturation (test_vendored_xi.GeneralPositiveWitnessTests) ... ok
@@ -134,18 +157,19 @@
 test_gp9_actual_compiler_order_interval (test_vendored_xi.GeneralPositiveWitnessTests) ... ok
 test_gp1_foa_specializes_to_DK (test_vendored_xi.PositiveSpecializationTests) ... ok
 test_gp2_exact_minimum_specializes_to_DK (test_vendored_xi.PositiveSpecializationTests) ... ok
-test_gp5_firewall_specializes_to_IX (test_vendored_xi.PositiveSpecializationTests) ... ok
+test_gp5_fencing_specializes_to_IX (test_vendored_xi.PositiveSpecializationTests) ... ok
 test_gp6_alignment_specializes_to_X (test_vendored_xi.PositiveSpecializationTests) ... ok
-test_gp7_siege_specializes_to_DK (test_vendored_xi.PositiveSpecializationTests) ... ok
+test_gp7_recurrent_complaint_sequence_specializes_to_DK (test_vendored_xi.PositiveSpecializationTests) ... ok
 test_gp9_compilers_specialize_to_IX (test_vendored_xi.PositiveSpecializationTests) ... ok
 test_gn1_matching_inflow_defeats_every_displayed_prefix (test_vendored_xi.UniformNegativeWitnessTests) ... ok
 test_gn2_no_bootstrap_has_a_nonvacuity_boundary (test_vendored_xi.UniformNegativeWitnessTests) ... ok
 test_gn3_bypass_threshold_is_an_interval_not_all_underfunding (test_vendored_xi.UniformNegativeWitnessTests) ... ok
-test_gn5_positive_literal_rent_pays_correct_repair (test_vendored_xi.UniformNegativeWitnessTests) ... ok
+test_gn5_positive_literal_charge_pays_correct_repair (test_vendored_xi.UniformNegativeWitnessTests) ... ok
 test_gn6_key_boundary_requires_repair_only_density (test_vendored_xi.UniformNegativeWitnessTests) ... ok
 
 ----------------------------------------------------------------------
 Ran 140 tests in <elapsed>
 
 OK (skipped=6)
-ALL GREEN: Tier A, Tier B, document audits, and Lean
+LEAN CHECKED: both consolidation Lean files compiled sorry-free
+ALL PYTHON TESTS GREEN: Tier A, Tier B, document and integrity audits
~~~

## normative-learner

~~~diff
--- /tmp/normative_before.out
+++ /tmp/normative_after.out
@@ -1,7 +1,30 @@
+RENAME CHECK PASSED: 24 pure files byte-round-tripped
+CONTEXTUAL EXCLUDED: consolidation_aug8/DECISION_LEDGER.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/DEVIATIONS.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/FOR_HUMANS.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/GLOSSARY.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/INTERPRETATION.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/LEDGER.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/OPEN_PROBLEMS.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/README.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/THEORY_1_FOUNDATIONS.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/THEORY_2_LEVERAGE.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/THEORY_3_OPERATIVE_FORCE.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/THEORY_4_LEARNING_AND_INSTALLATION.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/THEORY_5_CHALLENGE_SEMANTICS.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/THEORY_6_PARAMETERIZED_ANSWERABILITY.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/VERIFICATION.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: consolidation_aug8/tests/run.py (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: normative-learner/JOINT_THEORY.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: normative-learner/LEDGER.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: normative-learner/MIGRATION_THEORY.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: normative-learner/OPEN_PROBLEMS.md (see AMBIGUITIES.md)
+CONTEXTUAL EXCLUDED: normative-learner/README.md (see AMBIGUITIES.md)
+CONTEXTUAL FILES: 21
 test_claim_ledger_is_complete (test_joint.JointExactTests) ... ok
 test_duplicate_identical_channel_really_doubles_debit (test_joint.JointExactTests) ... ok
 test_exact_joint_trace (test_joint.JointExactTests) ... ok
-test_expansion_stable_suspension_has_zero_shock (test_joint.JointExactTests) ... ok
+test_expansion_stable_suspension_has_zero_jump (test_joint.JointExactTests) ... ok
 test_literal_liability_identity_uses_obligation_id (test_joint.JointExactTests) ... ok
 test_load_bearing_movement_recursion (test_joint.JointExactTests) ... ok
 test_one_change_alone_has_no_uniform_movement_cap (test_joint.JointExactTests) ... ok
@@ -12,6 +35,7 @@
 test_disclosed_but_unauthorized_loss (test_migration.MigrationVerifierTests) ... ok
 test_duplicate_consuming_cells (test_migration.MigrationVerifierTests) ... ok
 test_duplicate_loss_key (test_migration.MigrationVerifierTests) ... ok
+test_eventual_route_coverage_is_computed_from_routes (test_migration.MigrationVerifierTests) ... ok
 test_inexpressibility_is_not_discharge (test_migration.MigrationVerifierTests) ... ok
 test_late_burden_target_reassignment (test_migration.MigrationVerifierTests) ... ok
 test_local_bridge_does_not_supply_a_universal_ontology (test_migration.MigrationVerifierTests) ... ok
@@ -25,12 +49,11 @@
 test_raw_harm_certificate_passes_all_nine_checks (test_migration.MigrationVerifierTests) ... ok
 test_semantic_coupling_is_not_authorization (test_migration.MigrationVerifierTests) ... ok
 test_split_challenge_has_uncovered_descendant (test_migration.MigrationVerifierTests) ... ok
-test_terminal_coverage_is_computed_from_routes (test_migration.MigrationVerifierTests) ... ok
 test_uncertified_early_pointer_swap (test_migration.MigrationVerifierTests) ... ok
 
 ----------------------------------------------------------------------
 Ran 29 tests in <elapsed>
 
 OK
-LEAN CHECKED: load-bearing Lean kernels compiled
+LEAN CHECKED: both normative-learner Lean files compiled sorry-free
 ALL PYTHON TESTS GREEN
~~~

