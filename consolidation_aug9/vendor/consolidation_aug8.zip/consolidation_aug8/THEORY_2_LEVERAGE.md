# Part II. Leverage and finite constraint geometry

## 1. The leverage identity

Let \(A,I,T\subseteq\Omega_t\) and \(c_P,c_A,c_S\in[0,1]\). Define
\[
\delta_P=\mu(A)-c_P,\quad
\delta_A=\mu(A\cap I)-c_A\mu(A),
\]
\[
\delta_S=\mu(A\cap I\cap T)-c_S\mu(A\cap I),\quad
\delta_T=\mu(T)-\mu(A\cap I\cap T).
\]

**Leverage theorem.** {#C-LEV} **Status: PROVED+MACHINE-CHECKED.** If the four slacks are nonnegative, then
\[
\mu(T)\ge c_Pc_Ac_S,
\]
and exactly
\[
\mu(T)-c_Pc_Ac_S
=\delta_T+\delta_S+c_S\delta_A+c_Sc_A\delta_P. \tag{2.1}
\]
The coefficient is sharp for every \((c_P,c_A,c_S)\).

**Proof.** Substitute the definitions on the right of (2.1) and cancel. Each remaining term is nonnegative. For sharpness, use four atoms with masses
\[
c_Pc_Ac_S,\quad c_Pc_A(1-c_S),\quad c_P(1-c_A),\quad 1-c_P
\]
on \(A\cap I\cap T,A\cap I\cap T^c,A\cap I^c,A^c\), and take \(T=A\cap I\cap T\). All slacks vanish. \(\square\)

Deleting any lower-bound premise permits its corresponding factor to fall to zero, so all three premises are necessary for the stated product.

## 2. Certificate regions and sharp network bounds

**Finite certificate-region theorem.** {#C-CERT} **Status: PROVED+INDEPENDENTLY-REDERIVED.** A finite set of affine certificate endorsements cuts out a closed convex polytope in \(\Delta(\Omega_t)\). With rational coefficients, feasibility is decidable by exact rational linear programming, and every bounded rational linear objective attains a rational optimum at a rational vertex.

**Proof.** Each endorsement is a closed halfspace. Their finite intersection with the compact simplex is closed, convex, and bounded. Rational elimination decides feasibility. A linear objective attains an optimum on a nonempty compact polytope; some vertex lies in its optimum face, and rational elimination gives rational vertex coordinates. \(\square\)

**Network leverage and dual certificate.** {#C-NETWORK} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Every warrant path gives a valid product lower bound by repeated application of the leverage theorem. The sharp global bound on target \(T\) is
\[
\min_{\mu}\ \mu(T)\quad\text{subject to }\mu\in\Delta(\Omega_t)\text{ and all active endorsements}.
\]
For a feasible instance, finite-dimensional strong duality supplies a finite linear certificate of the optimum. For an infeasible instance, Farkas' lemma supplies a finite contradiction certificate.

**Proof.** Induct along each path for validity. The preceding theorem supplies the primal rational polytope. Strong duality gives equal primal and dual optima; the infeasible alternative is Farkas' theorem. Overlapping paths can share constraints, so the minimum need not equal any single path product. \(\square\)

The fresh exact suite recomputes the four-atom instance \((3/4)(2/3)(4/5)=2/5\) and its matching primal and dual values.

## 3. Certified serviceability

Let \(\Delta(\Omega_t)\subset\mathbb R^d\) be a nonempty rational polytope, \(\theta\in(0,1]\cap\mathbb Q\), and requested endorsements \(A_ip\le b_i\). Let \(r_i\ge0\) have positive rational weights \(w_i\), and let \(h_{\Delta}(A_i)=\max_{z\in\Delta(\Omega_t)}A_iz\).

**Core-certified relaxation theorem.** {#C-COMPILER} **Status: PROVED+INDEPENDENTLY-REDERIVED.** The program
\[
\min_{q\in\Delta(\Omega_t),r\ge0}\sum_iw_ir_i,
\qquad (1-\theta)A_iq+\theta h_{\Delta}(A_i)\le b_i+r_i
\]
is a feasible rational linear program with a rational optimum. Its repaired region
\[
\mathcal C_t=\{p\in\Delta(\Omega_t):A_ip\le b_i+r_i\ \forall i\}
\]
contains \(q+\theta(\Delta(\Omega_t)-q)\).

**Proof.** Each support value is the rational optimum of a linear program. The displayed constraints are linear in \((q,r)\). Large relaxations give feasibility; compactness of \(\Delta(\Omega_t)\), positivity of weights, and closedness give attainment; rational linear-programming theory gives a rational optimum. For \(z\in\Delta(\Omega_t)\),
\[
A_i(q+\theta(z-q))=(1-\theta)A_iq+\theta A_iz\le(1-\theta)A_iq+\theta h_{\Delta}(A_i)\le b_i+r_i.
\]
Thus every contracted point is in \(\mathcal C_t\). \(\square\)

The optimizer need not be unique. For \(\Delta(\Omega_t)=[0,1]\), \(\theta=1/2\), and requests \(p\ge3/4,p\le1/4\), every \(q\in[0,1]\) supports total relaxation one with \(r_L=3/4-q/2\), \(r_U=1/4+q/2\). A selection rule is therefore additional input.

For a box \(\Delta(\Omega_t)=[0,1]^d\) with intervals \([l_j,u_j]\), a core of coefficient \(\theta\) exists exactly when each repaired interval has width at least \(\theta\). Minimum unweighted widening is \([\theta-(u_j-l_j)]_+\); for \(\theta<1\), references satisfy
\[
\frac{l'_j}{1-\theta}\le q_j\le\frac{u'_j-\theta}{1-\theta}.
\]

## 4. Self-financing separation

**Self-financing separation theorem.** {#C-SELF-FIN} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Let \(\Omega_t=\{\omega_i\}_{i=1}^m\) be represented payoff vectors, let \(\mu_i>0\) sum to one, and quote forever \(p=\sum_i\mu_i\omega_i\). If an ordinary self-financing cumulative payoff satisfies \(G_N(\omega_j)\ge-R\) for every \(j,N\), then
\[
G_N(\omega_i)\le R\frac{1-\mu_i}{\mu_i}.
\]
This remains true if \(p\) violates an extra nonlogical endorsement.

**Proof.** Each trade has zero \(\mu\)-expected payoff at \(p\), hence \(\sum_j\mu_jG_N(\omega_j)=0\). Therefore
\[
\mu_iG_N(\omega_i)=-\sum_{j\ne i}\mu_jG_N(\omega_j)\le R(1-\mu_i).
\]
Divide by full-support \(\mu_i\). \(\square\)

Full support is necessary: a zero-mass world can carry arbitrary gain without changing expectation. The theorem proves that an extra warrant endorsement cannot in general be enforced by ordinary risk-limited settlement trading alone.

## 5. Full-coupling conditioning boundary

Let finite nonempty sets \(X,Y\) have allowed marginal sets \(\varnothing\ne\mathcal E\subseteq\Delta(X)\) and \(\mathcal N\subseteq\Delta(Y)\). Let \(\mathcal J_{all}\) contain every joint distribution whose two marginals lie in those sets. For \(A\subseteq X\), let \(\mathcal N_A^+\) be the set of conditional \(Y\)-distributions given \(A\), omitting joints with zero probability for \(A\).

**Full-coupling non-contraction.** {#C-COUP-NC} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If some \(e_0\in\mathcal E\) has \(e_0(A)>0\), then \(\mathcal N\subseteq\mathcal N_A^+\). The containment may be strict.

**Proof.** For each \(n\in\mathcal N\), the independent product \(e_0\otimes n\) is in \(\mathcal J_{all}\), and its conditional \(Y\)-distribution given \(A\) is exactly \(n\). For strictness, take binary \(X,Y\), both allowed marginal sets equal to the singleton one-half, and write \(\lambda=P(A\cap B)\in[0,1/2]\). Then \(P(B\mid A)=2\lambda\) ranges over \([0,1]\). \(\square\)

**Full-coupling posterior characterization.** {#C-COUP-CHAR} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Put \(\mathcal A=\{e(A):e\in\mathcal E,e(A)>0\}\). A distribution \(m\in\Delta(Y)\) belongs to \(\mathcal N_A^+\) exactly when there are \(\lambda\in\mathcal A\) and \(n\in\mathcal N\) such that either \(\lambda=1\) and \(m=n\), or \(0<\lambda<1\) and \(\lambda m(y)\le n(y)\) for every \(y\). Equivalently, \(n=\lambda m+(1-\lambda)m'\) for some \(m'\in\Delta(Y)\).

**Proof.** Any admissible joint obeys total probability with \(m'\) its conditional distribution on \(A^c\), proving necessity. Conversely, coordinatewise domination makes \(m'=(n-\lambda m)/(1-\lambda)\) nonnegative with coordinates summing to one. Choose \(e\in\mathcal E\) with \(e(A)=\lambda\), use conditional distribution \(m\) on \(A\) and \(m'\) on \(A^c\), and obtain a joint with marginal \(n\) and posterior \(m\). The \(\lambda=1\) case is immediate. \(\square\)

The positive-probability hypothesis is necessary for ordinary conditioning. Equality rather than non-contraction requires \(\mathcal N\) to be closed under every displayed component operation; the binary witness shows it is not automatic.
