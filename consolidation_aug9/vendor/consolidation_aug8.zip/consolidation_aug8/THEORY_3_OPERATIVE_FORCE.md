# Part III. Operative force and moving permitted regions

Let \(\Omega_t=\{w_1,\ldots,w_m\}\subset\mathbb R^d\) be nonempty and let its credal simplex be \(\Delta(\Omega_t)=\operatorname{conv}(\Omega_t)\). At date \(t\), a nonempty permitted region \(\mathcal C_t\subseteq\Delta(\Omega_t)\), reference \(q_t\in\Delta(\Omega_t)\), and coefficient \(\theta_t\in(0,1]\) satisfy
\[
q_t+\theta_t(\Delta(\Omega_t)-q_t)\subseteq\mathcal C_t. \tag{3.1}
\]
A realized position and quote \((x_t,p_t)\) satisfy the approximate variational inequality
\[
\langle x_t,y-p_t\rangle\le\varepsilon_t\quad(y\in\mathcal C_t),\qquad\varepsilon_t\ge0. \tag{3.2}
\]
The position executes at \(p_t\), with payoff \(g_t(w)=\langle x_t,w-p_t\rangle\), post-trade holdings \(H_t=\sum_{s=0}^tx_s\), and prefix payoff \(G_N(w)=\sum_{t=0}^{N-1}g_t(w)\). The reference move \(q_t\to q_{t+1}\) occurs after trade \(t\). Assume \(G_n(w_i)\ge-R\) for all represented worlds and relevant prefixes.

## 1. Fixed-core wealth cap

**Anchored comparison.** {#C-OF0} **Status: PROVED+INDEPENDENTLY-REDERIVED.** For every \(w\in\Delta(\Omega_t)\),
\[
g_t(w)\le \frac{\varepsilon_t}{\theta_t}-\frac{1-\theta_t}{\theta_t}\langle x_t,q_t-p_t\rangle.
\]

**Proof.** Substitute \(y=q_t+\theta_t(w-q_t)\) in (3.2), expand the affine combination, and divide by \(\theta_t>0\). \(\square\)

**Repaired summation identity.** {#C-OFSB} **Status: PROVED+INDEPENDENTLY-REDERIVED.** For \(N\ge1\),
\[
\sum_{t=0}^{N-1}\langle x_t,q_t-p_t\rangle
=G_N(q_{N-1})+\sum_{u=0}^{N-2}\langle H_u,q_u-q_{u+1}\rangle. \tag{3.3}
\]

**Proof.** Subtract \(G_N(q_{N-1})\). Price terms cancel, and
\[
\sum_{t=0}^{N-1}\langle x_t,q_t-q_{N-1}\rangle
=\sum_{t=0}^{N-2}\sum_{u=t}^{N-2}\langle x_t,q_u-q_{u+1}\rangle.
\]
Exchange the finite sums; the inner sum is \(H_u\). The final trade has no subsequent charged move. \(\square\)

The endpoint \(q_{N-1}\) is essential for this horizon. Replacing it by \(q_N\) without adding the final movement is already false at \(N=1\).

Define \(\theta_t=\theta\), \(\kappa=(1-\theta)/\theta\), \(\varepsilon_{1:N}=\sum_{t<N}\varepsilon_t\), and
\[
M_N=\sum_{t=0}^{N-2}[-\langle H_t,q_t-q_{t+1}\rangle]_+.
\]

**Operative-force wealth-cap theorem.** {#C-OF1} **Status: PROVED+INDEPENDENTLY-REDERIVED.** For every \(w\in\Delta(\Omega_t)\),
\[
G_N(w)\le \frac{\varepsilon_{1:N}}{\theta}+\kappa(R+M_N). \tag{3.4}
\]

**Proof.** Sum the anchored comparisons. By convex averaging at \(q_{N-1}\), \(G_N(q_{N-1})\ge-R\). Each movement scalar \(m\) obeys \(m\ge-[-m]_+\), so (3.3) gives \(\sum_t\langle x_t,q_t-p_t\rangle\ge-R-M_N\). Multiplying by \(-\kappa\le0\) and substituting gives (3.4). \(\square\)

No rationality, box shape, affine demand, or exact solver is used after the witnesses exist. A uniform infinite-horizon cap requires a positive uniform core, a uniform risk limit, summable error, and capped movement liability.

**Individual nonexploitation corollary.** {#C-OF-IND} **Status: PROVED (single derivation).** If individual risk limits sum to \(-R\) and the right side of (3.4) has a uniform cap on admitted prefixes, no individual can have unbounded gain with fixed risk.

**Proof.** If one gain diverged while every other payoff retained its bound, aggregate gain would diverge, contradicting (3.4). \(\square\)

## 2. Variable cores and movement accounting

**Variable-core theorem.** {#C-OF2} **Status: PROVED+INDEPENDENTLY-REDERIVED.** For arbitrary positive \(\theta_t\), setting \(\underline\theta_N=\min_{t<N}\theta_t\) gives (3.4) with \(\theta=\underline\theta_N\). If \(\theta_t\) is nondecreasing and \(\kappa_t=(1-\theta_t)/\theta_t\), define \(J_t=\sum_{s\le t}\kappa_sx_s\) and
\[
M_N^\kappa=\sum_{t=0}^{N-2}[-\langle J_t,q_t-q_{t+1}\rangle]_+.
\]
Then
\[
G_N(w)\le\sum_{t<N}\frac{\varepsilon_t}{\theta_t}+\kappa_0R+M_N^\kappa. \tag{3.5}
\]

**Proof.** Core containment for each \(\theta_t\) implies containment for their minimum. For (3.5), sum the anchored comparisons and apply the weighted version of (3.3). Abel summation gives
\[
\sum_{t<N}\kappa_tg_t(w)=\kappa_{N-1}G_N(w)+\sum_{t<N-1}(\kappa_t-\kappa_{t+1})G_{t+1}(w)\ge-\kappa_0R,
\]
because \(\kappa_t\) is nonincreasing. Convex average at \(q_{N-1}\), cap adverse movements by \(M_N^\kappa\), and substitute. \(\square\)

Oscillating core strengths make Abel coefficients negative; the clean weighted form then needs a weighted risk premise or the prefix-minimum reduction.

**Local movement-liability minimality.** {#C-MOVE-MIN} **Status: PROVED+MACHINE-CHECKED.** Among nonnegative increments \(\ell_t\) that certify one movement locally with no prior slack or future netting by \(\langle H_t,q_t-q_{t+1}\rangle+\ell_t\ge0\), the least is \([-\langle H_t,q_t-q_{t+1}\rangle]_+\).

**Proof.** If the scalar is nonnegative, zero is least. If negative, rearrangement requires at least its negation. \(\square\)

This is not global minimality: movements \(-1,+1\) net to zero at a fixed terminal horizon but have positive-part sum one.

**Static aggregation of movement liabilities.** {#C-MOVE-AGG} **Status: PROVED+INDEPENDENTLY-REDERIVED.** With fixed holdings \(H\),
\[
\sum_j[-\langle H,\Delta q_j\rangle]_+\ge[-\langle H,\sum_j\Delta q_j\rangle]_+,
\]
with equality exactly when the scalar movements do not include both a positive and a negative term.

**Proof.** This is subadditivity of positive part, iterated. Equality for two terms fails exactly when opposite strict signs permit cancellation; induction gives the finite condition. \(\square\)

Changing holdings between moves invalidates order independence: the exact retained instance has liability \(7/40\) in one order and \(1/10\) in the reverse order.

**Moving-region gain obstruction.** {#C-MOVE-OBS} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Suppose a binary coordinate must visit a low interval \(L_n\) and then a high interval \(U_n\), with \(\inf U_n-\sup L_n\ge g_n>0\). Buying one unit in \(L_n\) and selling it in \(U_n\) has inventory in \(\{0,1\}\), risk at most one, and completed gain at least \(g_n\). If \(\sum_ng_n=\infty\), every conforming selector is exploited.

**Proof.** Settlement terms cancel over each completed buy-sell cycle, leaving sale price minus purchase price. While open, a binary claim loses at most one. Sum the cycle gains. \(\square\)

Repeated \([0,1/3]\) and \([2/3,1]\) shows positive width is insufficient. The convergent intervals \([1/2-2/n,1/2-1/n]\), \([1/2+1/n,1/2+2/n]\) yield a divergent harmonic lower bound. Bounded total variation is not refuted.

## 3. Representation and moving-correspondence boundaries

**Provenance irreducibility.** {#C-PROV-IRR} **Status: PROVED+INDEPENDENTLY-REDERIVED.** There exist histories with identical active payoff cones and permitted regions but different legitimate repairs because challenges cite different dependency identifiers. Hence a repair transition cannot in general factor through current payoff geometry.

**Proof.** Take two endorsements with equal coefficient vectors but distinct dependency identifiers. Challenge only the first identifier in one history and only the second in another. The current geometry is equal, while dependency-preserving removal targets different endorsements. Any geometry-only function returns one output on both and is wrong on at least one. \(\square\)

**Shared-scalar impossibility.** {#C-SCALAR-NOGO} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Under a faithful positive price functional, a nonzero challenge reward cannot be both ordinary self-financing wealth and nonnegative in every world. World-independent minted rewards are either cumulatively unbounded, giving a trivial all-world gain, or bounded, changing ordinary wealth only by a bounded perturbation.

**Proof.** A self-financing payoff has zero expectation under the positive pricing measure. A nonnegative payoff with positive value somewhere has positive expectation, contradiction. A constant minted cumulative reward is itself the all-world payoff; its bounded/unbounded dichotomy gives the second statement. \(\square\)

**Separated-service crossing theorem.** {#C-SEPARATED} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If service liveness forces infinitely many completed crossings between two traded-value regions separated by a fixed gap, a bounded-inventory buy-low/sell-high strategy has risk at most one and unbounded gain.

**Proof.** This is the moving-region obstruction with a constant positive \(g_n\). A causal finite-state policy can choose the next full-support region after each action while leaving the zero-action trace cyclic, so causal endogenous selection does not remove the witness. \(\square\)

**Stationary service decomposition.** {#C-STATIONARY-SERVICE} **Status: PROVED-CONDITIONAL (conditions listed).** Suppose a finite continuous price-dependent service menu has prices converging to a full-support \(p^*\) and its queues are rate stable. Then a limiting branch-frequency mixture at \(p^*\) supplies at least the arrival vector. If rational or effectively approximable, a periodic constant-price scheduler supplies the same service and is safe for finite-state self-financing traders.

**Proof.** Take a convergent subsequence of empirical branch frequencies in the compact simplex. Queue rate stability says cumulative service minus arrivals has nonnegative limiting rate; continuity moves service values to \(p^*\). Approximate the finite mixture rationally and repeat a common-denominator date. At a fixed full-support coherent price, the self-financing separation theorem bounds every world payoff. \(\square\)

**Collateralized migration theorem.** {#C-MIGRATION} **Status: PROVED+INDEPENDENTLY-REDERIVED.** For effectively selectable portfolios \(Y_n\), computable stakes \(a_n\ge0\), and worst-case collateral \(c_n\), if \(\sum_na_nc_n<\infty\) while
\[
\sup_{v\in\Omega_N}\sum_{n\le N}a_nY_n(v)
\]
is unbounded, the resulting computable trader satisfies the standard moving-world exploitation criterion.

**Proof.** Separate collateral caps total risk by the convergent series. The displayed supremum gives unbounded plausible upside, with the maximizing world allowed to vary by horizon. Computability follows from the effective selector and stakes. \(\square\)

Nonempty convex computable correspondences remain insufficient even with coordinate convergence, projective coherence, pointwise full support, relative interior, or nesting: forced shrinking mutually exclusive tickets supply the migration hypotheses. A fixed-world criterion is strictly weaker because no single world need realize unbounded gain.

## 4. Conditional moving-correspondence cap

**Positive moving-correspondence interface.** {#C-MOVING-INTERFACE} **Status: PROVED-CONDITIONAL (conditions listed).** Fix a computable deductive process. Suppose each date publishes before demand a rational compact convex cylinder \(\mathcal C_t\); computes a rational witnessed \(q_t\in\mathcal P_t\) and fixed \(\theta>0\) with \(q_t+\theta(\mathcal P_t-q_t)\subseteq\mathcal C_t\); coherently extends its retained world mixture to fresh queried sentences; caps \(|\langle H_t,q_t-q_{t+1}\rangle|\le m_t\) with \(\sum m_t=\overline M<\infty\); computes a constrained quote with errors summing to \(\overline\varepsilon<\infty\); preserves the rational prefix-causal clock and aggregate risk \(-2\); and uses an aggregate trading field with the declared dominance property that exploitation by any enumerated ordinary computable component makes aggregate plausible wealth unbounded. Then
\[
G_N(v)\le\frac{\overline\varepsilon}{\theta}+\frac{1-\theta}{\theta}(2+\overline M)
\]
for all plausible \(v\) and horizons. The inherited lower bound remains \(-2\), so ordinary computable traders do not exploit.

**Proof.** The core comparison gives the anchored one-step inequality. Zero-padding and coherent witness extension permit the finite-algebra summation identity. Convex averaging of the retained global-world mixture gives terminal reference gain at least \(-2\). Absolute movement caps dominate adverse movement, and summable errors give the displayed cap. The stated dominance property transfers the aggregate cap to every enumerated ordinary computable component. \(\square\)

The statement is conditional because the recursive constrained history, effective witness-extension compiler, clock proof, and constrained solver integration are not formalized by the corpus. Arbitrary correspondences fail by the preceding migration theorem.
