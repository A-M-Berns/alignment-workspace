# Deviations and source findings

1. **Historical operative-force proof error, repaired upstream and retained here.** The original summation-by-parts display used terminal reference `q_N` while accounting for movements only through `N-2`. The independent audit showed it false at `N=1`. The authoritative repaired theorem, and this consolidation, use `q_(N-1)`. The theorem's numerical cap is unchanged.
2. **General record invariance is equivariant, not literal.** Phase XI correctly refuted the requested claim for every raw record-computable functional. This consolidation states only orbit-quotient/equivariant invariance and preserves the literal-name counterexample.
3. **Delay closure is not necessary for peak equality.** The exact hypothesis is peak synchronization. The stronger preregistered necessity claim is not retained.
4. **The certified slack transfer cap is not the unconditional transfer classification.** Funding-decision separability is exact; the numerical cap is fixed-horizon and directional.
5. **The full charge-incentive impossibility is not a theorem of the frozen model.** Formal queue universality survives zero repair payment. Only the positive-charge identity and an explicitly behavioral conditional theorem are retained; the mechanism question is open.
6. **The coarse endowment ratio has no universal constant cap.** Unreachable keys make it arbitrarily loose, and the quadratic latency law needs saturation. No attempted reconciliation appears here.
7. **Conditional moving-correspondence construction remains conditional.** The finite-algebra witness-extension compiler, recursive constrained history, clock integration, and constrained solver are not formalized. The wealth implication is proved; a complete Logical Induction construction is not.
8. **Tier B vendors the relevant witness suites, not the entire 790-test implementation harness.** Standalone exact-rational modules are byte-identical and their mathematical tests run locally. Six old repository-layout, old-ledger, and upstream-checksum assertions are skipped and replaced by the consolidation's manifest and claim/status audits. Broader implementation regressions lie outside the theorem dependency closure.
9. **Lean formalization is theorem-mechanism rather than system-level.** New proofs isolate the subtle algebra but do not encode the whole flow transition system. Ledger machine-checked labels are limited to what the compiled statements actually cover, paired with hand proofs for the canonical system statement.

10. **Standardization changes names, not mathematics.** The pre-pass tree is
    archived byte-for-byte with a manifest. Pure substitutions pass the inverse
    rename check; contextual readings are enumerated in `AMBIGUITIES.md`.
    Stable IDs, theorem hypotheses, witnesses, rational values, and proof steps
    are unchanged.
11. **The cited Phase IX/X proposal files were absent from the supplied trees.**
    The six adopted author decisions are therefore applied to the retained
    monograph, glossary, catalogue, and decision ledger; no absent proposal file
    was fabricated.

The pre-standardization source was not overwritten: it remains in
`archive/pre_standardization/`. No new mathematical generalization beyond the
Phase XI frontier was introduced.
