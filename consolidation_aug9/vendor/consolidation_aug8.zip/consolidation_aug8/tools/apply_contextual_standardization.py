#!/usr/bin/env python3
"""Apply the reviewed, semantics-preserving part of the Aug. 8 name migration.

Unlike apply_standardization.py, this pass is deliberately phrase based.  Every
edited file is marked contextual in rename_manifest.json and is enumerated in
AMBIGUITIES.md; it is therefore outside the pure-token round-trip claim.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOTS = (
    Path("/Users/anson/Desktop/consolidation_aug8"),
    Path("/Users/anson/Desktop/normative-learner"),
)
EXTS = {".md", ".py", ".lean"}

# Ordered longest/specific first.  These are readings, not mathematical edits.
LITERAL = [
    ("\\\\theta", "\\theta"),
    ("post-trade cumulative exposure", "post-trade holdings"),
    ("post-trade exposure", "post-trade holdings"),
    ("exposure-weighted reference movement", "holdings-weighted reference movement"),
    ("exposure-weighted movement", "holdings-weighted movement"),
    ("exposure-dependent movement", "holdings-dependent movement"),
    ("exposure-dependent activation", "holdings-dependent activation"),
    ("zero-new-exposure", "zero-new-holdings"),
    ("zero new exposure", "zero new holdings"),
    ("market exposure", "market holdings"),
    ("force exposure", "force holdings"),
    ("force_exposures", "force_holdings"),
    ("exposure_map", "holdings_map"),
    ("exposure changed", "holdings changed"),
    ("exposure must be identical", "holdings must be identical"),
    ("exposure through", "holdings through"),
    ("at every exposure", "at every holdings vector"),
    ("movement charge", "movement liability"),
    ("movement charges", "movement liabilities"),
    ("reference-movement charge", "reference-movement liability"),
    ("adverse reference-movement charge", "adverse reference-movement liability"),
    ("compilerShock", "compilerJump"),
    ("constantRent", "constantCharge"),
    ("downside floor", "risk"),
    ("worldwise payoff floor", "worldwise risk limit"),
    ("funding floor", "funding minimum"),
    ("wealth bound", "wealth cap"),
    ("wealth bounds", "wealth caps"),
    ("movement bound", "movement cap"),
    ("movement bounds", "movement caps"),
    ("uniform bound", "uniform cap"),
    ("uniform bounds", "uniform caps"),
    ("coarse bound", "coarse cap"),
    ("coarse bounds", "coarse caps"),
    ("upper bound", "upper cap"),
    ("upper bounds", "upper caps"),
    ("bounded operative force", "capped operative force"),
    ("operative-force bound", "operative-force cap"),
    ("operative-force bounds", "operative-force caps"),
    ("fixed-core OF bound", "fixed-core OF cap"),
    ("checked-answer", "checked-response"),
    ("checked answer", "checked response"),
    ("checked answers", "checked responses"),
    ("canonical-answer", "canonical-response"),
    ("canonical answer", "canonical response"),
    ("canonical answers", "canonical responses"),
    ("answer-only", "respond-only"),
    ("answer_cost", "reply_cost"),
    ("answer cost", "reply cost"),
    ("response type", "reply type"),
    ("nested warranted floors", "nested warranted bounds"),
    ("false floor", "false bound"),
    ("false floors", "false bounds"),
    ("exposed floor", "exposed bound"),
    ("exposed floors", "exposed bounds"),
    ("consistent floor", "consistent bound"),
    ("consistent floors", "consistent bounds"),
    ("unexposed floor", "unexposed bound"),
    ("unexposed floors", "unexposed bounds"),
    ("active floor", "active bound"),
    ("active floors", "active bounds"),
    ("per-floor", "per-bound"),
    ("floor chain", "bound chain"),
    ("floor inequalities", "bound inequalities"),
    ("floor inequality", "bound inequality"),
    ("floor constraint", "bound constraint"),
    ("floor constraints", "bound constraints"),
    ("floor witness", "bound witness"),
    ("floor witnesses", "bound witnesses"),
    ("floor semantics", "bound semantics"),
    ("floor event", "bound event"),
    ("floor count", "bound count"),
    ("floor instance", "bound instance"),
    ("floor path", "bound path"),
    ("floor loss", "bound loss"),
    ("floor field", "bound field"),
    ("floor threshold", "bound threshold"),
    ("floor test", "bound test"),
    ("floor value", "bound value"),
    ("floor formula", "integer-floor formula"),
    ("floor equality", "integer-floor equality"),
]

BOOK_ROW_PATTERNS = [
    (r"\b(active|warrant|nonlogical|reason|false|removed|source|compiled|target|new|old|equal|affine|book|constraint) rows\b", r"\1 endorsements"),
    (r"\b(active|warrant|nonlogical|reason|false|removed|source|compiled|target|new|old|equal|affine|book|constraint) row\b", r"\1 endorsement"),
    (r"\brow occurrence(s?)\b", r"endorsement occurrence\1"),
    (r"\brow identifier(s?)\b", r"endorsement identifier\1"),
    (r"\brow ID(s?)\b", r"endorsement ID\1"),
]

def contextual_code(text: str) -> str:
    # Code-level domain fields.  Matrix loop variables named row are untouched.
    reps = [
        ("CompilerRow", "CompilerEndorsement"),
        ("compiler.rows", "compiler.endorsements"),
        ("rows: tuple[CompilerEndorsement", "endorsements: tuple[CompilerEndorsement"),
        ("rows: Tuple[CompilerEndorsement", "endorsements: Tuple[CompilerEndorsement"),
        ("self.rows", "self.endorsements"),
        ("old_position.exposure", "old_position.holdings"),
        ("new_position.exposure", "new_position.holdings"),
        ("retained_exposure", "retained_holdings"),
        ("exposure: Q", "holdings: Q"),
        ("exposure: Fraction", "holdings: Fraction"),
        ("exposure, old_reference", "holdings, old_reference"),
        ("-exposure *", "-holdings *"),
        ("exposure !=", "holdings !="),
        ("exposure ==", "holdings =="),
        ("exposure_map", "holdings_map"),
        ("exposure = Q(old_state.force_holdings", "holdings = Q(old_state.force_holdings"),
        ("-exposure * (q_old", "-holdings * (q_old"),
        ("new_coordinate, exposure,", "new_coordinate, holdings,"),
        (".floor", ".bound"),
        ("floor: Fraction", "bound: Fraction"),
        ("floor=Fraction", "bound=Fraction"),
        ("for index, floor in", "for index, bound in"),
        ("if floor >", "if bound >"),
        ("floor > frequency", "bound > frequency"),
        ("mean < floor", "mean < bound"),
        ("stake: Fraction, floor:", "stake: Fraction, bound:"),
        ('"B_R"', '"Psi0"'),
        ("DK[\"B_R\"]", "DK[\"Psi0\"]"),
        ("b_r:", "psi0:"),
        ("b_r,", "psi0,"),
        (" b_r ", " psi0 "),
        ("r_K", "c_K"),
        ("R_K", "C_K"),
    ]
    for a, b in reps:
        text = text.replace(a, b)
    return text

def edit(path: Path) -> bool:
    text = path.read_text()
    old = text
    for a, b in LITERAL:
        text = text.replace(a, b)
    for pat, repl in BOOK_ROW_PATTERNS:
        text = re.sub(pat, repl, text, flags=re.I)
    if path.suffix in {".py", ".lean"}:
        text = contextual_code(text)
    # Remaining ordinary uses of floor in prose denote book bounds, except the
    # explicit mathematical integer-floor vocabulary.
    if path.suffix == ".md" and path.name not in {"GLOSSARY.md", "AMBIGUITIES.md", "ID_EXPANSIONS.md"}:
        lines = []
        for line in text.splitlines(keepends=True):
            if re.search(r"rational-floor|integer-floor|Mathlib\.Data\.Rat\.Floor|\\lfloor|⌊", line, re.I):
                lines.append(line)
            else:
                lines.append(re.sub(r"\bfloors\b", "bounds", re.sub(r"\bfloor\b", "bound", line, flags=re.I), flags=re.I))
        text = "".join(lines)
    if text != old:
        path.write_text(text)
        return True
    return False

def main() -> None:
    changed = []
    for root in ROOTS:
        for path in sorted(root.rglob("*")):
            if not path.is_file() or path.suffix not in EXTS or "archive" in path.parts:
                continue
            if path.name in {"apply_standardization.py", "apply_contextual_standardization.py"}:
                continue
            if edit(path):
                changed.append(f"{root.name}/{path.relative_to(root)}")
        manifest = root / "tools" / "rename_manifest.json"
        if manifest.exists():
            data = json.loads(manifest.read_text())
            changed_here = {x.split("/", 1)[1] for x in changed if x.startswith(root.name + "/")}
            files = data.get("files", {})
            for key, item in files.items():
                rel = key.split("/", 1)[1] if "/" in key else key
                if rel in changed_here:
                    item["pure"] = False
                    item["contextual_reason"] = "reviewed context-sensitive vocabulary/notation pass"
            manifest.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
    print(f"contextually edited {len(changed)} files")

if __name__ == "__main__":
    main()
