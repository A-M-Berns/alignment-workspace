#!/usr/bin/env python3
"""Freeze the final inverse edit script for code-only pure substitutions.

The pre-standardization archive is authoritative.  Source, test, and Lean files
other than the portable runners are eligible only when their line structure is
unchanged; each changed line is then recorded as an exact old/new substitution.
The verifier consumes this fixed record and never regenerates it.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
MANIFEST = ROOT / "tools" / "rename_manifest.json"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


data = json.loads(MANIFEST.read_text())
final_pure: dict[str, object] = {}
for label, value in data["roots"].items():
    root = Path(value)
    archive = root / "archive" / "pre_standardization"
    for original in sorted(archive.rglob("*")):
        if not original.is_file() or original.suffix not in {".py", ".lean"}:
            continue
        relative = original.relative_to(archive)
        if relative.as_posix() == "tests/run.py":
            continue
        current = root / relative
        if not current.is_file():
            raise SystemExit(f"missing live counterpart: {label}/{relative}")
        old_lines = original.read_text().splitlines(keepends=True)
        new_lines = current.read_text().splitlines(keepends=True)
        if len(old_lines) != len(new_lines):
            raise SystemExit(f"non-substitutional line-count change: {label}/{relative}")
        operations: list[dict[str, object]] = []
        offset = 0
        for old, new in zip(old_lines, new_lines):
            if old != new:
                operations.append({"post_start": offset, "old": old, "new": new})
            offset += len(new)
        if operations:
            final_pure[f"{label}/{relative.as_posix()}"] = {
                "pre_sha256": sha(original.read_bytes()),
                "final_sha256": sha(current.read_bytes()),
                "operations": operations,
            }

data["final_pure_files"] = final_pure
MANIFEST.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
print(f"recorded final inverse substitutions for {len(final_pure)} code/Lean files")
