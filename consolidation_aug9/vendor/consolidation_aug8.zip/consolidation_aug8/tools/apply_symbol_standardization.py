#!/usr/bin/env python3
"""Reviewed symbol renames whose scope is fixed by file/semantic family."""
from pathlib import Path

CONS = Path("/Users/anson/Desktop/consolidation_aug8")
NORM = Path("/Users/anson/Desktop/normative-learner")

def apply(path: Path, pairs: list[tuple[str, str]]) -> None:
    text = path.read_text()
    old = text
    for source, target in pairs:
        text = text.replace(source, target)
    if text != old:
        path.write_text(text)

# Challenge-mechanism notation; κ here was reply cost, not the OF odds factor.
for name in ("THEORY_5_CHALLENGE_SEMANTICS.md", "THEORY_6_PARAMETERIZED_ANSWERABILITY.md"):
    apply(CONS / name, [
        ("B_R", "\\Psi_0"),
        ("r_K", "c_K"), ("R_K", "C_K"),
        ("r(k)", "c(k)"), ("R(k)", "C(k)"),
        ("d\\kappa", "d\\zeta"),
        ("canonical answer", "canonical response"),
        ("canonical answers", "canonical responses"),
        ("checked answer", "checked response"),
        ("checked answers", "checked responses"),
        ("answer, authorized revision, or suspension", "respond, repair, or suspend"),
        ("answer, weaken, or suspend", "respond, repair, or suspend"),
        ("answer or consuming route", "respond or consuming route"),
        ("answer or repair", "respond or repair"),
        ("unanswered", "unresponded-to"),
    ])

# Documentation and ledgers use the same potential and charge notation.
for root in (CONS, NORM):
    for path in root.rglob("*.md"):
        if "archive" in path.parts or path.name in {"GLOSSARY.md", "AMBIGUITIES.md", "ID_EXPANSIONS.md"}:
            continue
        apply(path, [
            ("`B_R`", "`Psi0`"), ("B_R", "\\Psi_0"),
            ("r_K", "c_K"), ("R_K", "C_K"),
            ("E_N", "\\varepsilon_{1:N}"), ("D_N", "M_N"),
        ])

if __name__ == "__main__":
    print("symbol standardization applied")
