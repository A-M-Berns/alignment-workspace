#!/usr/bin/env python3
"""Mechanical domain-identifier renames shared by source and tests."""
from pathlib import Path

roots = (Path("/Users/anson/Desktop/consolidation_aug8"), Path("/Users/anson/Desktop/normative-learner"))
pairs = [
    ("FalseFloor", "FalseBound"),
    ("false_floor", "false_bound"),
    ("floor_is_false", "bound_is_false"),
    ("max_floor", "max_bound"),
    ("accrual_floor", "accrual_bound"),
    ("periods_open", "dates_open"),
    ("periods", "dates"),
    ("rounds", "dates"),
    ("per_round", "per_date"),
    ("floor_false", "bound_false"),
    ("floor_address_is_valid", "bound_address_is_valid"),
    ("old_floor", "old_bound"),
    ("new_floor", "new_bound"),
    ("floor_drop", "bound_drop"),
    ("movement_charge", "movement_liability"),
    ("compiler_shocks", "reference_jumps"),
    ("compiler_shock", "reference_jump"),
    ("jump_step_bound", "jump_step_cap"),
    ("downside", "risk"),
    ("terminal_coverage", "eventual_route_coverage"),
    ("total_recurrent_complaint_sequence_revenue_bound", "total_recurrent_complaint_sequence_revenue_cap"),
    ("recurrent_complaint_sequence_bound", "recurrent_complaint_sequence_cap"),
    ("construction_outflow_bound", "construction_outflow_cap"),
    ("consumption_status_change_bound", "consumption_status_change_cap"),
    ("operational_lock_bound", "operational_lock_cap"),
    ("procedure_lock_bound", "procedure_lock_cap"),
    ("world_lock_bound", "world_lock_cap"),
    ("actual_total_lock_bound", "actual_total_lock_cap"),
    ("dovetail_bound", "dovetail_cap"),
    ("loose_key_bound", "loose_key_cap"),
    ("uniform_bound", "uniform_cap"),
]
for root in roots:
    for parent in (root / "src", root / "tests"):
        if not parent.exists():
            continue
        for path in parent.glob("*.py"):
            text = path.read_text()
            for old, new in pairs:
                text = text.replace(old, new)
            path.write_text(text)
print("code identifiers standardized")
