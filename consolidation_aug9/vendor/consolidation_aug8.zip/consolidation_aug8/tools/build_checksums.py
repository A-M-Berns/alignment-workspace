#!/usr/bin/env python3
"""Regenerate pre/post rename manifests and downstream input pins."""
from __future__ import annotations

import hashlib
import json
from datetime import date
from pathlib import Path

CONS = Path("/Users/anson/Desktop/consolidation_aug8")
NORM = Path("/Users/anson/Desktop/normative-learner")
IGNORE_NAMES = {".DS_Store", "FROZEN_INPUT_CHECKSUMS.json", "CHECKSUMS_PRE_POST.md"}

def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def files(base: Path, *, live: bool) -> dict[str, str]:
    result = {}
    for path in sorted(base.rglob("*")):
        if not path.is_file() or path.name in IGNORE_NAMES or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        if live and "archive" in path.parts:
            continue
        if not live and path.name == "MANIFEST.json":
            continue
        result[path.relative_to(base).as_posix()] = digest(path)
    return result

def retained_consolidation_files() -> dict[str, str]:
    result = {}
    for path in sorted(CONS.rglob("*")):
        if not path.is_file() or "archive" in path.parts or "tools" in path.parts or "__pycache__" in path.parts:
            continue
        if path.name in IGNORE_NAMES or path.suffix == ".pyc":
            continue
        if path.suffix not in {".md", ".py", ".lean"}:
            continue
        result[path.relative_to(CONS).as_posix()] = digest(path)
    return result

pre_post: dict[str, tuple[dict[str, str], dict[str, str]]] = {}
for root in (CONS, NORM):
    archive = root / "archive" / "pre_standardization"
    pre = files(archive, live=False)
    post = files(root, live=True)
    pre_post[root.name] = (pre, post)
    archive_manifest = {
        "algorithm": "sha256",
        "purpose": "byte-exact pre-standardization archive",
        "restore_target": str(root),
        "files": pre,
    }
    (archive / "MANIFEST.json").write_text(json.dumps(archive_manifest, indent=2, sort_keys=True) + "\n")

old_manifest = json.loads((CONS / "archive" / "pre_standardization" / "FROZEN_INPUT_CHECKSUMS.json").read_text())
cons_data = {
    "algorithm": "sha256",
    "generated": str(date.today()),
    "upstream_pre_consolidation_files": old_manifest.get("files", {}),
    "pre_rename_files": pre_post[CONS.name][0],
    "post_rename_files": pre_post[CONS.name][1],
    "self_exclusions": sorted(IGNORE_NAMES),
}
(CONS / "FROZEN_INPUT_CHECKSUMS.json").write_text(json.dumps(cons_data, indent=2, sort_keys=True) + "\n")

norm_data = {
    "algorithm": "sha256",
    "generated": str(date.today()),
    "authority": "../consolidation_aug8",
    "consolidation_files": retained_consolidation_files(),
    "pre_rename_files": pre_post[NORM.name][0],
    "post_rename_files": pre_post[NORM.name][1],
    "self_exclusions": sorted(IGNORE_NAMES),
}
(NORM / "FROZEN_INPUT_CHECKSUMS.json").write_text(json.dumps(norm_data, indent=2, sort_keys=True) + "\n")

lines = [
    "# Pre- and post-standardization SHA-256 table\n",
    "Hashes cover every archived and live file except the checksum artifacts themselves, `.DS_Store`, bytecode, and archive manifests. `(absent)` records a file present on only one side.\n",
    "| Tree | Relative path | Pre-rename SHA-256 | Post-rename SHA-256 |\n",
    "|---|---|---|---|\n",
]
for tree, (pre, post) in pre_post.items():
    for relative in sorted(set(pre) | set(post)):
        lines.append(f"| `{tree}` | `{relative}` | `{pre.get(relative, '(absent)')}` | `{post.get(relative, '(absent)')}` |\n")
(CONS / "CHECKSUMS_PRE_POST.md").write_text("".join(lines))
print(f"checksummed {sum(len(p)+len(q) for p,q in pre_post.values())} pre/post file entries")
