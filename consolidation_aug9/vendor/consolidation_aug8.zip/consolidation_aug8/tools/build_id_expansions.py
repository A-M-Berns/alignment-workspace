#!/usr/bin/env python3
"""Generate old/new claim-ID expansions without changing stable identifiers."""
from __future__ import annotations

import re
from pathlib import Path

ROOTS = (
    Path("/Users/anson/Desktop/consolidation_aug8"),
    Path("/Users/anson/Desktop/normative-learner"),
)
ID = re.compile(r"\b(?:C|NL|AM)-[A-Z0-9-]+\b")

def clean(value: str) -> str:
    value = re.sub(r"^#+\s*", "", value.strip())
    value = value.replace("**", "").strip()
    return value.replace("|", "\\|").replace("`", "'")

def expansions(base: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    for path in sorted(base.rglob("*.md")):
        if path.name in {"AMBIGUITIES.md", "ID_EXPANSIONS.md", "GLOSSARY.md", "REPORT.md"}:
            continue
        for line in path.read_text(errors="ignore").splitlines():
            marker = re.search(r"\{#((?:C|NL|AM)-[A-Z0-9-]+)\}", line)
            if marker:
                before = line[:marker.start()]
                title = clean(before)
                if title:
                    result.setdefault(marker.group(1), title)
            if line.startswith("|"):
                cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
                if cells:
                    match = ID.search(cells[0])
                    if match:
                        expansion = clean(cells[0].replace(match.group(0), "", 1))
                        if expansion:
                            result.setdefault(match.group(0), expansion)
    return result

all_rows = []
for root in ROOTS:
    old = expansions(root / "archive" / "pre_standardization")
    new = expansions(root)
    identifiers = sorted(set(old) | set(new))
    for claim in identifiers:
        all_rows.append((claim, old.get(claim, "(identifier only)"), new.get(claim, "(identifier only)"), root.name))

out = Path("/Users/anson/Desktop/consolidation_aug8/ID_EXPANSIONS.md")
lines = [
    "# Stable identifier expansions\n",
    "Stable identifiers are frozen. This table records the pre-pass and canonical expansions; unchanged expansions are listed too so the map is exhaustive.\n",
    "| ID | Old expansion | New expansion | Source tree |\n",
    "|---|---|---|---|\n",
]
for claim, old, new, tree in sorted(all_rows):
    lines.append(f"| `{claim}` | {old} | {new} | `{tree}` |\n")
out.write_text("".join(lines))
print(f"wrote {len(all_rows)} ID expansion rows")
