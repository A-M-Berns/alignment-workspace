#!/usr/bin/env python3
"""Render the retained pre/post test-output diff for the standardization pass."""
from __future__ import annotations

import difflib
from pathlib import Path

PAIRS = (
    ("consolidation_aug8", Path("/tmp/consolidation_before.out"), Path("/tmp/consolidation_after.out")),
    ("normative-learner", Path("/tmp/normative_before.out"), Path("/tmp/normative_after.out")),
)
OUT = Path("/Users/anson/Desktop/consolidation_aug8/TEST_OUTPUT_DIFF.md")


def normalized(lines: list[str]) -> list[str]:
    """Remove only elapsed-run variation, leaving every semantic output line."""
    substitutions = {
        "Ran 140 tests in 0.014s": "Ran 140 tests in <elapsed>",
        "Ran 140 tests in 0.013s": "Ran 140 tests in <elapsed>",
        "Ran 29 tests in 0.241s": "Ran 29 tests in <elapsed>",
        "Ran 29 tests in 0.239s": "Ran 29 tests in <elapsed>",
        "Ran 29 tests in 0.240s": "Ran 29 tests in <elapsed>",
    }
    return [substitutions.get(line.rstrip("\n"), line.rstrip("\n")) + "\n" for line in lines]


sections: list[str] = [
    "# Test-output diff\n\n",
    "This is the exact unified comparison of the baseline and final portable-runner outputs, except that nondeterministic elapsed durations are normalized to <elapsed>. The only semantic output changes are the newly required audit prelude, canonical identifiers/vocabulary, the adopted per-provenance schedule labels, and the explicit Lean status line. No displayed exact-rational value changed.\n\n",
]
for label, before, after in PAIRS:
    if not before.exists() or not after.exists():
        raise SystemExit(f"missing captured output for {label}: {before} or {after}")
    diff = difflib.unified_diff(
        normalized(before.read_text().splitlines(keepends=True)),
        normalized(after.read_text().splitlines(keepends=True)),
        fromfile=str(before),
        tofile=str(after),
    )
    sections.append(f"## {label}\n\n~~~diff\n")
    sections.extend(diff)
    sections.append("~~~\n\n")
OUT.write_text("".join(sections))
print(f"wrote {OUT}")
