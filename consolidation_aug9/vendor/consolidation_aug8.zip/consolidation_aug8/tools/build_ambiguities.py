#!/usr/bin/env python3
"""Build the reviewed occurrence ledger for context-sensitive readings."""
from __future__ import annotations

import re
from pathlib import Path

ROOTS = (
    Path("/Users/anson/Desktop/consolidation_aug8"),
    Path("/Users/anson/Desktop/normative-learner"),
)

TOKENS = {
    "floor": re.compile(r"\bfloor(?:s)?\b", re.I),
    "bound": re.compile(r"\bbound(?:s|ed|ing)?\b", re.I),
    "exposure": re.compile(r"\bexpos(?:ure|ures|ed)\b", re.I),
    "rent/charge": re.compile(r"\b(?:rent|rents|charge|charges|charged|charging)\b", re.I),
    "answer": re.compile(r"\banswer(?:s|ed|ing|able)?\b", re.I),
    "row": re.compile(r"\brow(?:s)?\b", re.I),
    "kappa": re.compile(r"(?:\\kappa|\bkappa\b|κ)"),
    "alpha/a_t": re.compile(r"(?:\\alpha|\balpha\b|α|\ba_t\b)"),
    "slack": re.compile(r"\bslack\b", re.I),
}

def classify(kind: str, line: str, path: Path) -> tuple[str, str]:
    low = line.lower()
    if kind == "floor":
        if any(x in line for x in ("Nat.floor", "math.floor", "Mathlib.Data.Rat.Floor", "\\lfloor", "⌊")) or "rational-floor" in low:
            return "integer-floor operation", "unchanged mathematical floor"
        if "downside floor" in low or "payoff floor" in low:
            return "market risk limit", "risk / R"
        if "funding floor" in low:
            return "minimum required funding", "minimum"
        if any(x in low for x in ("row", "book", "active floor", "removed floor", "floor occurrence")):
            return "book object", "endorsement"
        return "numeric content asserted by an endorsement", "bound"
    if kind == "bound":
        if any(x in low for x in ("lower bound", "lower-bound", "at least", "minimum", "f_min", "p_min", "w_min", "stake-margin")):
            return "proved lower requirement or minimum", "bound/minimum unchanged"
        if any(x in low for x in ("upper", "wealth", "movement", "uniform", "coarse", "loose", "finite bound", "boundedness", "without bound")):
            return "proved ceiling", "cap"
        return "generic mathematical inequality", "bound retained unless a displayed ceiling"
    if kind == "exposure":
        if any(x in low for x in ("h_t", "position", "portfolio", "market", "nonzero-exposure", "exposure-weighted", "zero new", "force_exposure")):
            return "market quantity", "holdings"
        return "epistemic/empirical exposure", "exposure retained"
    if kind == "rent/charge":
        if "movement" in low or "reference" in low and "charge" in low:
            return "analytic movement proof accounting", "liability"
        if "service charge" in low or "charge its declared procedure cost" in low:
            return "service-cost verb", "charge retained as an ordinary verb"
        return "literal per-date account transfer", "charge; cumulative plural charges"
    if kind == "answer":
        if any(x in low for x in ("answerability", "answerable learner", "terminal learning", "umbrella")):
            return "umbrella answering/answerability", "answering retained"
        if any(x in low for x in ("or repair", "or revision", "or suspension", "canonical answer", "checked answer", "answer-only", "no answer")):
            return "no-active-endorsement-change disposition", "respond/response"
        return "ordinary or umbrella prose", "retained where not a disposition constructor"
    if kind == "row":
        if path.name == "exact.py":
            return "matrix/table row", "row retained"
        if any(x in low for x in ("compilerrow", "compiler.rows", "row.source", "row.coefficients", "row.rhs", "active row", "compiled row", "row occurrence")):
            return "book/compiler occurrence", "endorsement"
        if path.name == "LEDGER.md" or "ledger row" in low:
            return "ledger row", "row retained"
        if any(x in low for x in ("matrix", "table row", "ledger row", "for row", "row in", "rows =", "row[:]", "row[a]")):
            return "matrix/table/ledger row", "row retained"
        return "book/compiler occurrence", "endorsement"
    if kind == "kappa":
        if any(x in str(path).lower() for x in ("theory_5", "theory_6", "vendored_x", "exact.py")) or any(x in low for x in ("response-cost", "answerable at cost", "b(b_r+1)d")):
            return "finite-construction reply cost", "zeta / ζ"
        return "operative-force odds factor", "kappa / κ retained"
    if kind == "alpha/a_t":
        if "a_t" in line and any(x in low for x in ("arriv", "workload", "queue")):
            return "service arrival", "u_t"
        if any(x in low for x in ("type*", "schema", "rightsquigarrow")):
            return "type/warrant metavariable", "tau or phi"
        return "core coefficient", "theta / θ"
    if kind == "slack":
        if any(x in low for x in ("e_", "epsilon", "operative-force", "of-1")):
            return "solver contribution to the OF cap", "tolerance"
        return "LP/certified/algebraic slack", "slack retained"
    raise AssertionError(kind)

def esc(text: str) -> str:
    return text.replace("|", "\\|").replace("`", "'")

rows = []
for root in ROOTS:
    archive = root / "archive" / "pre_standardization"
    for path in sorted(archive.rglob("*")):
        if not path.is_file() or path.suffix not in {".md", ".py", ".lean"}:
            continue
        rel = f"{root.name}/{path.relative_to(archive)}"
        for number, line in enumerate(path.read_text(errors="ignore").splitlines(), 1):
            for kind, pattern in TOKENS.items():
                if pattern.search(line):
                    reading, rendering = classify(kind, line, path)
                    snippet = line.strip()
                    if len(snippet) > 150:
                        snippet = snippet[:147] + "..."
                    rows.append((rel, number, kind, reading, rendering, snippet))

out = Path("/Users/anson/Desktop/consolidation_aug8/AMBIGUITIES.md")
lines = [
    "# Context-sensitive occurrence ledger\n",
    "This ledger enumerates every pre-pass source line containing a context-sensitive term reviewed in this pass. Line numbers refer to `archive/pre_standardization/`; repeated tokens on one line share the recorded reading. Pure-token files are handled separately by `tools/rename_check.py`.\n",
    "| Pre-pass file | Line | Token class | Reading assigned | Canonical rendering | Context |\n",
    "|---|---:|---|---|---|---|\n",
]
for rel, number, kind, reading, rendering, snippet in rows:
    lines.append(f"| `{esc(rel)}` | {number} | {kind} | {esc(reading)} | {esc(rendering)} | {esc(snippet)} |\n")
out.write_text("".join(lines))
print(f"wrote {len(rows)} reviewed source-line occurrences")
