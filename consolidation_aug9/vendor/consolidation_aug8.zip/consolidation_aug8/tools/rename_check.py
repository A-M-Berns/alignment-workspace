#!/usr/bin/env python3
"""Verify byte-exact invertibility of every still-pure rename target.

The mechanical manifest records post-replacement character offsets.  Files
subsequently subjected to a reviewed contextual edit are reported as contextual
and checked through AMBIGUITIES.md instead; every file whose current bytes still
equal its mechanical digest is inverted and compared byte-for-byte with the
archived pre-pass copy.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve()
CONSOLIDATION = HERE.parents[1]
MANIFEST = CONSOLIDATION / "tools" / "rename_manifest.json"

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def reverse(text: str, operations: list[dict[str, object]]) -> str:
    for operation in reversed(operations):
        start = int(operation["post_start"])
        old = str(operation["old"])
        new = str(operation["new"])
        if text[start:start + len(new)] != new:
            raise ValueError(
                f"expected canonical token {new!r} at character {start}, "
                f"found {text[start:start + len(new)]!r}"
            )
        text = text[:start] + old + text[start + len(new):]
    return text

def main() -> int:
    data = json.loads(MANIFEST.read_text())
    roots = {name: Path(value) for name, value in data["roots"].items()}
    failures: list[str] = []
    checked = 0
    final_pure = data.get("final_pure_files", {})
    checked_keys: set[str] = set()
    for key, record in sorted(final_pure.items()):
        label, relative = key.split("/", 1)
        root = roots[label]
        current_path = root / relative
        original_path = root / "archive" / "pre_standardization" / relative
        if not current_path.is_file() or not original_path.is_file():
            failures.append(f"{key}: current or archived counterpart is missing")
            continue
        current = current_path.read_bytes()
        if sha(current) != record["final_sha256"]:
            failures.append(f"{key}: current bytes differ from the frozen final rename digest")
            continue
        try:
            inverted = reverse(current.decode("utf-8"), record["operations"]).encode("utf-8")
        except Exception as exc:
            failures.append(f"{key}: final inverse application failed: {exc}")
            continue
        expected = original_path.read_bytes()
        if inverted != expected or sha(expected) != record["pre_sha256"]:
            failures.append(f"{key}: final inverse bytes differ from the archived source")
            continue
        checked += 1
        checked_keys.add(key)

    contextual_files: list[str] = []
    for key, record in sorted(data["files"].items()):
        if key in checked_keys:
            continue
        label, relative = key.split("/", 1)
        root = roots[label]
        current_path = root / relative
        original_path = root / "archive" / "pre_standardization" / relative
        if not current_path.is_file() or not original_path.is_file():
            failures.append(f"{key}: current or archived counterpart is missing")
            continue
        current = current_path.read_bytes()
        # A later contextual pass changes the mechanical digest by design.  It
        # is outside the pure-token claim and is enumerated in AMBIGUITIES.md.
        if sha(current) != record["mechanical_sha256"]:
            contextual_files.append(key)
            continue
        try:
            inverted = reverse(current.decode("utf-8"), record["operations"]).encode("utf-8")
        except Exception as exc:
            failures.append(f"{key}: inverse application failed: {exc}")
            continue
        expected = original_path.read_bytes()
        if inverted != expected:
            failures.append(
                f"{key}: inverse bytes differ "
                f"(got {sha(inverted)}, expected {sha(expected)})"
            )
            continue
        if sha(expected) != record["pre_sha256"]:
            failures.append(f"{key}: archived pre-pass digest no longer matches manifest")
            continue
        checked += 1
    for failure in failures:
        print(f"ROUNDTRIP FAIL: {failure}")
    if failures:
        print(f"RENAME CHECK FAILED: {len(failures)} failure(s), {checked} pure files passed")
        return 1
    print(f"RENAME CHECK PASSED: {checked} pure files byte-round-tripped")
    for key in contextual_files:
        print(f"CONTEXTUAL EXCLUDED: {key} (see AMBIGUITIES.md)")
    print(f"CONTEXTUAL FILES: {len(contextual_files)}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
