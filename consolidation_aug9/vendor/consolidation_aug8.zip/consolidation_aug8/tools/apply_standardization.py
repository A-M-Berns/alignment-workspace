#!/usr/bin/env python3
"""Apply the mechanical part of the 2026-08-08 terminology standardization.

Context-sensitive notation and vocabulary are deliberately left to the reviewed
pass.  Every edit made here is recorded at occurrence level so rename_check.py
can invert it byte-for-byte even when a canonical token already existed.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import re

HERE = pathlib.Path(__file__).resolve()
CONSOLIDATION = HERE.parents[1]
NORMATIVE = CONSOLIDATION.parent / "normative-learner"
MANIFEST = CONSOLIDATION / "tools" / "rename_manifest.json"
TEXT_SUFFIXES = {".md", ".py", ".lean"}


PROSE_RENAMES = (
    (r"terminally answerable-learning criterion \(placeholder\)", "answerable learner"),
    (r"flow terminal learning criterion \(descriptive placeholder[^)]*\)", "flow answerable learner"),
    (r"terminal-book coverage condition \(placeholder[^)]*\)", "eventual route coverage"),
    (r"terminal-book coverage condition", "eventual route coverage"),
    (r"covered and adequately funded repeated-complaint regime", "enforcement"),
    (r"underfunding-triggered correct-target suspension", "starvation"),
    (r"uncovered recurrent rent extraction", "extraction"),
    (r"martyrdom-by-latency", "starvation-by-latency"),
    (r"Strong Firewall Theorem", "Strong Fencing Theorem"),
    (r"ARC-iff conjecture", "route-coverage biconditional"),
    (r"reachable-book repair coverage", "reachable-book route coverage"),
    (r"every-era repair coverage", "every-era route coverage"),
    (r"authorized repair coverage", "route coverage"),
    (r"syntactic ARC", "syntactic route coverage"),
    (r"semantic ARC", "semantic route coverage"),
    (r"flow-ARC", "route coverage"),
    (r"ARC-Reach", "reachable-book route coverage"),
    (r"ARC-Era", "every-era route coverage"),
    (r"ARC-Term", "eventual route coverage"),
    (r"Terminal ARC", "eventual route coverage"),
    (r"\bTRC\b", "eventual route coverage"),
    (r"Flow-AnsLearn", "flow answerable learner"),
    (r"AnsLearn", "answerable learner"),
    (r"compiler[- ]shock recursion", "reference-jump recursion"),
    (r"compiler[- ]shock scalar", "reference-jump scalar"),
    (r"compiler[- ]shocks", "reference jumps"),
    (r"compiler[- ]shock", "reference jump"),
    (r"shock scalars", "jump scalars"),
    (r"shock scalar", "jump scalar"),
    (r"account separation", "fencing"),
    (r"\bfirewalls\b", "fences"),
    (r"\bFirewall\b", "Fencing"),
    (r"\bfirewall\b", "fencing"),
    (r"\bmartyrdom\b", "starvation"),
    (r"\bmartyr\b", "starvation case"),
    (r"\bextortion\b", "extraction"),
    (r"\bdefects\b", "objections"),
    (r"\bDefects\b", "Objections"),
    (r"\bdefect\b", "objection"),
    (r"\bDefect\b", "Objection"),
    (r"\bkernels\b", "mechanisms"),
    (r"\bKernels\b", "Mechanisms"),
    (r"\bkernel\b", "mechanism"),
    (r"\bKernel\b", "Mechanism"),
    (r"\bshocks\b", "jumps"),
    (r"\bShocks\b", "Jumps"),
    (r"\bshock\b", "jump"),
    (r"\bShock\b", "Jump"),
    (r"\brents\b", "charges"),
    (r"\bRents\b", "Charges"),
    (r"\brent\b", "charge"),
    (r"\bRent\b", "Charge"),
    (r"\brounds\b", "dates"),
    (r"\bRounds\b", "Dates"),
    (r"\bround\b", "date"),
    (r"\bRound\b", "Date"),
    (r"\bperiods\b", "dates"),
    (r"\bPeriods\b", "Dates"),
    (r"\bperiod\b", "date"),
    (r"\bPeriod\b", "Date"),
    (r"\bARC\b", "route coverage"),
    (r"\\alpha", r"\\theta"),
    (r"α", "θ"),
    (r"\balpha\b", "theta"),
)


CODE_COMPONENT_RENAMES = (
    ("compiler_shock", "reference_jump"),
    ("shock", "jump"),
    ("Kernel", "Mechanism"),
    ("kernel", "mechanism"),
    ("Firewall", "Fencing"),
    ("firewall", "fencing"),
    ("martyrdom", "starvation"),
    ("martyr", "starvation_case"),
    ("extortion", "extraction"),
    ("siege", "recurrent_complaint_sequence"),
    ("defect", "objection"),
    ("ARC", "RouteCoverage"),
    ("arc", "route_coverage"),
    ("rent", "charge"),
    ("round", "date"),
    ("period", "date"),
    ("alpha", "theta"),
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def eligible(root: pathlib.Path) -> list[pathlib.Path]:
    result = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES:
            continue
        if "archive" in path.parts or path.name == "apply_standardization.py":
            continue
        result.append(path)
    return sorted(result)


def apply_patterns(text: str, patterns: tuple[tuple[str, str], ...],
                   operations: list[dict[str, object]]) -> str:
    for pattern, replacement in patterns:
        regex = re.compile(pattern)
        cursor = 0
        pieces: list[str] = []
        for match in regex.finditer(text):
            pieces.append(text[cursor:match.start()])
            post_start = sum(len(piece) for piece in pieces)
            old = match.group(0)
            pieces.append(replacement)
            operations.append({"post_start": post_start, "old": old, "new": replacement})
            cursor = match.end()
        if cursor:
            pieces.append(text[cursor:])
            text = "".join(pieces)
    return text


def apply_code_components(text: str, operations: list[dict[str, object]]) -> str:
    for old, new in CODE_COMPONENT_RENAMES:
        pattern = re.compile(rf"(?<![A-Za-z]){re.escape(old)}(?![A-Za-z])")
        text = apply_patterns(text, ((pattern.pattern, new),), operations)
    return text


def main() -> None:
    if MANIFEST.exists():
        raise SystemExit(f"refusing to reapply: {MANIFEST} already exists")
    records: dict[str, object] = {"version": 1, "roots": {}, "files": {}}
    for label, root in (("consolidation_aug8", CONSOLIDATION), ("normative-learner", NORMATIVE)):
        records["roots"][label] = str(root)  # type: ignore[index]
        for path in eligible(root):
            original = path.read_bytes()
            text = original.decode("utf-8")
            operations: list[dict[str, object]] = []
            if path.suffix in {".py", ".lean"}:
                text = apply_code_components(text, operations)
                text = apply_patterns(text, ((r"\\alpha", r"\\theta"), (r"α", "θ")), operations)
            else:
                text = apply_patterns(text, PROSE_RENAMES, operations)
            renamed = text.encode("utf-8")
            if renamed != original:
                path.write_bytes(renamed)
                relative = f"{label}/{path.relative_to(root).as_posix()}"
                records["files"][relative] = {
                    "pure": path.suffix in {".py", ".lean"} and path.name != "run.py",
                    "pre_sha256": digest(original),
                    "mechanical_sha256": digest(renamed),
                    "operations": operations,
                }
    MANIFEST.write_text(json.dumps(records, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
