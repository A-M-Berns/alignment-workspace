#!/usr/bin/env python3
"""Notation-only rewrite of the downstream joint theorem."""
import re
from pathlib import Path

path = Path("/Users/anson/Desktop/normative-learner/JOINT_THEORY.md")
text = path.read_text()
for old, new in [
    ("`W={w_1,...,w_m}`", "`Omega_t={w_1,...,w_m}`"),
    ("`R^d`", "`R^d`"),
    ("`P=conv(W)`", "`Delta(Omega_t)=conv(Omega_t)`"),
    ("book is `R`", "book is `mathcal E_t`"),
    ("R_t", "\\mathcal E_t"),
    ("S_t", "\\mathcal C_t"),
    ("S_{t+1}", "\\mathcal C_{t+1}"),
    ("`R,S,q`", "`mathcal E,mathcal C,q`"),
    ("`R,S,q,p`", "`mathcal E,mathcal C,q,p`"),
    ("`R` it returns", "`mathcal E` it returns"),
    ("\\operatorname{Comp}(R)", "\\operatorname{Comp}(\\mathcal E)"),
    ("S(R)", "\\mathcal C(\\mathcal E)"),
    ("q(R)", "q(\\mathcal E)"),
    ("a(R)", "\\theta(\\mathcal E)"),
    ("`a(R)>=theta>0`", "`theta(mathcal E)>=theta>0`"),
    ("`q(R)`, `S(R)`", "`q(mathcal E)`, `mathcal C(mathcal E)`"),
    ("`E_*`", "`bar_epsilon`"),
    ("E_*", "\\overline\\varepsilon"),
    ("`D_ord`", "`M_ord`"),
    ("D_{ord}", "M_{ord}"),
    ("D_ord", "M_{ord}"),
    ("`-B`", "`-R`"),
    ("`B`", "`R`"),
    ("+B", "+R"),
    ("-B", "-R"),
    ("(B+", "(R+"),
    ("B+D", "R+D"),
    ("E_*+B", "\\overline\\varepsilon+R"),
    ("fixed finite coordinate", "fixed finite coordinate"),
    ("finite reference jump bound", "finite reference jump cap"),
    ("Finite reference jump bound", "Finite reference jump cap"),
    ("charged movement", "accounted movement"),
    ("the charge is `M`", "the liability is `M`"),
    ("Raw exposure", "Raw holdings"),
    ("raw exposure", "raw holdings"),
    ("Exposure is", "Holdings are"),
    ("one sourced row", "one sourced endorsement"),
    ("row `rho", "endorsement `rho"),
    ("invalid row", "invalid endorsement"),
]:
    text = text.replace(old, new)

# Book-object row vocabulary; ordinary Markdown ledger/table rows are absent here.
text = re.sub(r"\brow occurrences\b", "endorsement occurrences", text)
text = re.sub(r"\brow occurrence\b", "endorsement occurrence", text)
text = re.sub(r"\brows\b", "endorsements", text)
text = re.sub(r"\brow\b", "endorsement", text)

# In formulas and hypothesis lists B is now risk.  The book symbol has already
# been removed, so these remaining standalone occurrences are unambiguous.
text = re.sub(r"(?<![A-Za-z_])B(?![A-Za-z_])", "R", text)

# The represented credal carrier in this document.
text = text.replace("`z in P`", "`z in Delta(Omega_t)`")
text = text.replace("`w in P`", "`w in Delta(Omega_t)`")
text = text.replace("`q^-,q^+ in P`", "`q^-,q^+ in Delta(Omega_t)`")
text = text.replace("of `P`", "of `Delta(Omega_t)`")
text = text.replace("`P=[0,1]`", "`Delta(Omega_t)=[0,1]`")
text = text.replace("`W={0,1}`", "`Omega_t={0,1}`")

path.write_text(text)
print("joint notation standardized")
