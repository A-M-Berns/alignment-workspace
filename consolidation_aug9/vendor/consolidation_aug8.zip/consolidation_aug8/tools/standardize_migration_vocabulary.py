#!/usr/bin/env python3
"""Context-resolved migration vocabulary; all exposure uses here are market holdings."""
from pathlib import Path

ROOT = Path("/Users/anson/Desktop/normative-learner")

for name in ("MIGRATION_THEORY.md", "README.md", "OPEN_PROBLEMS.md", "LEDGER.md"):
    path = ROOT / name
    text = path.read_text()
    text = text.replace("nonzero-exposure", "nonzero-holdings")
    text = text.replace("exposure-norm", "holdings-norm")
    text = text.replace("exposure norm", "holdings norm")
    text = text.replace("exposure transport", "holdings transport")
    text = text.replace("frozen exposure", "frozen holdings")
    text = text.replace("outstanding exposure", "outstanding holdings")
    text = text.replace("old exposure", "old holdings")
    text = text.replace("zero exposure", "zero holdings")
    text = text.replace("unit of exposure", "unit of holdings")
    text = text.replace("exposure `", "holdings `")
    text = text.replace("exposure and", "holdings and")
    text = text.replace("Raw exposure", "Raw holdings")
    text = text.replace("raw exposure", "raw holdings")
    text = text.replace("`C-OF2` exposure", "`C-OF2` holdings")
    text = text.replace("row on every", "endorsement on every")
    text = text.replace("second row", "second endorsement")
    text = text.replace("proposed bound creates", "proposed endorsement creates")
    text = text.replace("answer/discharge witness", "response/discharge witness")
    text = text.replace("answer certificate", "response certificate")
    text = text.replace("mark its challenge answered", "mark its challenge responded to")
    text = text.replace("jump bound", "jump cap")
    text = text.replace("uniform bound", "uniform cap")
    path.write_text(text)

for path in list((ROOT / "src").glob("*.py")) + list((ROOT / "tests").glob("*.py")):
    text = path.read_text()
    text = text.replace("exposures", "holdings")
    text = text.replace("exposure", "holdings")
    text = text.replace("new_coordinate_holdings", "new_coordinate_holdings")
    text = text.replace("new_holdings", "new_holdings")
    text = text.replace("row:harm-floor", "endorsement:harm-bound")
    text = text.replace("row:any-harm-floor", "endorsement:any-harm-bound")
    text = text.replace("row:protect-pc", "endorsement:protect-pc")
    text = text.replace("row:protect", "endorsement:protect")
    path.write_text(text)

print("migration vocabulary standardized")
