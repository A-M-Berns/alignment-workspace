# Consolidation, August 8

This folder is a self-contained statement and verification package for the retained mathematics of the `LI-plus-leverage` corpus as of 2026-08-08. It presents one theory in a fixed order: reasons constraining through leverage and operative force; revising reasons through finite challenge-based answerability; and both as projections of the joint public-history process `NL-J3` in the downstream `normative-learner` project. Leverage and operative force are the thesis; answerability is the mechanism that turns its statics into a dynamics.

## Folder map

- `THEORY_1_FOUNDATIONS.md` through `THEORY_3_OPERATIVE_FORCE.md`: common records followed by reasons constraining—leverage and operative force.
- `THEORY_4_LEARNING_AND_INSTALLATION.md` through `THEORY_6_PARAMETERIZED_ANSWERABILITY.md`: revising reasons—activation, challenge semantics, and the parameterized flow mechanism. The joint `NL-J3` layer is pinned downstream.
- `GLOSSARY.md`: canonical vocabulary, notation, and the exhaustive old-to-new name table.
- `LEDGER.md`: one row for every formal monograph claim, with hypotheses, status, provenance, sharpness, and verification.
- `VERIFICATION.md`: trust audit, executable coverage, and Lean scope.
- `FOR_HUMANS.md`: standalone plain-language account.
- `INTERPRETATION.md`: non-authoritative readings and design commentary.
- `OPEN_PROBLEMS.md`: genuinely unresolved mathematical frontiers; adopted author decisions are in the decision ledger.
- `src/`, `tests/`: exact-rational Tier A and Tier B suite. Run `python3 tests/run.py` from this folder.
- `lean/`: vendored formal mechanism and four new bounded formalization targets.
- `FROZEN_INPUT_CHECKSUMS.json`: SHA-256 records for consulted and vendored sources.
- `DEVIATIONS.md`: source problems and consolidation limitations.
- `DECISION_LEDGER.md`: every discretionary consolidation choice.

## Evidence discipline

Passing finite code is evidence for the displayed finite instances only. General theorems are supported by the complete rederivations in the monograph. The ledger uses only the mandated status vocabulary. Conditional statements list their conditions; refutations display their witnesses; open questions are not promoted.

## One-command verification

From this directory:

```sh
python3 tests/run.py
```

The runner executes both Python tiers, checks claim-ledger coverage, checksum and rename integrity, and retired-name exclusion. Set `MATHLIB_DIR` to a Mathlib-enabled Lake project to compile both Lean files `sorry`-free; when it is unset, Lean is skipped explicitly and the Python/document suite remains portable. Mathlib is the only external mathematical dependency.

## Discard-test audit

The discard test passes for retained mathematical value. The six theory parts define every symbol and reprove every retained theorem; the ledger fixes status and provenance; exact computations and counterexamples are executable without repository imports; existing and new Lean source is vendored; and the checksum manifest freezes the evidence consulted. Deleting the rest of the repository would lose phase chronology, experimental process narration, superseded designs, and full original regression implementations, but no retained theorem, proof, decisive witness, exact number, status boundary, canonical definition, or open mathematical question. Tier B retains the long-tail numerical assertions rather than every historical implementation detail; that intentional distinction is recorded in `VERIFICATION.md` and does not alter mathematical content.
