# Part IV. Warrant learning, staged activation, and transfer

Let \(C\) be a finite typed claim set, \(K\) a finite set of warrants with premises and conclusions in \(C\), and \(A_0\subseteq C\).

**Finite inference closure.** {#C-INF-CLOSE} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Iterating
\[
A_{n+1}=A_n\cup\{c:\text{some warrant in }K\text{ has premises in }A_n\text{ and conclusion }c\}
\]
stabilizes after at most \(|C|\) strict-growth dates at the least \(K\)-closed superset of \(A_0\).

**Proof.** The sequence is monotone; each strict step adds an element of finite \(C\). By induction every closed superset of \(A_0\) contains every \(A_n\), hence the fixed point is least. \(\square\)

Governance changes \(K\) between closures. It is not an inference rule inside a closure.

**Proposal/activation separation.** {#C-ACTIVATION} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If operative projection reads activation records only, derivability without activation has identity operative projection; every operative endorsement has a stored derivation and authorization path.

**Proof.** The nonidentity branch is defined only on an activation record containing both paths. Absence of that constructor forces identity; presence exposes its stored fields. \(\square\)

## 1. Earlier authorization and persistent burdens

For initial prefix \(h_0\), define \(\operatorname{Improves}_{h_0}(p,d)\) to require: an earlier authorized route for objection class \(d\); a later public trigger; recognition of objection \(d\); evidence that proposal \(p\) addresses it; and preservation of every inherited unresolved burden.

**Prior-authorized correction theorem.** {#C-PRIOR-CORR} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Those five dated witnesses imply \(\operatorname{Improves}_{h_0}(p,d)\) whether or not the earlier state endorsed the endpoint of \(p\).

**Proof.** The witnesses are exactly the defining conjunction, with chronology supplied by their dates. Endpoint endorsement is not a conjunct. \(\square\)

Each witness is necessary for this declared relation. If only a successor-endorsement bit were required, every transformation could set the bit true on its image, so the test would impose no restriction.

**Successor self-endorsement obstruction.** {#C-SUCCESSOR} **Status: PROVED+MACHINE-CHECKED.** For every transformation \(F:X\to X\), there is a predicate that endorses every successor \(F(x)\); therefore successor endorsement alone restricts no transformation.

**Proof.** Take the predicate that is true on every element of \(X\). It holds at every \(F(x)\), independently of \(F\). \(\square\)

## 2. Targets and staged activation

A target \(T\) stores immutable identity, path \(\gamma:[0,1]\to\mathcal R\), endpoint, scope, authorization, burdens, and completion predicate. A stage stores nondecreasing \(\lambda_t\), realized state \(\gamma(\lambda_t)\), and remainder \(1-\lambda_t\).

**Target persistence and exact completion.** {#C-TARGET} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Every stage preserves the immutable fields; affordability changes only \(\lambda_t\); completion is exactly the stored predicate \(\mathsf{Complete}(T,\lambda_t)\). For affine paths,
\[
(\gamma(\lambda)-\gamma(0))+(\gamma(1)-\gamma(\lambda))=\gamma(1)-\gamma(0).
\]
For casewise completion \(\forall i\,\lambda_i=1\), any positive remainder precludes completion.

**Proof.** The algebraic identity expands and cancels. Induct over append-only stage transitions, each of which copies \(T\) and appends only new parameters. The completion flag is computed from, not independent of, the predicate. \(\square\)

**Positive remainder excludes completion.** {#C-NO-FALSE-COMPLETE} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Under casewise exact completion, if some \(1-\lambda_i>0\), the target is not complete.

**Proof.** Positive remainder implies \(\lambda_i<1\), contradicting the universal completion predicate. \(\square\)

**Maximal proportional stage.** {#C-MAX-STAGE} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Suppose on finitely many rational cells \(q(\lambda)\) is rational affine and
\[
K(\lambda)=m[-\langle H,q^0-q(\lambda)\rangle]_+
\]
is downward-feasible on \([\lambda_0,1]\). For rational capacity \(C\), the nonempty feasible set \(K(\lambda)\le C\) has a greatest rational element, found by scanning breakpoints and rational roots of \(K=C\).

**Proof.** Positive part preserves continuity and piecewise rational affinity. The feasible set is closed; downward feasibility makes it a closed initial interval. Its endpoint lies at a rational cell boundary or solves a rational affine equation. Finite scanning is exhaustive. \(\square\)

Downward feasibility is necessary for this scan: \(|2\lambda-1|\le C\) can be a middle interval. The retained instance has breakpoint \(1/2\), cost \(3\lambda/10-3/20\), capacity \(1/20\), and maximum \(2/3\).

**Staged-safety composition.** {#C-STAGE-SAFE} **Status: PROVED+MACHINE-CHECKED.** If \(\mathsf{Safe}(z)\) is preserved by every accepted operative transition and every stage is either identity or one accepted transition, every finite staged prefix starting safe is safe.

**Proof.** Induct on prefix length, using identity in the first case and the preservation implication in the second. \(\square\)

This imports the operative invariant; it does not prove one.

**Conditional target completion.** {#C-TARGET-LIVE} **Status: PROVED-CONDITIONAL (conditions listed).** A stable undefeated target of remaining cost at most \(C\) completes after a finite date at which cumulative free capacity reaches \(C\), provided its coordinates remain available and no incompatible target permanently consumes its service.

**Proof.** Nonstarvation assigns the target the finite service it still requires once that service exists. Maximal staging consumes available feasible progress, so a positive remainder after all \(C\) service would contradict the cost bound. \(\square\)

Recognition alone is insufficient: zero capacity keeps \(\lambda=0\) forever. Approaching \(C\) only asymptotically may give \(\lambda_t\to1\) without finite completion.

**Recognition without service.** {#C-RECOGNITION} **Status: REFUTED (witness displayed).** Recognition alone does not imply realization: a stable recognized target requiring positive capacity remains at \(\lambda_t=0\) when capacity is zero at every date.

**Proof.** No feasible transition has positive progress, so the constant zero-parameter run respects recognition and every capacity guard. \(\square\)

**Allocation nonuniqueness.** {#C-ALLOC-NONUNIQ} **Status: REFUTED (witness displayed).** Feasibility alone does not uniquely select among staged targets. In \(\{(\lambda_1,\lambda_2):0\le\lambda_i\le1,\lambda_1+\lambda_2\le1\}\), both \((1,0)\) and \((1/2,1/2)\) are Pareto maximal.

**Proof.** Both points are feasible. Increasing any coordinate at either point violates the sum constraint unless another is decreased, so both are maximal and distinct. \(\square\)

**Solvency does not imply authorization or priority.** {#C-SOLV-AUTH} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Funding fields alone entail neither activation nor a unique allocation among authorized targets.

**Proof.** The proposal/activation interface has no inference from a balance comparison to an activation constructor. Even after independent authorization, the two distinct funded Pareto maxima in the preceding witness remain. \(\square\)

**No target-independent fraction order.** {#C-PROGRESS-NOSCALAR} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Target identities and fractions alone determine no cross-target ordering.

**Proof.** At equal positive fractions, adding weights \((2,1)\) ranks target one first while \((1,2)\) reverses the ranking without changing any target or fraction. \(\square\)

## 3. Finite learned transfer

An ontology is finite data \((C,\Sigma,\operatorname{Eval},v)\) with a three-valued executable evaluator. A separate finite candidate family \(\mathcal H\) has versioned public definitions and provenance. An audit gives each candidate success set \(S_h\), burden set \(B_h\), failed clauses, and eligibility. Quotient by identical visible definition and define
\[
h\succ g\iff S_h\supseteq S_g,\quad B_h\subseteq B_g,
\quad(S_h\ne S_g\text{ or }B_h\ne B_g).
\]

**Finite version-space theorem.** {#C-VERSION} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Evaluation, eligibility, equivalence, dominance, and the undominated eligible set are decidable; \(\succ\) is a strict partial order; every nonempty eligible set has an undominated member; survivors satisfy every active clause; each nonsurvivor has a failed clause or named dominator.

**Proof.** All sets and evaluators are finite and decidable. Irreflexivity follows from the strict disjunct. Inclusion composes; if a composite had equality in both coordinates, strictness of both links would fail, proving transitivity. Following dominators in a finite irreflexive graph terminates. The last two conclusions unpack filtering and dominance removal. \(\square\)

Equal active records cannot be extensionally separated; a unique choice adds a tie-break. Renaming or duplicating an identical visible definition adds no quotient class. Counting support by provenance components makes copying inside one component ineffective, while coarsening components cannot increase support. Candidate-generated successes excluded from that candidate's support cannot raise its count.

**Extensional transfer underdetermination.** {#C-TRANSFER-UNDER} **Status: PROVED+INDEPENDENTLY-REDERIVED.** A predicate absent from the candidate family cannot be selected; distinct candidates with equal active evaluation records tie under every extensional comparison; a unique selection between them uses an additional datum.

**Proof.** The selector's codomain contains no absent predicate. Substitution of equal records makes every extensional score equal. Any asymmetric output must therefore depend on an identifier, complexity measure, breadth rule, or other added input. \(\square\)

**Visible-definition alias invariance.** {#C-ALIAS} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Renaming or duplicating an identical versioned executable definition changes no quotient class or selected executable rule.

**Proof.** Both operations add an element to an existing equivalence class, leaving the quotient and every quotient-defined operation unchanged. \(\square\)

**Represented-provenance duplication invariance.** {#C-DUP} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If support counts met provenance components, copying a record within one component adds no support, and coarsening the partition cannot increase support.

**Proof.** Set insertion of an existing component is idempotent. A coarsening maps several old components to at most one new component, so the image cardinality cannot increase. \(\square\)

**Audit-relative self-support exclusion.** {#C-SELF-SUPPORT} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If evidence generated by candidate \(h\) is excluded from \(h\)'s installation support, adding only such evidence cannot move \(h\) across a support threshold.

**Proof.** The counted support set is unchanged by every excluded addition. \(\square\)

**Feature-interface extensionality.** {#C-FEATURE-EXT} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Extensionally equal public case, definition, evaluation, and provenance outputs yield equal candidate records and proposals.

**Proof.** Every downstream constructor is a function of those outputs; substitute equals at each constructor. \(\square\)

**Six-case audit instance.** {#C-SIX-CASE} **Status: PROVED+INDEPENDENTLY-REDERIVED.** With successes \(c_0,c_2\), burden controls \(c_1,c_3\), and candidate predicates “all,” “manufacturing,” “local \(c_0\),” and “high dependency,” the rule requiring at least two successes and no burden controls makes “high dependency” uniquely eligible; it includes held-out \(c_4\) and excludes \(c_5\).

**Proof.** “All” hits both controls; “manufacturing” hits \(c_1\) and only one success; “local \(c_0\)” has one success; “high dependency” hits \(c_0,c_2\) and neither control. Its definition is true on high-dependency \(c_4\) and false on low-dependency \(c_5\). \(\square\)

**Local-change nonpropagation.** {#C-TRANSFER-LOCAL} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If \(\mathcal C_t=\prod_i\mathcal C_{t,i}\) and every endorsement and compiler operation is component-local, changing only component \(i\) leaves every marginal \(j\ne i\) unchanged.

**Proof.** Projection of \(\prod_k\mathcal C_{t,k}(\mathcal E_{t,k})\) to coordinate \(j\) is exactly \(\mathcal C_{t,j}(\mathcal E_{t,j})\) before and after the local change. \(\square\)

Thus learned transfer requires an explicit shared feature, schema, correspondence, or cross-case endorsement.

**Ontology noninterference.** {#C-ONTOLOGY-NI} **Status: PROVED+INDEPENDENTLY-REDERIVED.** If ontology outputs contain only cases, definitions, evaluations, and provenance, and operative projection requires selection, proposal, and activation in order, ontology values and unactivated proposals cannot change warrants, staging, or quote state.

**Proof.** Those state-changing values are absent from the ontology codomain, and the projection's nonidentity branch requires the missing activation event. \(\square\)

**End-to-end conditional composition.** {#C-COMPOSE} **Status: PROVED-CONDITIONAL (conditions listed).** Suppose ontology selection outputs data and at most a proposal; learning activates only through authorized append-only transition; staging preserves target identity and maps each accepted act to a force transition; that transition preserves safety; and every layer appends its witnesses. Then every operative prefix is safe, every operative act has a reconstructible evidence-to-admission path, and old paths and burdens persist after later defeat.

**Proof.** Induct on composite steps. Before activation, noninterference makes the force projection identity. Each accepted act invokes the assumed safe transition; no-progress dates are identity. Append-only concatenation preserves old witnesses and the step appends new ones. \(\square\)

## 4. Conservative finite-language extension

**Projection-conservative extension.** {#C-CONS-EXT} **Status: PROVED+INDEPENDENTLY-REDERIVED.** Let \(\Delta(\Omega'_t)\subset\mathbb R^{d+k}\) project onto \(\Delta(\Omega_t)\). Before new-coordinate action, assume the new permitted set is exactly \(\Delta(\Omega'_t)\cap\pi^{-1}(\mathcal C_t)\), references project correctly, demands and holdings have zero new-coordinate component, and old endorsements gain no new scope. Then old-coordinate variational inequalities, payoffs, holdings, movement liabilities, and constraints equal the old process term by term.

**Proof.** Inner products with zero new-coordinate demand depend only on projection. Surjectivity and the preimage condition make quantification over the new region equivalent to quantification over \(\mathcal C_t\). Every payoff, holdings vector, movement term, and endorsement then projects termwise. \(\square\)

Dropping zero holdings permits new-coordinate movement cost; dropping exact preimage scope permits old constraints to change; dropping surjectivity can shrink old prices.

**Fixed-endpoint acquisition boundary.** {#C-FIXED-ENDPOINT} **Status: PROVED (single derivation).** An evaluator whose success predicate is \(x=x^*\) can test arrival at \(x^*\) but does not explain acquisition of \(x^*\), because the endpoint is already an evaluator input.

**Proof.** Evaluating equality requires the constant \(x^*\). The test distinguishes states after that constant has been supplied; it contains no operation that derives the constant from data not already containing it. \(\square\)

**Fixed-transition boundary.** {#C-FIXED-KERNEL} **Status: PROVED (single derivation).** An induction theorem for \(F:X\to X\) does not automatically apply to a step that redefines \(X\) or \(F\).

**Proof.** The induction hypothesis is a proposition formed with the old types and transition. Without a relation transporting it to the new types and transition, it is not a premise about the new step. \(\square\)
